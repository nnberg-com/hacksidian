---
tags:
- atlas/technique
- atlas/table
category: table
digest: []
source_anchor: e023
sources:
- https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/table-layout
example: Markdown.{lang}.md
template: recipe.css
format: markdown
interactive: false
id: table-e023
description: Description.{lang}.md
---

# table-e023

[Русский](!%20P%20R%20O/hacksidian/atlas/!%20hacks/table-e023/Description.ru.md) · [English](!%20P%20R%20O/hacksidian/atlas/!%20hacks/table-e023/Description.en.md)
