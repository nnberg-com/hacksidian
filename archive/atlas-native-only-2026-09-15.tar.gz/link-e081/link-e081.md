---
tags:
- atlas/technique
- atlas/link
category: link
digest: []
source_anchor: e081
sources: []
example: Markdown.{lang}.md
template: recipe.css
format: markdown
interactive: false
id: link-e081
description: Description.{lang}.md
---

# link-e081

[Русский](!%20P%20R%20O/hacksidian/atlas/!%20hacks/link-e081/Description.ru.md) · [English](!%20P%20R%20O/hacksidian/atlas/!%20hacks/link-e081/Description.en.md)
