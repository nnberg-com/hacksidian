---
language: ru
translation_status: complete
title: NOTE · справочное примечание
group: GitHub Alerts
---

# NOTE · справочное примечание

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-gh-note
```

## Зачем

Пять штатных смысловых типов GitHub Alerts.

## Как работает

Тип в [!TYPE] превращается в markdown-alert-TYPE; заголовок и SVG создаёт GitHub.

## Ограничения исходного приёма

Это расширение GitHub поверх Markdown. CSS демо применяется в своём просмотрщике; произвольный CSS на github.com из README не подключается.

## Пояснения из HTML-атласа

ЗачемПять штатных смысловых типов GitHub Alerts.

КакТип в [!TYPE] превращается в markdown-alert-TYPE; заголовок и SVG создаёт GitHub.

Это расширение GitHub поверх Markdown. CSS демо применяется в своём просмотрщике; произвольный CSS на github.com из README не подключается.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#gh-note>)
- [Источник 1](https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#alerts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
/* Дополнительные правила отсутствуют в исходном рецепте. */
```

## Данные исходного каталога

```json
{
  "group": "github",
  "key": "gh-note",
  "title": "NOTE · справочное примечание",
  "why": "Пять штатных смысловых типов GitHub Alerts.",
  "how": "Тип в [!TYPE] превращается в markdown-alert-TYPE; заголовок и SVG создаёт GitHub.",
  "profile": "github",
  "type": "note",
  "note": "Это расширение GitHub поверх Markdown. CSS демо применяется в своём просмотрщике; произвольный CSS на github.com из README не подключается.",
  "source": "https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#alerts",
  "n": 1,
  "id": "c001"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="markdown-alert markdown-alert-note"><p class="markdown-alert-title"><svg data-component="Octicon" class="octicon octicon-info mr-2" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8Zm8-6.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13ZM6.5 7.75A.75.75 0 0 1 7.25 7h1a.75.75 0 0 1 .75.75v2.75h.25a.75.75 0 0 1 0 1.5h-2a.75.75 0 0 1 0-1.5h.25v-2h-.25a.75.75 0 0 1-.75-.75ZM8 6a1 1 0 1 1 0-2 1 1 0 0 1 0 2Z"></path></svg>Note</p><p>Изменения появятся после повторного открытия файла.</p>
</div>
```

## Опора на стандартную тему

Приём не содержит применяемых CSS-деклараций.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
