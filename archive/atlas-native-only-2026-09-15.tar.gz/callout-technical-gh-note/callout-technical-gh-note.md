---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: gh-note
sources:
- https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#alerts
example: Markdown.{lang}.md
template: recipe.css
format: markdown
interactive: false
id: callout-technical-gh-note
description: Description.{lang}.md
---

# callout-technical-gh-note

[Русский](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-gh-note/Description.ru.md) · [English](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-gh-note/Description.en.md)
