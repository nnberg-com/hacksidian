---
cssclasses:
  - atlas-callout-technical-ob-example
---

> [!example]
> Короткий образец показывает ожидаемый результат.
