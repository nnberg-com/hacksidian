---
language: en
translation_status: pending
---

## Default-theme baseline

This technique contains no applied CSS declarations.

[Default theme CSS](./Default.css) · [Bindings and unresolved cases](./baseline.json)

Remove the technique block or use Undo immediately after applying. Default.css is reference only, not a reset of user settings.
