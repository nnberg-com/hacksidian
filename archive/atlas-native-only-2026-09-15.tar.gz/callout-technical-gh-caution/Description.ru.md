---
language: ru
translation_status: complete
title: CAUTION · риск последствий
group: GitHub Alerts
---

# CAUTION · риск последствий

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-gh-caution
```

## Зачем

Пять штатных смысловых типов GitHub Alerts.

## Как работает

Тип в [!TYPE] превращается в markdown-alert-TYPE; заголовок и SVG создаёт GitHub.

## Ограничения исходного приёма

Это расширение GitHub поверх Markdown. CSS демо применяется в своём просмотрщике; произвольный CSS на github.com из README не подключается.

## Пояснения из HTML-атласа

ЗачемПять штатных смысловых типов GitHub Alerts.

КакТип в [!TYPE] превращается в markdown-alert-TYPE; заголовок и SVG создаёт GitHub.

Это расширение GitHub поверх Markdown. CSS демо применяется в своём просмотрщике; произвольный CSS на github.com из README не подключается.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#gh-caution>)
- [Источник 1](https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#alerts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
/* Дополнительные правила отсутствуют в исходном рецепте. */
```

## Данные исходного каталога

```json
{
  "group": "github",
  "key": "gh-caution",
  "title": "CAUTION · риск последствий",
  "why": "Пять штатных смысловых типов GitHub Alerts.",
  "how": "Тип в [!TYPE] превращается в markdown-alert-TYPE; заголовок и SVG создаёт GitHub.",
  "profile": "github",
  "type": "caution",
  "note": "Это расширение GitHub поверх Markdown. CSS демо применяется в своём просмотрщике; произвольный CSS на github.com из README не подключается.",
  "source": "https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#alerts",
  "n": 5,
  "id": "c005"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="markdown-alert markdown-alert-caution"><p class="markdown-alert-title"><svg data-component="Octicon" class="octicon octicon-stop mr-2" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path d="M4.47.22A.749.749 0 0 1 5 0h6c.199 0 .389.079.53.22l4.25 4.25c.141.14.22.331.22.53v6a.749.749 0 0 1-.22.53l-4.25 4.25A.749.749 0 0 1 11 16H5a.749.749 0 0 1-.53-.22L.22 11.53A.749.749 0 0 1 0 11V5c0-.199.079-.389.22-.53Zm.84 1.28L1.5 5.31v5.38l3.81 3.81h5.38l3.81-3.81V5.31L10.69 1.5ZM8 4a.75.75 0 0 1 .75.75v3.5a.75.75 0 0 1-1.5 0v-3.5A.75.75 0 0 1 8 4Zm0 8a1 1 0 1 1 0-2 1 1 0 0 1 0 2Z"></path></svg>Caution</p><p>Удалённые локальные изменения нельзя восстановить без копии.</p>
</div>
```

## Опора на стандартную тему

Приём не содержит применяемых CSS-деклараций.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
