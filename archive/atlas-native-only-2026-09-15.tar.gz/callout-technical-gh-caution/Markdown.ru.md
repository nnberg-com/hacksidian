---
cssclasses:
  - atlas-callout-technical-gh-caution
---

> [!CAUTION]
> Удалённые локальные изменения нельзя восстановить без копии.
