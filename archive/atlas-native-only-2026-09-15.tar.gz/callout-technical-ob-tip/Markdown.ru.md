---
cssclasses:
  - atlas-callout-technical-ob-tip
---

> [!tip]
> Начните с маленького воспроизводимого примера.
