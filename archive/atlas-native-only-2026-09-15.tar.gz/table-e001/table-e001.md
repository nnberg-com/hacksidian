---
tags:
- atlas/technique
- atlas/table
category: table
digest: []
source_anchor: e001
sources:
- https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics/Tables
example: Markdown.{lang}.md
template: recipe.css
format: markdown
interactive: false
id: table-e001
description: Description.{lang}.md
---

# table-e001

[Русский](!%20P%20R%20O/hacksidian/atlas/!%20hacks/table-e001/Description.ru.md) · [English](!%20P%20R%20O/hacksidian/atlas/!%20hacks/table-e001/Description.en.md)
