---
tags:
- atlas/technique
- atlas/quote
category: quote
digest: []
source_anchor: ofm-default
sources: []
example: Markdown.{lang}.md
template: recipe.css
format: markdown
interactive: false
id: quote-ofm-default
description: Description.{lang}.md
---

# quote-ofm-default

[Русский](!%20P%20R%20O/hacksidian/atlas/!%20hacks/quote-ofm-default/Description.ru.md) · [English](!%20P%20R%20O/hacksidian/atlas/!%20hacks/quote-ofm-default/Description.en.md)
