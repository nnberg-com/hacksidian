---
language: ru
translation_status: complete
title: failure · неудача
group: Типы Obsidian
---

# failure · неудача

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-ob-failure
```

## Зачем

Штатный тип Callout в Obsidian.

## Как работает

data-callout хранит тип из [!type]; заголовок и значок создаёт рендерер.

## Ограничения исходного приёма

Цвета этой страницы — самостоятельная CSS-тема, а не обещание совпадения с установленной темой Obsidian.

## Пояснения из HTML-атласа

ЗачемШтатный тип Callout в Obsidian.

Какdata-callout хранит тип из [!type]; заголовок и значок создаёт рендерер.

Цвета этой страницы — самостоятельная CSS-тема, а не обещание совпадения с установленной темой Obsidian.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#ob-failure>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
/* Дополнительные правила отсутствуют в исходном рецепте. */
```

## Данные исходного каталога

```json
{
  "group": "obsidian",
  "key": "ob-failure",
  "title": "failure · неудача",
  "why": "Штатный тип Callout в Obsidian.",
  "how": "data-callout хранит тип из [!type]; заголовок и значок создаёт рендерер.",
  "profile": "obsidian",
  "type": "failure",
  "note": "Цвета этой страницы — самостоятельная CSS-тема, а не обещание совпадения с установленной темой Obsidian.",
  "source": "https://help.obsidian.md/callouts",
  "n": 14,
  "id": "c014"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="failure" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Failure</div></div><div class="callout-content">
<p>Проверка не завершена: один из файлов отсутствует.</p>
</div></div>
```

## Опора на стандартную тему

Приём не содержит применяемых CSS-деклараций.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
