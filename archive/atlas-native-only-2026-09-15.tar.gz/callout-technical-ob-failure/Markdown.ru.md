---
cssclasses:
  - atlas-callout-technical-ob-failure
---

> [!failure]
> Проверка не завершена: один из файлов отсутствует.
