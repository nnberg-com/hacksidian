---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: ob-failure
sources:
- https://help.obsidian.md/callouts
example: Markdown.{lang}.md
template: recipe.css
format: markdown
interactive: false
id: callout-technical-ob-failure
description: Description.{lang}.md
---

# callout-technical-ob-failure

[Русский](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-ob-failure/Description.ru.md) · [English](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-ob-failure/Description.en.md)
