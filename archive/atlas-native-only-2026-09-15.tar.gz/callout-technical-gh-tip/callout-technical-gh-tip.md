---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: gh-tip
sources:
- https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#alerts
example: Markdown.{lang}.md
template: recipe.css
format: markdown
interactive: false
id: callout-technical-gh-tip
description: Description.{lang}.md
---

# callout-technical-gh-tip

[Русский](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-gh-tip/Description.ru.md) · [English](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-gh-tip/Description.en.md)
