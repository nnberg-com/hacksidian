---
cssclasses:
  - atlas-callout-technical-gh-tip
---

> [!TIP]
> Сначала проверьте оформление на коротком примере.
