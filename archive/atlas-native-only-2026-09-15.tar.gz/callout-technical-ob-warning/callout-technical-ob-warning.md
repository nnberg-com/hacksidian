---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: ob-warning
sources:
- https://help.obsidian.md/callouts
example: Markdown.{lang}.md
template: recipe.css
format: markdown
interactive: false
id: callout-technical-ob-warning
description: Description.{lang}.md
---

# callout-technical-ob-warning

[Русский](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-ob-warning/Description.ru.md) · [English](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-ob-warning/Description.en.md)
