---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: ob-info
sources:
- https://help.obsidian.md/callouts
example: Markdown.{lang}.md
template: recipe.css
format: markdown
interactive: false
id: callout-technical-ob-info
description: Description.{lang}.md
---

# callout-technical-ob-info

[Русский](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-ob-info/Description.ru.md) · [English](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-ob-info/Description.en.md)
