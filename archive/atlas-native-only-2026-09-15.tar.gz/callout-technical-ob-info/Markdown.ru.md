---
cssclasses:
  - atlas-callout-technical-ob-info
---

> [!info]
> Обновление доступно после перезапуска приложения.
