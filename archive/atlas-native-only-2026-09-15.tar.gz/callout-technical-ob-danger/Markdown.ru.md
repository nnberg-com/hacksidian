---
cssclasses:
  - atlas-callout-technical-ob-danger
---

> [!danger]
> Перед удалением данных сохраните резервную копию.
