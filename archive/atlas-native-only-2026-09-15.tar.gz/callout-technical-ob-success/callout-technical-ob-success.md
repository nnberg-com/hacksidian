---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: ob-success
sources:
- https://help.obsidian.md/callouts
example: Markdown.{lang}.md
template: recipe.css
format: markdown
interactive: false
id: callout-technical-ob-success
description: Description.{lang}.md
---

# callout-technical-ob-success

[Русский](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-ob-success/Description.ru.md) · [English](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-ob-success/Description.en.md)
