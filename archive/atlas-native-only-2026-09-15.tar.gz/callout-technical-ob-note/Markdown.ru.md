---
cssclasses:
  - atlas-callout-technical-ob-note
---

> [!note]
> Сохраните промежуточный результат рядом с исходником.
