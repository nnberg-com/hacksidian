---
cssclasses:
  - atlas-callout-technical-ob-question
---

> [!question]
> Что изменится, если открыть документ на узком экране?
