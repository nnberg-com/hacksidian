---
cssclasses:
  - atlas-callout-technical-ob-quote
---

> [!quote]
> «Хорошая заметка помогает вернуться к мысли позже».
