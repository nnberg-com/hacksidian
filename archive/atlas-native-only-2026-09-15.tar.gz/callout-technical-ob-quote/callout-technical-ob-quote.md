---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: ob-quote
sources:
- https://help.obsidian.md/callouts
example: Markdown.{lang}.md
template: recipe.css
format: markdown
interactive: false
id: callout-technical-ob-quote
description: Description.{lang}.md
---

# callout-technical-ob-quote

[Русский](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-ob-quote/Description.ru.md) · [English](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-ob-quote/Description.en.md)
