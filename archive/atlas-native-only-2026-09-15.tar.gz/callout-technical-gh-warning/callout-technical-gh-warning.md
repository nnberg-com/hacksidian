---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: gh-warning
sources:
- https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#alerts
example: Markdown.{lang}.md
template: recipe.css
format: markdown
interactive: false
id: callout-technical-gh-warning
description: Description.{lang}.md
---

# callout-technical-gh-warning

[Русский](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-gh-warning/Description.ru.md) · [English](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-gh-warning/Description.en.md)
