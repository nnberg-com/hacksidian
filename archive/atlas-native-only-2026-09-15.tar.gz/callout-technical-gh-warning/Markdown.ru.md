---
cssclasses:
  - atlas-callout-technical-gh-warning
---

> [!WARNING]
> Повторная загрузка может прервать текущую операцию.
