---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: ob-abstract
sources:
- https://help.obsidian.md/callouts
example: Markdown.{lang}.md
template: recipe.css
format: markdown
interactive: false
id: callout-technical-ob-abstract
description: Description.{lang}.md
---

# callout-technical-ob-abstract

[Русский](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-ob-abstract/Description.ru.md) · [English](!%20P%20R%20O/hacksidian/atlas/!%20hacks/callout-technical-ob-abstract/Description.en.md)
