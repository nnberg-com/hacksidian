---
cssclasses:
  - atlas-callout-technical-ob-abstract
---

> [!abstract]
> Ниже — три вывода из подробного исследования.
