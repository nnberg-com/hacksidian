---
cssclasses:
  - atlas-callout-technical-ob-bug
---

> [!bug]
> Заголовок перекрывает первую строку содержимого.
