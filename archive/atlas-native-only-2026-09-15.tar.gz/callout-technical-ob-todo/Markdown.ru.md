---
cssclasses:
  - atlas-callout-technical-ob-todo
---

> [!todo]
> Сравнить два варианта и записать результат.
