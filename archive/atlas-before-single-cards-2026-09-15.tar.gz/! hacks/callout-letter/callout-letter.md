---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: letter
sources:
- https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/letter.html
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-letter
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-letter/Description.ru]]
