---
language: ru
translation_status: complete
title: Письмо из архива
group: ''
---

# Письмо из архива

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-letter
```

## Зачем

Визуально отделить первоисточник от авторского рассказа.

## Как работает

Заголовок и абзацы остаются обычным Markdown. CSS задаёт бумагу, книжную типографику, увеличенную первую букву и положение подписи.

## Ограничения исходного приёма

Текст письма вымышленный. Это пример оформления источника, не архивная цитата.

## Пояснения из HTML-атласа

Визуально отделить первоисточник от авторского рассказа.

Заголовок и абзацы остаются обычным Markdown. CSS задаёт бумагу, книжную типографику, увеличенную первую букву и положение подписи.

Текст письма вымышленный. Это пример оформления источника, не архивная цитата.

Практика сообщества

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/index.html#letter>)
- [Источник 1](https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/letter.html)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
[data-callout="letter"] {padding:30px clamp(20px,5vw,44px);background:#f7ecd6;color:#58452d;box-shadow:0 12px 25px #49331b18;border:1px solid #ddc9a2;font-family:Georgia,serif}
[data-callout="letter"] > .callout-title {font-size:28px;font-style:italic;border-bottom:1px solid #ccb78e;padding-bottom:18px;margin-bottom:20px}
[data-callout="letter"] p {line-height:1.8}
[data-callout="letter"] p:first-child {font-size:12px;text-align:right;letter-spacing:.04em}
[data-callout="letter"] p:nth-child(3)::first-letter {float:left;font-size:50px;line-height:1;padding-right:8px;color:#986236}
[data-callout="letter"] p:last-child {text-align:right;font-size:23px}
```

## Данные исходного каталога

```json
{
  "key": "letter",
  "title": "Письмо из архива",
  "role": "Визуально отделить первоисточник от авторского рассказа.",
  "how": "Заголовок и абзацы остаются обычным Markdown. CSS задаёт бумагу, книжную типографику, увеличенную первую букву и положение подписи.",
  "ref": "https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/letter.html",
  "limit": "Текст письма вымышленный. Это пример оформления источника, не архивная цитата."
}
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 4. Используется штатных переменных: 2. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color, font; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 3. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
