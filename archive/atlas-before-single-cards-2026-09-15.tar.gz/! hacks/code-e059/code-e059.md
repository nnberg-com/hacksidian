---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e059
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: code-e059
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e059/Description.ru]]
