---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: catalogue
sources:
- https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/table-cards.html
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-catalogue
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-catalogue/Description.ru]]
