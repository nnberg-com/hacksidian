---
language: ru
translation_status: complete
title: Каталог из таблицы
group: ''
---

# Каталог из таблицы

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-catalogue
```

## Зачем

Просматривать небольшую подборку объектов по одной и той же схеме.

## Как работает

Каждая строка Markdown-таблицы становится карточкой; первая ячейка — её крупным названием. Названия полей остаются в самом тексте.

## Ограничения исходного приёма

Это визуальное преобразование таблицы. При переносе в продукт нужно отдельно проверить чтение таблицы экранным диктором.

## Пояснения из HTML-атласа

Просматривать небольшую подборку объектов по одной и той же схеме.

Каждая строка Markdown-таблицы становится карточкой; первая ячейка — её крупным названием. Названия полей остаются в самом тексте.

Это визуальное преобразование таблицы. При переносе в продукт нужно отдельно проверить чтение таблицы экранным диктором.

Практика сообщества

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/index.html#catalogue>)
- [Источник 1](https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/table-cards.html)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
[data-callout="catalogue"] > .callout-title {font-size:23px;margin-bottom:20px}
[data-callout="catalogue"] table,[data-callout="catalogue"] tbody {display:block;width:100%}
[data-callout="catalogue"] thead {position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%)}
[data-callout="catalogue"] tbody {display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,155px),1fr));gap:12px}
[data-callout="catalogue"] tr {display:flex;flex-direction:column;border:1px solid #d5c4a8;background:#fffaf0;padding:18px;box-shadow:0 4px 0 #d5c4a8}
[data-callout="catalogue"] td {display:block;padding:8px 0;font-size:13px}
[data-callout="catalogue"] td:first-child {font-family:Georgia,serif;font-size:23px;line-height:1.1;min-height:75px;border-bottom:1px solid #d5c4a8;margin-bottom:12px}
```

## Данные исходного каталога

```json
{
  "key": "catalogue",
  "title": "Каталог из таблицы",
  "role": "Просматривать небольшую подборку объектов по одной и той же схеме.",
  "how": "Каждая строка Markdown-таблицы становится карточкой; первая ячейка — её крупным названием. Названия полей остаются в самом тексте.",
  "ref": "https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/table-cards.html",
  "limit": "Это визуальное преобразование таблицы. При переносе в продукт нужно отдельно проверить чтение таблицы экранным диктором."
}
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 4. Используется штатных переменных: 2. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color, font; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 9. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
