---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e036
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e036
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e036/Description.ru]]
