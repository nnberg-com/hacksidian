---
language: ru
translation_status: complete
title: Окно с тремя кружками
group: Декоративные оболочки
---

# Окно с тремя кружками

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
code-e036
```

## Зачем

Декоративная имитация окна терминала в статье.

## Как работает

pre::before создаёт шапку; три radial-gradient рисуют кружки.

## Ограничения исходного приёма

Кружки — рисунок. Они не являются кнопками.

## Пояснения из HTML-атласа

Декоративная имитация окна терминала в статье.

pre::before создаёт шапку; три radial-gradient рисуют кружки.

Кружки — рисунок. Они не являются кнопками.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/code-styles-demo/index.html#e036>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
S pre { background: #202d29; color: #e3ebdf; border-radius: 10px; padding-top: 0; }
S pre::before { content: ""; display: block; height: 36px; margin-inline: -18px; margin-bottom: 14px; background: radial-gradient(circle at 20px 18px, #e78471 0 4px, transparent 5px), radial-gradient(circle at 36px 18px, #e8c67c 0 4px, transparent 5px), radial-gradient(circle at 52px 18px, #8bb58b 0 4px, transparent 5px), #ffffff0c; }
```

## Данные исходного каталога

```json
{
  "id": "e036",
  "group": "objects",
  "title": "Окно с тремя кружками",
  "why": "Декоративная имитация окна терминала в статье.",
  "how": "pre::before создаёт шапку; три radial-gradient рисуют кружки.",
  "note": "Кружки — рисунок. Они не являются кнопками.",
  "kind": "Обычный Markdown"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<pre><code>const palette = {
  background: &quot;#f8f7f2&quot;,
  accent: &quot;#bd5036&quot;,
  spacing: [4, 8, 16]
};

render(palette);
</code></pre>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 3. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
