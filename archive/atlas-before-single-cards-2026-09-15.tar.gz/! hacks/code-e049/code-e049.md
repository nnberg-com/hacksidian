---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e049
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e049
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e049/Description.ru]]
