---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e045
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: footnote-e045
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e045/Description.ru]]
