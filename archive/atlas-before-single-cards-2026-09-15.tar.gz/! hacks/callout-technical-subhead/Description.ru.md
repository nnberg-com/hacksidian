---
language: ru
translation_status: complete
title: Подзаголовки внутри тела
group: Контекст и длинный текст
---

# Подзаголовки внутри тела

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-subhead
```

## Зачем

Длинное примечание с двумя самостоятельными пунктами.

## Как работает

Настоящий h3 находится в callout-content, а не подменяет заголовок самого Callout.

## Пояснения из HTML-атласа

ЗачемДлинное примечание с двумя самостоятельными пунктами.

КакНастоящий h3 находится в callout-content, а не подменяет заголовок самого Callout.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#subhead>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@body h3 {font-size:.9em;color:var(--tone);margin:1em 0 .3em} @body h3:first-child {margin-top:0}
```

## Данные исходного каталога

```json
{
  "group": "detail",
  "key": "subhead",
  "title": "Подзаголовки внутри тела",
  "why": "Длинное примечание с двумя самостоятельными пунктами.",
  "how": "Настоящий h3 находится в callout-content, а не подменяет заголовок самого Callout.",
  "profile": "obsidian",
  "type": "note",
  "note": "",
  "source": "https://help.obsidian.md/callouts",
  "n": 59,
  "id": "c059"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="note" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Условия применения</div></div><div class="callout-content">
<h3 data-heading="Когда использовать">Когда использовать</h3>
<p>Когда пояснение относится к одному месту текста.</p>
<h3 data-heading="Когда сократить">Когда сократить</h3>
<p>Когда примечание становится длиннее основного раздела.</p>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 1. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
