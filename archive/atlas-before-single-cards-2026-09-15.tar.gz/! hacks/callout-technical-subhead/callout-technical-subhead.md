---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: subhead
sources:
- https://help.obsidian.md/callouts
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-technical-subhead
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-technical-subhead/Description.ru]]
