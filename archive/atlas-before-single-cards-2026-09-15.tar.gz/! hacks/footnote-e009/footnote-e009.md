---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e009
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: footnote-e009
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e009/Description.ru]]
