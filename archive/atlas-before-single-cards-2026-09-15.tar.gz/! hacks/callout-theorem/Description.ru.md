---
language: ru
translation_status: complete
title: Утверждение и доказательство
group: ''
---

# Утверждение и доказательство

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-theorem
```

## Зачем

Отделить формальное утверждение от его обоснования в конспекте или исследовательской заметке.

## Как работает

Собственный тип задаёт книжный шрифт и курсив утверждения. Доказательство — вложенный callout с прямым начертанием; знак завершения рисует псевдоэлемент.

## Ограничения исходного приёма

Номер вписан в Markdown. CSS не проверяет доказательство и не вычисляет номера или ссылки на утверждения.

## Пояснения из HTML-атласа

Отделить формальное утверждение от его обоснования в конспекте или исследовательской заметке.

Собственный тип задаёт книжный шрифт и курсив утверждения. Доказательство — вложенный callout с прямым начертанием; знак завершения рисует псевдоэлемент.

Номер вписан в Markdown. CSS не проверяет доказательство и не вычисляет номера или ссылки на утверждения.

sailKite и elevict

От источника — академическая типографика callout. Вложенное доказательство и завершающий квадрат — наша адаптация; отдельного математического рендеринга нет.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/index.html#theorem>)
- [Источник 1](https://github.com/r-u-s-h-i-k-e-s-h/Obsidian-CSS-Snippets/blob/Collection/snippets/callout%20styling%20-%20theorem%20callout.md)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
[data-callout="theorem"] {background:#fff;color:#262626;border-block:2px solid #343434;padding:26px 22px;font:italic 18px/1.75 Georgia,serif}
[data-callout="theorem"] > .callout-title {font-style:normal;font-weight:400;font-size:20px;margin-bottom:14px;line-height:1.4}
[data-callout="theorem"] > .callout-content > p {margin-bottom:24px}
[data-callout="demonstration"] {border-top:1px solid #c9c9c9;padding-top:18px;font-style:normal;font-size:16px}
[data-callout="demonstration"] > .callout-title {font-style:italic;font-weight:400}
[data-callout="demonstration"] > .callout-content::after {content:"∎";display:block;text-align:right;font-size:19px;line-height:1}
```

## Данные исходного каталога

```json
{
  "key": "theorem",
  "title": "Утверждение и доказательство",
  "role": "Отделить формальное утверждение от его обоснования в конспекте или исследовательской заметке.",
  "how": "Собственный тип задаёт книжный шрифт и курсив утверждения. Доказательство — вложенный callout с прямым начертанием; знак завершения рисует псевдоэлемент.",
  "ref": "https://github.com/r-u-s-h-i-k-e-s-h/Obsidian-CSS-Snippets/blob/Collection/snippets/callout%20styling%20-%20theorem%20callout.md",
  "limit": "Номер вписан в Markdown. CSS не проверяет доказательство и не вычисляет номера или ссылки на утверждения.",
  "author": "sailKite и elevict",
  "adaptation": "От источника — академическая типографика callout. Вложенное доказательство и завершающий квадрат — наша адаптация; отдельного математического рендеринга нет."
}
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 5. Используется штатных переменных: 3. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 4. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
