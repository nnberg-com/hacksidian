---
tags:
- atlas/technique
- atlas/callout
category: callout
digest:
- teach
source_anchor: theorem
sources:
- https://github.com/r-u-s-h-i-k-e-s-h/Obsidian-CSS-Snippets/blob/Collection/snippets/callout%20styling%20-%20theorem%20callout.md
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-theorem
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-theorem/Description.ru]]
