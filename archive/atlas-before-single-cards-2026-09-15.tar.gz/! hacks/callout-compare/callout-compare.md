---
tags:
- atlas/technique
- atlas/callout
category: callout
digest:
- teach
- management
source_anchor: compare
sources:
- https://github.com/efemkay/obsidian-modular-css-layout#multi-column
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-compare
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-compare/Description.ru]]
