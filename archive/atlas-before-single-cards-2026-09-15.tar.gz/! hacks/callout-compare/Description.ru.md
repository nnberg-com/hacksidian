---
language: ru
translation_status: complete
title: Сравнение решений
group: ''
---

# Сравнение решений

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-compare
```

## Зачем

Сопоставить варианты в одном поле зрения и записать основания выбора.

## Как работает

Вложенные callouts становятся колонками CSS Grid. На узком экране колонки переходят в вертикальный список.

## Пояснения из HTML-атласа

Сопоставить варианты в одном поле зрения и записать основания выбора.

Вложенные callouts становятся колонками CSS Grid. На узком экране колонки переходят в вертикальный список.

Практика сообщества

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/index.html#compare>)
- [Источник 1](https://github.com/efemkay/obsidian-modular-css-layout#multi-column)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
[data-callout="compare"] {border-top:3px solid #282b29;padding-top:18px}
[data-callout="compare"] > .callout-title {font-size:21px;line-height:1.25;margin-bottom:20px}
[data-callout="compare"] > .callout-content {display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
[data-callout="option"], [data-callout="selected"] {padding:20px;background:#edece7;font-size:14px}
[data-callout="selected"] {background:#233e34;color:#fff}
[data-callout="option"] > .callout-title,[data-callout="selected"] > .callout-title {font-family:Georgia,serif;font-size:22px;margin-bottom:20px}
@media(max-width:650px){[data-callout="compare"] > .callout-content {grid-template-columns:1fr}}
```

## Данные исходного каталога

```json
{
  "key": "compare",
  "title": "Сравнение решений",
  "role": "Сопоставить варианты в одном поле зрения и записать основания выбора.",
  "how": "Вложенные callouts становятся колонками CSS Grid. На узком экране колонки переходят в вертикальный список.",
  "ref": "https://github.com/efemkay/obsidian-modular-css-layout#multi-column",
  "limit": ""
}
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 4. Используется штатных переменных: 2. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color, font; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 5. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
