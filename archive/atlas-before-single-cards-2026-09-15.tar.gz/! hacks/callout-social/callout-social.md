---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: social
sources:
- https://gist.github.com/masaki39/dbf19b19333ae9b7b687b93b0c4ac346
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-social
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-social/Description.ru]]
