---
language: ru
translation_status: complete
title: Пост из полевого дневника
group: ''
---

# Пост из полевого дневника

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-social
```

## Зачем

Представить короткую запись как публикацию конкретного человека с датой, изображением автора и ссылкой.

## Как работает

Имя — заголовок, аватар — обычное Markdown-изображение, дата — последний абзац. CSS помещает аватар рядом с именем. Все содержательные данные остаются в Markdown.

## Ограничения исходного приёма

Это статическая публикация. Здесь нет отправки сообщений, лайков и счётчиков взаимодействий.

## Пояснения из HTML-атласа

Представить короткую запись как публикацию конкретного человека с датой, изображением автора и ссылкой.

Имя — заголовок, аватар — обычное Markdown-изображение, дата — последний абзац. CSS помещает аватар рядом с именем. Все содержательные данные остаются в Markdown.

Это статическая публикация. Здесь нет отправки сообщений, лайков и счётчиков взаимодействий.

masaki39

В исходнике имя и аватар заданы в CSS, а значки действий декоративные. Здесь имя, дата и аватар перенесены в Markdown, фиктивная панель действий убрана.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/index.html#social>)
- [Источник 1](https://gist.github.com/masaki39/dbf19b19333ae9b7b687b93b0c4ac346)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/station.svg](<./assets/assets/station.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
[data-callout="social"] {position:relative;background:#15232e;color:#e4edf2;border:1px solid #415362;border-radius:16px;padding:26px 24px 22px 90px}
[data-callout="social"] > .callout-title {font-size:16px;line-height:1.4;margin-bottom:18px}
[data-callout="social"] > .callout-content > p:first-child {margin:0}
[data-callout="social"] img {position:absolute;left:22px;top:24px;width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid #647e8b}
[data-callout="social"] > .callout-content {font-size:16px;line-height:1.65}
[data-callout="social"] a {color:#8ec8ed;font-size:13px}
[data-callout="social"] > .callout-content > p:last-child {border-top:1px solid #415362;padding-top:15px;margin-top:20px;color:#a5bac7;font-size:11px;font-variant-numeric:tabular-nums}
@media(max-width:650px){[data-callout="social"] {padding:22px}[data-callout="social"] > .callout-title {padding-left:64px;min-height:50px}}
```

## Данные исходного каталога

```json
{
  "key": "social",
  "title": "Пост из полевого дневника",
  "role": "Представить короткую запись как публикацию конкретного человека с датой, изображением автора и ссылкой.",
  "how": "Имя — заголовок, аватар — обычное Markdown-изображение, дата — последний абзац. CSS помещает аватар рядом с именем. Все содержательные данные остаются в Markdown.",
  "ref": "https://gist.github.com/masaki39/dbf19b19333ae9b7b687b93b0c4ac346",
  "limit": "Это статическая публикация. Здесь нет отправки сообщений, лайков и счётчиков взаимодействий.",
  "author": "masaki39",
  "adaptation": "В исходнике имя и аватар заданы в CSS, а значки действий декоративные. Здесь имя, дата и аватар перенесены в Markdown, фиктивная панель действий убрана."
}
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 6. Используется штатных переменных: 2. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 7. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
