---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e013
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: footnote-e013
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e013/Description.ru]]
