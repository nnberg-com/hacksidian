---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e036
sources:
- https://github.com/markdown-it/markdown-it-footnote
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: footnote-e036
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e036/Description.ru]]
