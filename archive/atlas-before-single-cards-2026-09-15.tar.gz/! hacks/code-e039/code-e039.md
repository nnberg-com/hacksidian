---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e039
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e039
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e039/Description.ru]]
