---
language: ru
translation_status: complete
title: Чередование подложек
group: Список примечаний
---

# Чередование подложек

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
footnote-e019
```

## Зачем

Длинный список коротких источников проще просматривать.

## Как работает

nth-child(even) выделяет каждую вторую сноску.

## Демонстрация

Сравните номер в тексте и примечания ниже.

## Ограничения исходного приёма

Обычный CSS

## Пояснения из HTML-атласа

Как nth-child(even) выделяет каждую вторую сноску.

Зачем Длинный список коротких источников проще просматривать.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/footnote-styles-demo/index.html#e019>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Общие условия исходного раздела

Подсветка и нижняя панель основаны на опубликованных приёмах. Варианты оформления и сочетания с :has() и якорями — адаптации для HTML выбранного Markdown-рендерера.

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
.e019 .footnote-item {padding:.45em .7em;}
.e019 .footnote-item:nth-child(even) {background:var(--tint);}
```

## Данные исходного каталога

```json
{
  "id": "e019",
  "title": "Чередование подложек",
  "how": "nth-child(even) выделяет каждую вторую сноску.",
  "why": "Длинный список коротких источников проще просматривать.",
  "action": "Сравните номер в тексте и примечания ниже.",
  "limit": "",
  "support": "Обычный CSS",
  "group": "endnotes"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<p>В этом фрагменте собраны короткие источники: первый,<sup class="footnote-ref"><a href="#fn-e019-1" id="fnref-e019-1">[1]</a></sup> второй,<sup class="footnote-ref"><a href="#fn-e019-2" id="fnref-e019-2">[2]</a></sup> третий,<sup class="footnote-ref"><a href="#fn-e019-3" id="fnref-e019-3">[3]</a></sup> четвёртый,<sup class="footnote-ref"><a href="#fn-e019-4" id="fnref-e019-4">[4]</a></sup> пятый<sup class="footnote-ref"><a href="#fn-e019-5" id="fnref-e019-5">[5]</a></sup> и шестой.<sup class="footnote-ref"><a href="#fn-e019-6" id="fnref-e019-6">[6]</a></sup></p>
<hr class="footnotes-sep">
<section class="footnotes">
<ol class="footnotes-list">
<li id="fn-e019-1" class="footnote-item"><p>Записные книжки. 1924. <a href="#fnref-e019-1" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e019-2" class="footnote-item"><p>Письма к редактору. 1931. Дополнительное уточнение занимает ещё одну строку. <a href="#fnref-e019-2" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e019-3" class="footnote-item"><p>Каталог собрания. № 17. <a href="#fnref-e019-3" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e019-4" class="footnote-item"><p>Авторский комментарий к изданию. <a href="#fnref-e019-4" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e019-5" class="footnote-item"><p>Предисловие. Страницы 12–14. <a href="#fnref-e019-5" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e019-6" class="footnote-item"><p>Сопоставление двух редакций текста. <a href="#fnref-e019-6" class="footnote-backref">↩︎</a></p>
</li>
</ol>
</section>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 1. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
