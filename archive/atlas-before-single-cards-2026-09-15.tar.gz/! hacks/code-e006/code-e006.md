---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e006
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e006
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e006/Description.ru]]
