---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: film
sources:
- https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/film-strip.html
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: callout-film
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-film/Description.ru]]
