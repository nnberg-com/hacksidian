---
language: ru
translation_status: complete
title: Лента наблюдений
group: ''
---

# Лента наблюдений

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-film
```

## Зачем

Сопоставить кадры одной серии и сохранить их последовательность.

## Как работает

Три Markdown-изображения в одном абзаце образуют горизонтальную ленту. Перфорацию рисует повторяющийся градиент; прокрутка нативная.

## Пояснения из HTML-атласа

Сопоставить кадры одной серии и сохранить их последовательность.

Три Markdown-изображения в одном абзаце образуют горизонтальную ленту. Перфорацию рисует повторяющийся градиент; прокрутка нативная.

Практика сообщества

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/index.html#film>)
- [Источник 1](https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/film-strip.html)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/bay-scene.svg](<./assets/assets/bay-scene.svg>)
- [assets/assets/camera.svg](<./assets/assets/camera.svg>)
- [assets/assets/station.svg](<./assets/assets/station.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
[data-callout="film"] {padding:20px 0;color:#31312d}
[data-callout="film"] > .callout-title {font-size:22px;margin-bottom:20px}
[data-callout="film"] p:first-child {display:flex;gap:10px;overflow-x:auto;padding:25px 12px;background:repeating-linear-gradient(90deg,transparent 0 10px,#f5f0e6 10px 20px,transparent 20px 30px) top 7px left / 100% 9px no-repeat,repeating-linear-gradient(90deg,transparent 0 10px,#f5f0e6 10px 20px,transparent 20px 30px) bottom 7px left / 100% 9px no-repeat,#242822}
[data-callout="film"] br {display:none}
[data-callout="film"] img {flex:0 0 190px;width:190px;height:140px;object-fit:cover}
[data-callout="film"] p:last-child {font-size:12px;letter-spacing:.02em}
```

## Данные исходного каталога

```json
{
  "key": "film",
  "title": "Лента наблюдений",
  "role": "Сопоставить кадры одной серии и сохранить их последовательность.",
  "how": "Три Markdown-изображения в одном абзаце образуют горизонтальную ленту. Перфорацию рисует повторяющийся градиент; прокрутка нативная.",
  "ref": "https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/film-strip.html",
  "limit": ""
}
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 2. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 4. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
