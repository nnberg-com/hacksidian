---
tags:
- atlas/technique
- atlas/emphasis
category: emphasis
digest: []
source_anchor: s28
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: emphasis-s28
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/emphasis-s28/Description.ru]]
