---
tags:
- atlas/technique
- atlas/heading
category: heading
digest: []
source_anchor: e017
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: heading-e017
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/heading-e017/Description.ru]]
