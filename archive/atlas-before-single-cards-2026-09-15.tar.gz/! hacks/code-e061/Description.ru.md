---
language: ru
translation_status: complete
title: Отступ у продолжения строки
group: Ширина и прокрутка
---

# Отступ у продолжения строки

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
code-e061
```

## Зачем

Отличать мягкий перенос длинной строки от начала следующей строки исходника.

## Как работает

text-indent: 2ch hanging each-line отступает перенесённые продолжения и сбрасывает отступ после настоящего перевода строки. Сравните верхний блок с обычным переносом и нижний с отступом.

## Ограничения исходного приёма

В обоих блоках одинаковый исходник. Отступ появляется только у визуальных продолжений; существующие пробелы не переписываются. Если браузер не поддерживает сочетание ключевых слов, это указано над вторым образцом.

## Пояснения из HTML-атласа

Отличать мягкий перенос длинной строки от начала следующей строки исходника.

text-indent: 2ch hanging each-line отступает перенесённые продолжения и сбрасывает отступ после настоящего перевода строки. Сравните верхний блок с обычным переносом и нижний с отступом.

В обоих блоках одинаковый исходник. Отступ появляется только у визуальных продолжений; существующие пробелы не переписываются. Если браузер не поддерживает сочетание ключевых слов, это указано над вторым образцом.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/code-styles-demo/index.html#e061>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
S pre { white-space: pre-wrap; overflow-wrap: anywhere; }
S pre::before { content: "Обычный перенос"; display: block; font: 600 11px/1.5 system-ui; margin-bottom: 12px; }
S pre:nth-of-type(2)::before { content: "hanging each-line не поддерживается: обычный перенос"; }
@supports (text-indent: 2ch hanging each-line) {
  S pre:nth-of-type(2) > code { display: block; text-indent: 2ch hanging each-line; }
  S pre:nth-of-type(2)::before { content: "Продолжение с отступом 2ch"; }
}
```

## Данные исходного каталога

```json
{
  "id": "e061",
  "group": "flow",
  "title": "Отступ у продолжения строки",
  "why": "Отличать мягкий перенос длинной строки от начала следующей строки исходника.",
  "how": "text-indent: 2ch hanging each-line отступает перенесённые продолжения и сбрасывает отступ после настоящего перевода строки. Сравните верхний блок с обычным переносом и нижний с отступом.",
  "note": "В обоих блоках одинаковый исходник. Отступ появляется только у визуальных продолжений; существующие пробелы не переписываются. Если браузер не поддерживает сочетание ключевых слов, это указано над вторым образцом.",
  "kind": "Зависит от браузера"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<pre><code>GET /api/search?query=markdown&amp;include=examples,notes,references&amp;sort=updated_at&amp;direction=descending HTTP/1.1
Authorization: Bearer example_token_for_documentation_only
Accept: application/json

{&quot;status&quot;:&quot;ok&quot;,&quot;message&quot;:&quot;A deliberately long response that demonstrates horizontal scrolling and soft wrapping without changing the source text.&quot;}
</code></pre><pre><code>GET /api/search?query=markdown&amp;include=examples,notes,references&amp;sort=updated_at&amp;direction=descending HTTP/1.1
Authorization: Bearer example_token_for_documentation_only
Accept: application/json

{&quot;status&quot;:&quot;ok&quot;,&quot;message&quot;:&quot;A deliberately long response that demonstrates horizontal scrolling and soft wrapping without changing the source text.&quot;}
</code></pre>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 1. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
