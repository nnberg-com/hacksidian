---
tags:
- atlas/technique
- atlas/emphasis
category: emphasis
digest: []
source_anchor: s32
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: emphasis-s32
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/emphasis-s32/Description.ru]]
