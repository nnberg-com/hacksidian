---
language: ru
translation_status: complete
title: Развёрнутая сноска при печати
group: Сложное содержимое и среда
---

# Развёрнутая сноска при печати

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Зачем

Все примечания попадают в печатную версию.

## Как работает

@media print отменяет fixed, скрытие, ограничение высоты и анимацию.

## Демонстрация

Нажмите номер сноски, затем стрелку ↩ в примечании.

## Ограничения исходного приёма

В печати это концевые примечания. Распределение сносок по низу каждой печатной страницы обычный браузер здесь не выполняет.

Обычный CSS

## Пояснения из HTML-атласа

Как @media print отменяет fixed, скрытие, ограничение высоты и анимацию.

Зачем Все примечания попадают в печатную версию.

Условие В печати это концевые примечания. Распределение сносок по низу каждой печатной страницы обычный браузер здесь не выполняет.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/footnote-styles-demo/index.html#e053>)
- [Источник 1](https://github.com/markdown-it/markdown-it-footnote)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Общие условия исходного раздела

Подсветка и нижняя панель основаны на опубликованных приёмах. Варианты оформления и сочетания с :has() и якорями — адаптации для HTML выбранного Markdown-рендерера.

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@media screen {.e053 .footnote-item:target {position:fixed;z-index:30;box-sizing:border-box;max-block-size:42dvh;overflow:auto;padding:1.25rem 1.5rem 1.25rem 2.5rem;background:var(--paper);color:var(--ink);border:1px solid var(--line);box-shadow:0 12px 50px #0003;inset:auto 1rem 1rem;}}
@media print {.e053 .footnote-item {position:static!important;visibility:visible!important;opacity:1!important;max-height:none!important;overflow:visible!important;animation:none!important;break-inside:avoid;}
.e053 .footnote-backref {display:none;}}
```

## Данные исходного каталога

```json
{
  "id": "e053",
  "title": "Развёрнутая сноска при печати",
  "how": "@media print отменяет fixed, скрытие, ограничение высоты и анимацию.",
  "why": "Все примечания попадают в печатную версию.",
  "action": "Нажмите номер сноски, затем стрелку ↩ в примечании.",
  "limit": "В печати это концевые примечания. Распределение сносок по низу каждой печатной страницы обычный браузер здесь не выполняет.",
  "support": "Обычный CSS",
  "group": "resilience"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<p>Короткое уточнение может соседствовать с развёрнутым комментарием.<sup class="footnote-ref"><a href="#fn-e053-1" id="fnref-e053-1">[1]</a></sup> Ссылка на источник тоже остаётся обычной сноской.<sup class="footnote-ref"><a href="#fn-e053-2" id="fnref-e053-2">[2]</a></sup></p>
<hr class="footnotes-sep">
<section class="footnotes">
<ol class="footnotes-list">
<li id="fn-e053-1" class="footnote-item"><p><strong>Главная мысль примечания.</strong> Здесь есть <em>курсив</em> и несколько абзацев.</p>
<p>Второй абзац принадлежит той же сноске. Он не должен выглядеть как отдельное примечание.</p>
<ul>
<li>Первый довод.</li>
<li>Второй довод с <code>inline code</code>.</li>
</ul>
 <a href="#fnref-e053-1" class="footnote-backref">↩︎</a></li>
<li id="fn-e053-2" class="footnote-item"><p>Документация <a href="https://github.com/markdown-it/markdown-it-footnote">Markdown-it Footnote</a>. Длинные адреса и названия тоже должны помещаться в колонку. <a href="#fnref-e053-2" class="footnote-backref">↩︎</a></p>
</li>
</ol>
</section>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 3. Используется штатных переменных: 3. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
