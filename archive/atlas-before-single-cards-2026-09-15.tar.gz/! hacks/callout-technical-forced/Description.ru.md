---
language: ru
translation_status: complete
title: Высокий контраст
group: Среда и состояния
---

# Высокий контраст

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-forced
```

## Зачем

Примечание сохраняет границу и название при системных цветах.

## Как работает

forced-colors заменяет декоративную палитру системными цветами.

## Ограничения исходного приёма

Проверяется эмуляцией forced-colors. Значение типа остаётся написано в заголовке, а не передаётся одним цветом.

## Пояснения из HTML-атласа

ЗачемПримечание сохраняет границу и название при системных цветах.

Какforced-colors заменяет декоративную палитру системными цветами.

Проверяется эмуляцией forced-colors. Значение типа остаётся написано в заголовке, а не передаётся одним цветом.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#forced>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@media (forced-colors:active) {@box {background:Canvas;color:CanvasText;border:1px solid CanvasText} @title {color:CanvasText} @icon {color:CanvasText;background:Canvas}}
```

## Данные исходного каталога

```json
{
  "group": "states",
  "key": "forced",
  "title": "Высокий контраст",
  "why": "Примечание сохраняет границу и название при системных цветах.",
  "how": "forced-colors заменяет декоративную палитру системными цветами.",
  "profile": "obsidian",
  "type": "note",
  "note": "Проверяется эмуляцией forced-colors. Значение типа остаётся написано в заголовке, а не передаётся одним цветом.",
  "source": "https://help.obsidian.md/callouts",
  "n": 72,
  "id": "c072"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="note" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Обратите внимание</div></div><div class="callout-content">
<p>Изменения вступят в силу после повторного открытия файла. <strong>Сохраните результат</strong>, прежде чем продолжить.</p>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 0. Случаев для отдельного решения: 1. [baseline.json](./baseline.json) · [Default.css](./Default.css)
