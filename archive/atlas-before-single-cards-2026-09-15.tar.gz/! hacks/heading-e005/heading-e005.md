---
tags:
- atlas/technique
- atlas/heading
category: heading
digest: []
source_anchor: e005
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: heading-e005
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/heading-e005/Description.ru]]
