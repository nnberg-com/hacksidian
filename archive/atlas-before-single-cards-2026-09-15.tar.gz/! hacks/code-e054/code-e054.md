---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e054
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e054
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e054/Description.ru]]
