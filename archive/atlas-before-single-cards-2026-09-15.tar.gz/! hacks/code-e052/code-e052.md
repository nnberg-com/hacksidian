---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e052
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e052
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e052/Description.ru]]
