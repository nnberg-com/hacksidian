---
language: ru
translation_status: complete
title: 27 · Обвести слово
group: ''
---

# 27 · Обвести слово

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
emphasis-s27
```

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/emphasis-styles-demo/index.html#s27>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
mark { display: inline-block; position: relative;
  background: transparent; padding: 0 .3em; }
mark::before { content: ''; position: absolute; inset: .02em -.1em;
  border: 1.5px solid var(--accent); border-radius: 50%;
  transform: rotate(-6deg); pointer-events: none; }
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 2. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
