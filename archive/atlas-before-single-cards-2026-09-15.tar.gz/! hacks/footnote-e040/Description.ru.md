---
language: ru
translation_status: complete
title: Предпросмотр внизу
group: Предпросмотр при наведении
---

# Предпросмотр внизу

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Зачем

Быстро посмотреть короткую ремарку.

## Как работает

Общий контейнер через :has() реагирует на номер; связанный li становится фиксированным.

## Демонстрация

Наведите на [1] или [2]. На сенсорном экране нажмите номер для обычного перехода.

## Ограничения исходного приёма

После ухода с номера карточка исчезает. Для интерактивного содержимого используйте вариант с задержкой или клик.

:has()

## Пояснения из HTML-атласа

Как Общий контейнер через :has() реагирует на номер; связанный li становится фиксированным.

Зачем Быстро посмотреть короткую ремарку.

Условие После ухода с номера карточка исчезает. Для интерактивного содержимого используйте вариант с задержкой или клик.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/footnote-styles-demo/index.html#e040>)
- [Источник 1](https://github.com/markdown-it/markdown-it-footnote)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Общие условия исходного раздела

Подсветка и нижняя панель основаны на опубликованных приёмах. Варианты оформления и сочетания с :has() и якорями — адаптации для HTML выбранного Markdown-рендерера.

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@media screen and (hover:hover) {.e040:has(a[href="#fn-e040-1"]:is(:hover,:focus-visible)) #fn-e040-1 {position:fixed;z-index:30;box-sizing:border-box;max-block-size:42dvh;overflow:auto;padding:1.25rem 1.5rem 1.25rem 2.5rem;background:var(--paper);color:var(--ink);border:1px solid var(--line);box-shadow:0 12px 50px #0003;inset:auto 1rem 1rem auto;inline-size:min(30rem,calc(100% - 2rem));border-radius:.6rem;}}
@media screen and (hover:hover) {.e040:has(a[href="#fn-e040-2"]:is(:hover,:focus-visible)) #fn-e040-2 {position:fixed;z-index:30;box-sizing:border-box;max-block-size:42dvh;overflow:auto;padding:1.25rem 1.5rem 1.25rem 2.5rem;background:var(--paper);color:var(--ink);border:1px solid var(--line);box-shadow:0 12px 50px #0003;inset:auto 1rem 1rem auto;inline-size:min(30rem,calc(100% - 2rem));border-radius:.6rem;}}
```

## Данные исходного каталога

```json
{
  "id": "e040",
  "title": "Предпросмотр внизу",
  "how": "Общий контейнер через :has() реагирует на номер; связанный li становится фиксированным.",
  "why": "Быстро посмотреть короткую ремарку.",
  "action": "Наведите на [1] или [2]. На сенсорном экране нажмите номер для обычного перехода.",
  "limit": "После ухода с номера карточка исчезает. Для интерактивного содержимого используйте вариант с задержкой или клик.",
  "support": ":has()",
  "group": "hover"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<p>Короткое уточнение может соседствовать с развёрнутым комментарием.<sup class="footnote-ref"><a href="#fn-e040-1" id="fnref-e040-1">[1]</a></sup> Ссылка на источник тоже остаётся обычной сноской.<sup class="footnote-ref"><a href="#fn-e040-2" id="fnref-e040-2">[2]</a></sup></p>
<hr class="footnotes-sep">
<section class="footnotes">
<ol class="footnotes-list">
<li id="fn-e040-1" class="footnote-item"><p><strong>Главная мысль примечания.</strong> Здесь есть <em>курсив</em> и несколько абзацев.</p>
<p>Второй абзац принадлежит той же сноске. Он не должен выглядеть как отдельное примечание.</p>
<ul>
<li>Первый довод.</li>
<li>Второй довод с <code>inline code</code>.</li>
</ul>
 <a href="#fnref-e040-1" class="footnote-backref">↩︎</a></li>
<li id="fn-e040-2" class="footnote-item"><p>Документация <a href="https://github.com/markdown-it/markdown-it-footnote">Markdown-it Footnote</a>. Длинные адреса и названия тоже должны помещаться в колонку. <a href="#fnref-e040-2" class="footnote-backref">↩︎</a></p>
</li>
</ol>
</section>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 6. Используется штатных переменных: 3. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
