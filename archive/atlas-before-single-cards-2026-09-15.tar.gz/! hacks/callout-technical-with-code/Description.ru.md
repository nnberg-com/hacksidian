---
language: ru
translation_status: complete
title: Note с кодом получает другой фон
group: Контекст и длинный текст
---

# Note с кодом получает другой фон

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-with-code
```

## Зачем

Технические примечания отличаются по содержимому, без ручного класса.

## Как работает

has(pre) выбирает Callout, внутри которого рендерер создал блок кода.

## Пояснения из HTML-атласа

ЗачемТехнические примечания отличаются по содержимому, без ручного класса.

Какhas(pre) выбирает Callout, внутри которого рендерер создал блок кода.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#with-code>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@box:has(pre) {background:var(--paper);border:1px solid var(--tone)} @body pre {background:var(--wash);padding:.7em;overflow:auto}
```

## Данные исходного каталога

```json
{
  "group": "detail",
  "key": "with-code",
  "title": "Note с кодом получает другой фон",
  "why": "Технические примечания отличаются по содержимому, без ручного класса.",
  "how": "has(pre) выбирает Callout, внутри которого рендерер создал блок кода.",
  "profile": "obsidian",
  "type": "note",
  "note": "",
  "source": "https://help.obsidian.md/callouts",
  "n": 61,
  "id": "c061"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="note" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Обратите внимание</div></div><div class="callout-content">
<p>Минимальное правило:</p>
<pre><code class="language-css" data-line="3">.callout { border-radius: 0; }
</code></pre>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 3. Используется штатных переменных: 3. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
