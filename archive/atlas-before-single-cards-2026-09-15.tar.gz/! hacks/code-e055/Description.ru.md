---
language: ru
translation_status: complete
title: Адаптация на узком экране
group: Среда отображения
---

# Адаптация на узком экране

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
code-e055
```

## Зачем

Уменьшить поля и переносить текст при недостатке места.

## Как работает

Media query срабатывает при ширине окна до 600px.

## Ограничения исходного приёма

Уменьшите окно браузера. Для ASCII-схем такой перенос не подходит.

## Пояснения из HTML-атласа

Уменьшить поля и переносить текст при недостатке места.

Media query срабатывает при ширине окна до 600px.

Уменьшите окно браузера. Для ASCII-схем такой перенос не подходит.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/code-styles-demo/index.html#e055>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@media (max-width: 600px) { S pre { padding: 12px; white-space: pre-wrap; overflow-wrap: anywhere; } }
```

## Данные исходного каталога

```json
{
  "id": "e055",
  "group": "adaptive",
  "title": "Адаптация на узком экране",
  "why": "Уменьшить поля и переносить текст при недостатке места.",
  "how": "Media query срабатывает при ширине окна до 600px.",
  "note": "Уменьшите окно браузера. Для ASCII-схем такой перенос не подходит.",
  "kind": "Обычный Markdown"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<pre><code>GET /api/search?query=markdown&amp;include=examples,notes,references&amp;sort=updated_at&amp;direction=descending HTTP/1.1
Authorization: Bearer example_token_for_documentation_only
Accept: application/json

{&quot;status&quot;:&quot;ok&quot;,&quot;message&quot;:&quot;A deliberately long response that demonstrates horizontal scrolling and soft wrapping without changing the source text.&quot;}
</code></pre>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 1. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
