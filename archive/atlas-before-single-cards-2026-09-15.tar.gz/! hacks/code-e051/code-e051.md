---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e051
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e051
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e051/Description.ru]]
