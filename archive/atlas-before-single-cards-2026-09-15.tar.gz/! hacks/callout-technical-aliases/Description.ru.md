---
language: ru
translation_status: complete
title: Алиас сохраняет назначение
group: Композиция блока
---

# Алиас сохраняет назначение

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-aliases
```

## Зачем

Один стиль для разных допустимых имён типа.

## Как работает

Атрибут содержит исходное имя; объединённый селектор оформляет tip, hint и important.

## Ограничения исходного приёма

GitHub IMPORTANT — отдельный тип. Его нельзя автоматически считать аналогом Obsidian important.

## Пояснения из HTML-атласа

ЗачемОдин стиль для разных допустимых имён типа.

КакАтрибут содержит исходное имя; объединённый селектор оформляет tip, hint и important.

GitHub IMPORTANT — отдельный тип. Его нельзя автоматически считать аналогом Obsidian important.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#aliases>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
& .callout:is([data-callout="tip"],[data-callout="hint"],[data-callout="important"]) {border-block-start:3px solid var(--tone)}
```

## Данные исходного каталога

```json
{
  "group": "layout",
  "key": "aliases",
  "title": "Алиас сохраняет назначение",
  "why": "Один стиль для разных допустимых имён типа.",
  "how": "Атрибут содержит исходное имя; объединённый селектор оформляет tip, hint и important.",
  "profile": "obsidian",
  "type": "hint",
  "note": "GitHub IMPORTANT — отдельный тип. Его нельзя автоматически считать аналогом Obsidian important.",
  "source": "https://help.obsidian.md/callouts",
  "n": 48,
  "id": "c048"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="hint" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Подсказка</div></div><div class="callout-content">
<p>В Obsidian hint и important — алиасы tip.</p>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 1. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
