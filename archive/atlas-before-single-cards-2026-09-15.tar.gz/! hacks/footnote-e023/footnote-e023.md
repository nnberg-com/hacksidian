---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e023
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: footnote-e023
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e023/Description.ru]]
