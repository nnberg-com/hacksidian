---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: tree
sources:
- https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/family-tree.html
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-tree
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-tree/Description.ru]]
