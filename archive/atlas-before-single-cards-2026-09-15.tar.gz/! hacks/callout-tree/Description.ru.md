---
language: ru
translation_status: complete
title: Дерево архива
group: ''
---

# Дерево архива

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-tree
```

## Зачем

Показать вложенность и принадлежность материалов без отдельной диаграммы.

## Как работает

Уровни Markdown-списка создают дерево. Границы и псевдоэлементы соединяют узлы; на экране остаются настоящие списки и ссылки.

## Ограничения исходного приёма

Здесь адаптация идеи дерева: иерархия архива вместо родословной. Произвольные связи между ветвями CSS не строит.

## Пояснения из HTML-атласа

Показать вложенность и принадлежность материалов без отдельной диаграммы.

Уровни Markdown-списка создают дерево. Границы и псевдоэлементы соединяют узлы; на экране остаются настоящие списки и ссылки.

Здесь адаптация идеи дерева: иерархия архива вместо родословной. Произвольные связи между ветвями CSS не строит.

Практика сообщества

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/index.html#tree>)
- [Источник 1](https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/family-tree.html)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
[data-callout="tree"] {padding:24px;background:#1d302c;color:#deede5;border-radius:6px}
[data-callout="tree"] > .callout-title {font-size:13px;text-transform:uppercase;letter-spacing:.1em;color:#9ac9b0;margin-bottom:20px}
[data-callout="tree"] ul {list-style:none;padding-left:21px;margin:8px 0}
[data-callout="tree"] > .callout-content > ul {padding-left:0}
[data-callout="tree"] li {position:relative;padding:7px 0;font-size:14px}
[data-callout="tree"] ul ul {border-left:1px solid #5c8170}
[data-callout="tree"] ul ul > li::before {content:"";position:absolute;left:-21px;top:19px;width:15px;border-top:1px solid #5c8170}
```

## Данные исходного каталога

```json
{
  "key": "tree",
  "title": "Дерево архива",
  "role": "Показать вложенность и принадлежность материалов без отдельной диаграммы.",
  "how": "Уровни Markdown-списка создают дерево. Границы и псевдоэлементы соединяют узлы; на экране остаются настоящие списки и ссылки.",
  "ref": "https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/family-tree.html",
  "limit": "Здесь адаптация идеи дерева: иерархия архива вместо родословной. Произвольные связи между ветвями CSS не строит."
}
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 2. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 6. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
