---
tags:
- atlas/technique
- atlas/heading
category: heading
digest: []
source_anchor: e011
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: heading-e011
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/heading-e011/Description.ru]]
