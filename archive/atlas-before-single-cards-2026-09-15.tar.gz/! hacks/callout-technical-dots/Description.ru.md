---
language: ru
translation_status: complete
title: Точечный фон Callout
group: Декоративные варианты
---

# Точечный фон Callout

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-dots
```

## Зачем

Лёгкая записка, отличимая от основного текста.

## Как работает

Радиальный градиент повторяется на фоне контейнера; контраст точек невысокий.

## Пояснения из HTML-атласа

ЗачемЛёгкая записка, отличимая от основного текста.

КакРадиальный градиент повторяется на фоне контейнера; контраст точек невысокий.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#dots>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@box {background-color:var(--paper);background-image:radial-gradient(var(--edge) .7px,transparent .7px);background-size:10px 10px;border:1px solid var(--edge)}
```

## Данные исходного каталога

```json
{
  "group": "finish",
  "key": "dots",
  "title": "Точечный фон Callout",
  "why": "Лёгкая записка, отличимая от основного текста.",
  "how": "Радиальный градиент повторяется на фоне контейнера; контраст точек невысокий.",
  "profile": "obsidian",
  "type": "note",
  "note": "",
  "source": "https://help.obsidian.md/callouts",
  "n": 66,
  "id": "c066"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="note" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Обратите внимание</div></div><div class="callout-content">
<p>Изменения вступят в силу после повторного открытия файла. <strong>Сохраните результат</strong>, прежде чем продолжить.</p>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 3. Используется штатных переменных: 2. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 0. Случаев для отдельного решения: 2. [baseline.json](./baseline.json) · [Default.css](./Default.css)
