---
language: ru
translation_status: complete
title: Значок в круге
group: Заголовок и значок
---

# Значок в круге

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-icon-disc
```

## Зачем

Подсказка с хорошо различимым символом.

## Как работает

Контейнер значка получает круглый фон; его ::before рисует знак через CSS-маску.

## Пояснения из HTML-атласа

ЗачемПодсказка с хорошо различимым символом.

КакКонтейнер значка получает круглый фон; его ::before рисует знак через CSS-маску.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#icon-disc>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@icon {mask:none;background:var(--tone);color:var(--paper);border-radius:50%;width:1.8em;height:1.8em;padding:.35em} @icon::before {content:"";display:block;width:100%;height:100%;background:currentColor;mask:var(--glyph) center/contain no-repeat} @title {align-items:center}
```

## Данные исходного каталога

```json
{
  "group": "title",
  "key": "icon-disc",
  "title": "Значок в круге",
  "why": "Подсказка с хорошо различимым символом.",
  "how": "Контейнер значка получает круглый фон; его ::before рисует знак через CSS-маску.",
  "profile": "obsidian",
  "type": "tip",
  "note": "",
  "source": "https://help.obsidian.md/callouts",
  "n": 36,
  "id": "c036"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="tip" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Обратите внимание</div></div><div class="callout-content">
<p>Изменения вступят в силу после повторного открытия файла. <strong>Сохраните результат</strong>, прежде чем продолжить.</p>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 2. Используется штатных переменных: 2. Геометрия и механика эффекта сохранены. Требуют отдельного решения: embedded-asset; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
