---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: receipt
sources:
- https://github.com/emarpiee/Retroma/blob/main/assets/examples/retroma-retro-callouts.md
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-receipt
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-receipt/Description.ru]]
