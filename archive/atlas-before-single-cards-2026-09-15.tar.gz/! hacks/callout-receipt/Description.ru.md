---
language: ru
translation_status: complete
title: Чек экспедиции
group: ''
---

# Чек экспедиции

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-receipt
```

## Зачем

Показать короткий итог расходов в узнаваемой форме бумажного чека.

## Как работает

Таблица хранит позиции и суммы. Моноширинный шрифт выравнивает цифры; clip-path формирует отрывной край, а разделители Markdown становятся пунктирными линиями.

## Ограничения исходного приёма

Суммы и итог введены вручную: CSS не выполняет бухгалтерские вычисления. Чек учебный.

## Пояснения из HTML-атласа

Показать короткий итог расходов в узнаваемой форме бумажного чека.

Таблица хранит позиции и суммы. Моноширинный шрифт выравнивает цифры; clip-path формирует отрывной край, а разделители Markdown становятся пунктирными линиями.

Суммы и итог введены вручную: CSS не выполняет бухгалтерские вычисления. Чек учебный.

emarpiee · Retroma

От источника — предметный формат бумажного чека. Реализованы собственные края, таблица и типографика. Класс-переключатель Style Manager не нужен: CSS выбирает только тип callout.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/index.html#receipt>)
- [Источник 1](https://github.com/emarpiee/Retroma/blob/main/assets/examples/retroma-retro-callouts.md)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
[data-callout="receipt"] {max-width:350px;margin-inline:auto;background:#fffdf3;color:#252821;padding:30px 23px 36px;font:13px/1.6 "Courier New",monospace;filter:drop-shadow(0 7px 5px #302a2020);clip-path:polygon(0 0,100% 0,100% 98%,95% 100%,90% 98%,85% 100%,80% 98%,75% 100%,70% 98%,65% 100%,60% 98%,55% 100%,50% 98%,45% 100%,40% 98%,35% 100%,30% 98%,25% 100%,20% 98%,15% 100%,10% 98%,5% 100%,0 98%);border-top:5px solid #252821}
[data-callout="receipt"] > .callout-title {text-align:center;font-size:17px;letter-spacing:.06em;line-height:1.35}
[data-callout="receipt"] > .callout-content > p:first-child {text-align:center;font-size:10px;margin:12px 0 22px}
[data-callout="receipt"] hr {border:0;border-top:1px dashed #737769;margin:18px 0}
[data-callout="receipt"] table {width:100%;font-size:12px}
[data-callout="receipt"] th {text-align:left;font-weight:400;border-bottom:1px dotted #737769;padding-bottom:8px}
[data-callout="receipt"] td {padding:8px 0}
[data-callout="receipt"] th:last-child,[data-callout="receipt"] td:last-child {text-align:right;white-space:nowrap;padding-left:12px}
[data-callout="receipt"] > .callout-content > p:has(strong) {font-size:23px;text-align:right}
[data-callout="receipt"] > .callout-content > p:last-child {text-align:center;font-size:10px;margin-top:25px}
```

## Данные исходного каталога

```json
{
  "key": "receipt",
  "title": "Чек экспедиции",
  "role": "Показать короткий итог расходов в узнаваемой форме бумажного чека.",
  "how": "Таблица хранит позиции и суммы. Моноширинный шрифт выравнивает цифры; clip-path формирует отрывной край, а разделители Markdown становятся пунктирными линиями.",
  "ref": "https://github.com/emarpiee/Retroma/blob/main/assets/examples/retroma-retro-callouts.md",
  "limit": "Суммы и итог введены вручную: CSS не выполняет бухгалтерские вычисления. Чек учебный.",
  "author": "emarpiee · Retroma",
  "adaptation": "От источника — предметный формат бумажного чека. Реализованы собственные края, таблица и типографика. Класс-переключатель Style Manager не нужен: CSS выбирает только тип callout."
}
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 7. Используется штатных переменных: 3. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 9. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
