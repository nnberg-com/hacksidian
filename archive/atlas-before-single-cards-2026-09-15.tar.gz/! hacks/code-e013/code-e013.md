---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e013
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e013
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e013/Description.ru]]
