---
language: ru
translation_status: complete
title: Оформление раскрытого Callout
group: Среда и состояния
---

# Оформление раскрытого Callout

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-fold-open
```

## Зачем

Начальное состояние [!note]+ в Obsidian.

## Как работает

Парсер сохраняет + в data-callout-fold. CSS добавляет к заголовку декоративный индикатор.

## Ограничения исходного приёма

Статическое состояние. Нажатие на заголовок здесь не переключает блок: в Obsidian это поведение приложения, а не CSS.

## Пояснения из HTML-атласа

ЗачемНачальное состояние [!note]+ в Obsidian.

КакПарсер сохраняет + в data-callout-fold. CSS добавляет к заголовку декоративный индикатор.

Статическое состояние. Нажатие на заголовок здесь не переключает блок: в Obsidian это поведение приложения, а не CSS.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#fold-open>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@box[data-callout-fold="+"] {border:1px solid var(--edge)} @box[data-callout-fold="+"] > .callout-title::after {content:"⌄";margin-inline-start:auto}
```

## Данные исходного каталога

```json
{
  "group": "states",
  "key": "fold-open",
  "title": "Оформление раскрытого Callout",
  "why": "Начальное состояние [!note]+ в Obsidian.",
  "how": "Парсер сохраняет + в data-callout-fold. CSS добавляет к заголовку декоративный индикатор.",
  "profile": "obsidian",
  "type": "note",
  "note": "Статическое состояние. Нажатие на заголовок здесь не переключает блок: в Obsidian это поведение приложения, а не CSS.",
  "source": "https://help.obsidian.md/callouts",
  "n": 69,
  "id": "c069"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="note" data-callout-fold="+" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Раскрыто по умолчанию</div></div><div class="callout-content">
<p>Содержимое видно при открытии заметки.</p>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 1. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
