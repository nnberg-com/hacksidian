---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: inline
sources:
- https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#alerts
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-technical-inline
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-technical-inline/Description.ru]]
