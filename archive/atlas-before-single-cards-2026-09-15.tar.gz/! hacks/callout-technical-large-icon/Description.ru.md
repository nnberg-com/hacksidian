---
language: ru
translation_status: complete
title: Крупный значок рядом с текстом
group: Заголовок и значок
---

# Крупный значок рядом с текстом

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-large-icon
```

## Зачем

Короткое предупреждение, узнаваемое по силуэту.

## Как работает

У блока оставлено место слева, SVG увеличен и вынесен из потока.

## Пояснения из HTML-атласа

ЗачемКороткое предупреждение, узнаваемое по силуэту.

КакУ блока оставлено место слева, SVG увеличен и вынесен из потока.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#large-icon>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@box {position:relative;padding-inline-start:4.5em;min-height:7em} @icon {position:absolute;inset:1em auto auto .7em;width:2.5em;height:2.5em}
```

## Данные исходного каталога

```json
{
  "group": "title",
  "key": "large-icon",
  "title": "Крупный значок рядом с текстом",
  "why": "Короткое предупреждение, узнаваемое по силуэту.",
  "how": "У блока оставлено место слева, SVG увеличен и вынесен из потока.",
  "profile": "obsidian",
  "type": "warning",
  "note": "",
  "source": "https://help.obsidian.md/callouts",
  "n": 39,
  "id": "c039"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="warning" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Обратите внимание</div></div><div class="callout-content">
<p>Изменения вступят в силу после повторного открытия файла. <strong>Сохраните результат</strong>, прежде чем продолжить.</p>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
