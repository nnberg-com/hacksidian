---
tags:
- atlas/technique
- atlas/emphasis
category: emphasis
digest: []
source_anchor: s33
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: emphasis-s33
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/emphasis-s33/Description.ru]]
