---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e041
sources:
- https://github.com/markdown-it/markdown-it-footnote
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: footnote-e041
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e041/Description.ru]]
