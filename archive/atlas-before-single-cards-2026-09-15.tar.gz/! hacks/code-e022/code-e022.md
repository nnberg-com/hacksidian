---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e022
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: code-e022
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e022/Description.ru]]
