---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e024
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: code-e024
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e024/Description.ru]]
