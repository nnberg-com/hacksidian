---
language: ru
translation_status: complete
title: Тени слева и справа
group: Ширина и прокрутка
---

# Тени слева и справа

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
code-e024
```

## Зачем

Подсказать, что за краем есть продолжение строки.

## Как работает

Четыре фона: два покрытия с attachment: local и две тени с attachment: scroll.

## Ограничения исходного приёма

Прокрутите в обе стороны: тень исчезает у достигнутого края. Покрытия рассчитаны на однотонный фон.

## Пояснения из HTML-атласа

Подсказать, что за краем есть продолжение строки.

Четыре фона: два покрытия с attachment: local и две тени с attachment: scroll.

Прокрутите в обе стороны: тень исчезает у достигнутого края. Покрытия рассчитаны на однотонный фон.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/code-styles-demo/index.html#e024>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
S pre {
  background: linear-gradient(to right, #f4f3ee 35%, #f4f3ee00) left / 36px 100% no-repeat local,
    linear-gradient(to left, #f4f3ee 35%, #f4f3ee00) right / 36px 100% no-repeat local,
    linear-gradient(to right, #263d3238, transparent) left / 12px 100% no-repeat scroll,
    linear-gradient(to left, #263d3238, transparent) right / 12px 100% no-repeat scroll;
  background-color: #f4f3ee; overflow: auto;
}
```

## Данные исходного каталога

```json
{
  "id": "e024",
  "group": "flow",
  "title": "Тени слева и справа",
  "why": "Подсказать, что за краем есть продолжение строки.",
  "how": "Четыре фона: два покрытия с attachment: local и две тени с attachment: scroll.",
  "note": "Прокрутите в обе стороны: тень исчезает у достигнутого края. Покрытия рассчитаны на однотонный фон.",
  "kind": "Обычный Markdown"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<pre><code>GET /api/search?query=markdown&amp;include=examples,notes,references&amp;sort=updated_at&amp;direction=descending HTTP/1.1
Authorization: Bearer example_token_for_documentation_only
Accept: application/json

{&quot;status&quot;:&quot;ok&quot;,&quot;message&quot;:&quot;A deliberately long response that demonstrates horizontal scrolling and soft wrapping without changing the source text.&quot;}
</code></pre>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
