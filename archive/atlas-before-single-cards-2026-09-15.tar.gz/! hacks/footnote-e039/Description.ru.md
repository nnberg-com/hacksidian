---
language: ru
translation_status: complete
title: Панель с анимацией входа
group: Панель по нажатию
---

# Панель с анимацией входа

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Зачем

Помочь заметить примечание внизу экрана.

## Как работает

Небольшой translateY и opacity обозначают появление панели.

## Демонстрация

Нажмите номер сноски, затем стрелку ↩ в примечании.

## Ограничения исходного приёма

Обычный CSS

## Пояснения из HTML-атласа

Как Небольшой translateY и opacity обозначают появление панели.

Зачем Помочь заметить примечание внизу экрана.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/footnote-styles-demo/index.html#e039>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Общие условия исходного раздела

Подсветка и нижняя панель основаны на опубликованных приёмах. Варианты оформления и сочетания с :has() и якорями — адаптации для HTML выбранного Markdown-рендерера.

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@media screen {.e039 .footnote-item:target {position:fixed;z-index:30;box-sizing:border-box;max-block-size:42dvh;overflow:auto;padding:1.25rem 1.5rem 1.25rem 2.5rem;background:var(--paper);color:var(--ink);border:1px solid var(--line);box-shadow:0 12px 50px #0003;inset:auto 1rem 1rem;animation:panel-e039 .2s ease-out;} }
@keyframes panel-e039 {from {opacity:0;transform:translateY(.6rem);} }
@media(prefers-reduced-motion:reduce) {.e039 .footnote-item:target {animation:none;}}
```

## Данные исходного каталога

```json
{
  "id": "e039",
  "title": "Панель с анимацией входа",
  "how": "Небольшой translateY и opacity обозначают появление панели.",
  "why": "Помочь заметить примечание внизу экрана.",
  "action": "Нажмите номер сноски, затем стрелку ↩ в примечании.",
  "limit": "",
  "support": "Обычный CSS",
  "group": "panels"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<p>Хорошая сноска оставляет подробность рядом с мыслью,<sup class="footnote-ref"><a href="#fn-e039-1" id="fnref-e039-1">[1]</a></sup> не перегружая само предложение. Второе примечание помогает сравнить оформление.<sup class="footnote-ref"><a href="#fn-e039-2" id="fnref-e039-2">[2]</a></sup></p>
<hr class="footnotes-sep">
<section class="footnotes">
<ol class="footnotes-list">
<li id="fn-e039-1" class="footnote-item"><p>Уточнение к основному тексту. Его можно прочитать отдельно и вернуться по стрелке. <a href="#fnref-e039-1" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e039-2" class="footnote-item"><p>Источник или короткая авторская ремарка. <a href="#fnref-e039-2" class="footnote-backref">↩︎</a></p>
</li>
</ol>
</section>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 3. Используется штатных переменных: 3. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
