---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e057
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: code-e057
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e057/Description.ru]]
