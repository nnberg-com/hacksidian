---
language: ru
translation_status: complete
title: Две газетные колонки
group: Колонки и сетки
---

# Две газетные колонки

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
footnote-e033
```

## Зачем

Много небольших библиографических примечаний.

## Как работает

columns:2; break-inside:avoid удерживает короткий пункт целиком.

## Демонстрация

Сравните номер в тексте и примечания ниже.

## Ограничения исходного приёма

Чтение идёт вниз по левой колонке, затем по правой.

Обычный CSS

## Пояснения из HTML-атласа

Как columns:2; break-inside:avoid удерживает короткий пункт целиком.

Зачем Много небольших библиографических примечаний.

Условие Чтение идёт вниз по левой колонке, затем по правой.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/footnote-styles-demo/index.html#e033>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Общие условия исходного раздела

Подсветка и нижняя панель основаны на опубликованных приёмах. Варианты оформления и сочетания с :has() и якорями — адаптации для HTML выбранного Markdown-рендерера.

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
.e033 .footnotes-list {columns:2;column-gap:2.5rem;}
.e033 .footnote-item {break-inside:avoid;}
@media(max-width:600px) {.e033 .footnotes-list {columns:1;}}
```

## Данные исходного каталога

```json
{
  "id": "e033",
  "title": "Две газетные колонки",
  "how": "columns:2; break-inside:avoid удерживает короткий пункт целиком.",
  "why": "Много небольших библиографических примечаний.",
  "action": "Сравните номер в тексте и примечания ниже.",
  "limit": "Чтение идёт вниз по левой колонке, затем по правой.",
  "support": "Обычный CSS",
  "group": "columns"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<p>В этом фрагменте собраны короткие источники: первый,<sup class="footnote-ref"><a href="#fn-e033-1" id="fnref-e033-1">[1]</a></sup> второй,<sup class="footnote-ref"><a href="#fn-e033-2" id="fnref-e033-2">[2]</a></sup> третий,<sup class="footnote-ref"><a href="#fn-e033-3" id="fnref-e033-3">[3]</a></sup> четвёртый,<sup class="footnote-ref"><a href="#fn-e033-4" id="fnref-e033-4">[4]</a></sup> пятый<sup class="footnote-ref"><a href="#fn-e033-5" id="fnref-e033-5">[5]</a></sup> и шестой.<sup class="footnote-ref"><a href="#fn-e033-6" id="fnref-e033-6">[6]</a></sup></p>
<hr class="footnotes-sep">
<section class="footnotes">
<ol class="footnotes-list">
<li id="fn-e033-1" class="footnote-item"><p>Записные книжки. 1924. <a href="#fnref-e033-1" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e033-2" class="footnote-item"><p>Письма к редактору. 1931. Дополнительное уточнение занимает ещё одну строку. <a href="#fnref-e033-2" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e033-3" class="footnote-item"><p>Каталог собрания. № 17. <a href="#fnref-e033-3" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e033-4" class="footnote-item"><p>Авторский комментарий к изданию. <a href="#fnref-e033-4" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e033-5" class="footnote-item"><p>Предисловие. Страницы 12–14. <a href="#fnref-e033-5" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e033-6" class="footnote-item"><p>Сопоставление двух редакций текста. <a href="#fnref-e033-6" class="footnote-backref">↩︎</a></p>
</li>
</ol>
</section>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
