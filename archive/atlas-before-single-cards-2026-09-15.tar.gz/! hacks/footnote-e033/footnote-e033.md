---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e033
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: footnote-e033
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e033/Description.ru]]
