---
language: ru
translation_status: complete
title: Вопрос → ответ
group: ''
---

# Вопрос → ответ

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-qna
```

## Зачем

Выделить один вопрос и дать на него законченный ответ: в FAQ, учебном материале или разборе интервью.

## Как работает

Заголовок и тело получают собственные крупные маркеры через ::before. В Markdown остаётся один callout: вопрос в заголовке, ответ в содержимом.

## Пояснения из HTML-атласа

Выделить один вопрос и дать на него законченный ответ: в FAQ, учебном материале или разборе интервью.

Заголовок и тело получают собственные крупные маркеры через ::before. В Markdown остаётся один callout: вопрос в заголовке, ответ в содержимом.

jetfiremaster

Сохранены две роли Q/A. CSS написан заново: маркеры привязаны к своим блокам, добавлена адаптация размеров. Формул, требующих математического движка, в примере нет.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/index.html#qna>)
- [Источник 1](https://github.com/r-u-s-h-i-k-e-s-h/Obsidian-CSS-Snippets/blob/Collection/snippets/callout%20styling%20-%20qna%20callout.md)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
[data-callout="qna"] {background:#fff2dc;color:#492a21;border-block:3px solid #dc6a35;padding:24px}
[data-callout="qna"] > .callout-title,[data-callout="qna"] > .callout-content {position:relative;padding-left:55px}
[data-callout="qna"] > .callout-title {font-size:23px;line-height:1.25;padding-bottom:23px;border-bottom:1px solid #e3c6a3}
[data-callout="qna"] > .callout-title::before,[data-callout="qna"] > .callout-content::before {position:absolute;left:0;top:-5px;font:700 45px/1 Georgia,serif}
[data-callout="qna"] > .callout-title::before {content:"Q";color:#c95123}
[data-callout="qna"] > .callout-content {margin-top:24px;font-size:14px}
[data-callout="qna"] > .callout-content::before {content:"A";color:#39785f}
[data-callout="qna"] li {padding-left:4px}
@media(max-width:450px){[data-callout="qna"]{padding:20px 16px}[data-callout="qna"]>.callout-title,[data-callout="qna"]>.callout-content{padding-left:40px}[data-callout="qna"]>.callout-title{font-size:20px}[data-callout="qna"]>.callout-title::before,[data-callout="qna"]>.callout-content::before{font-size:34px}}
```

## Данные исходного каталога

```json
{
  "key": "qna",
  "title": "Вопрос → ответ",
  "role": "Выделить один вопрос и дать на него законченный ответ: в FAQ, учебном материале или разборе интервью.",
  "how": "Заголовок и тело получают собственные крупные маркеры через ::before. В Markdown остаётся один callout: вопрос в заголовке, ответ в содержимом.",
  "ref": "https://github.com/r-u-s-h-i-k-e-s-h/Obsidian-CSS-Snippets/blob/Collection/snippets/callout%20styling%20-%20qna%20callout.md",
  "limit": "",
  "author": "jetfiremaster",
  "adaptation": "Сохранены две роли Q/A. CSS написан заново: маркеры привязаны к своим блокам, добавлена адаптация размеров. Формул, требующих математического движка, в примере нет."
}
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 4. Используется штатных переменных: 2. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 7. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
