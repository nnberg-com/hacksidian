---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: ticket
sources:
- https://github.com/emarpiee/Retroma/blob/main/assets/examples/retroma-retro-callouts.md
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-ticket
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-ticket/Description.ru]]
