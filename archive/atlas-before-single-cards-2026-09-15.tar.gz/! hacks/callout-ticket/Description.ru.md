---
language: ru
translation_status: complete
title: Билет на встречу
group: ''
---

# Билет на встречу

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-ticket
```

## Зачем

Собрать событие, место и время в один компактный блок с отрывным корешком.

## Как работает

Основной callout хранит событие; вложенный callout — корешок. CSS Grid выделяет ему боковую колонку с перфорацией, на телефоне переносит вниз.

## Ограничения исходного приёма

Визуальная карточка события. Номер — текст из Markdown, без проверки доступа или бронирования.

## Пояснения из HTML-атласа

Собрать событие, место и время в один компактный блок с отрывным корешком.

Основной callout хранит событие; вложенный callout — корешок. CSS Grid выделяет ему боковую колонку с перфорацией, на телефоне переносит вниз.

Визуальная карточка события. Номер — текст из Markdown, без проверки доступа или бронирования.

emarpiee · Retroma

От источника — метафора билета. Двухчастная композиция с вложенным корешком и мобильное расположение написаны для демо. Зависимости от Style Manager нет.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/index.html#ticket>)
- [Источник 1](https://github.com/emarpiee/Retroma/blob/main/assets/examples/retroma-retro-callouts.md)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
[data-callout="ticket"] {background:#253fbd;color:#fffbe8;border-radius:8px;padding:25px;box-shadow:7px 7px 0 #d3e044}
[data-callout="ticket"] > .callout-title {font-size:clamp(25px,3vw,36px);line-height:1.05;font-weight:850;letter-spacing:-.04em;border-bottom:1px solid #8190dc;padding-bottom:20px;margin-bottom:20px}
[data-callout="ticket"] > .callout-content {display:grid;grid-template-columns:minmax(0,1fr) 100px;column-gap:20px;align-items:start}
[data-callout="ticket"] > .callout-content > p {grid-column:1;margin:0 0 15px;font-size:13px}
[data-callout="ticket"] > .callout-content > p:first-child {font-size:17px}
[data-callout="stub"] {grid-column:2;grid-row:1/4;align-self:stretch;border-left:2px dashed #aab5f0;padding-left:18px;text-align:center;display:flex;flex-direction:column;justify-content:center}
[data-callout="stub"] > .callout-title {font-size:11px;letter-spacing:.12em;color:#e2eb5d}
[data-callout="stub"] p:first-child {font:700 28px/1.4 "Courier New",monospace;margin:15px 0}
[data-callout="stub"] p:last-child {font-size:9px;letter-spacing:.06em}
@media(max-width:650px){[data-callout="ticket"] > .callout-content {grid-template-columns:1fr}[data-callout="stub"] {grid-column:1;grid-row:auto;border-left:0;border-top:2px dashed #aab5f0;padding:15px 0 0;margin-top:8px;flex-direction:row;align-items:center;justify-content:space-between;gap:15px}[data-callout="stub"] p:first-child {margin:0}}
```

## Данные исходного каталога

```json
{
  "key": "ticket",
  "title": "Билет на встречу",
  "role": "Собрать событие, место и время в один компактный блок с отрывным корешком.",
  "how": "Основной callout хранит событие; вложенный callout — корешок. CSS Grid выделяет ему боковую колонку с перфорацией, на телефоне переносит вниз.",
  "ref": "https://github.com/emarpiee/Retroma/blob/main/assets/examples/retroma-retro-callouts.md",
  "limit": "Визуальная карточка события. Номер — текст из Markdown, без проверки доступа или бронирования.",
  "author": "emarpiee · Retroma",
  "adaptation": "От источника — метафора билета. Двухчастная композиция с вложенным корешком и мобильное расположение написаны для демо. Зависимости от Style Manager нет."
}
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 5. Используется штатных переменных: 2. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 11. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
