---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e004
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: footnote-e004
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e004/Description.ru]]
