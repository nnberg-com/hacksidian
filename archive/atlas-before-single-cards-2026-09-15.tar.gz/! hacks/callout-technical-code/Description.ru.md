---
language: ru
translation_status: complete
title: Блок кода внутри NOTE
group: Содержимое примечания
---

# Блок кода внутри NOTE

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-code
```

## Зачем

Техническое примечание с копируемым примером.

## Как работает

pre получает отдельную подложку и собственную горизонтальную прокрутку.

## Ограничения исходного приёма

Цвет блока кода задаётся CSS; подсветка синтаксических токенов не требуется.

## Пояснения из HTML-атласа

ЗачемТехническое примечание с копируемым примером.

Какpre получает отдельную подложку и собственную горизонтальную прокрутку.

Цвет блока кода задаётся CSS; подсветка синтаксических токенов не требуется.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#code>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@body pre {padding:.8em;background:var(--paper);border:1px solid var(--edge);border-radius:.35em;overflow:auto;font-size:.78em}
```

## Данные исходного каталога

```json
{
  "group": "content",
  "key": "code",
  "title": "Блок кода внутри NOTE",
  "why": "Техническое примечание с копируемым примером.",
  "how": "pre получает отдельную подложку и собственную горизонтальную прокрутку.",
  "profile": "obsidian",
  "type": "note",
  "note": "Цвет блока кода задаётся CSS; подсветка синтаксических токенов не требуется.",
  "source": "https://help.obsidian.md/callouts",
  "n": 51,
  "id": "c051"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="note" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Сохранить пропорции</div></div><div class="callout-content">
<p>Для изображения внутри блока:</p>
<pre><code class="language-css" data-line="3">.callout-content img {
  max-width: 100%;
  height: auto;
}
</code></pre>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 8. Используется штатных переменных: 5. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 6. Случаев для отдельного решения: 1. [baseline.json](./baseline.json) · [Default.css](./Default.css)
