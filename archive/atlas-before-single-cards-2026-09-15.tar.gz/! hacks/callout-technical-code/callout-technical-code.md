---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: code
sources:
- https://help.obsidian.md/callouts
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: callout-technical-code
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-technical-code/Description.ru]]
