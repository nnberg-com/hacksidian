---
language: ru
translation_status: complete
title: Выделение внутри названия
group: Контекст и длинный текст
---

# Выделение внутри названия

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-formatted-title
```

## Зачем

Название примечания с кодом или смысловым акцентом.

## Как работает

Obsidian допускает Markdown в пользовательском заголовке; стилизуется сгенерированный code.

## Ограничения исходного приёма

Пользовательский заголовок — возможность Obsidian; GitHub использует стандартное название типа.

## Пояснения из HTML-атласа

ЗачемНазвание примечания с кодом или смысловым акцентом.

КакObsidian допускает Markdown в пользовательском заголовке; стилизуется сгенерированный code.

Пользовательский заголовок — возможность Obsidian; GitHub использует стандартное название типа.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#formatted-title>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@inner code {font:.88em ui-monospace,monospace;background:var(--paper);padding:.1em .25em;border-radius:.2em}
```

## Данные исходного каталога

```json
{
  "group": "detail",
  "key": "formatted-title",
  "title": "Выделение внутри названия",
  "why": "Название примечания с кодом или смысловым акцентом.",
  "how": "Obsidian допускает Markdown в пользовательском заголовке; стилизуется сгенерированный code.",
  "profile": "obsidian",
  "type": "note",
  "note": "Пользовательский заголовок — возможность Obsidian; GitHub использует стандартное название типа.",
  "source": "https://help.obsidian.md/callouts",
  "n": 58,
  "id": "c058"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="note" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Проверьте файл <code>settings.json</code></div></div><div class="callout-content">
<p>Имя файла должно совпадать с ожидаемым путём.</p>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 1. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
