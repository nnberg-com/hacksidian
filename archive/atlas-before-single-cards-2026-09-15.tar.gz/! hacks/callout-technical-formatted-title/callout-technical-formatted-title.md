---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: formatted-title
sources:
- https://help.obsidian.md/callouts
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-technical-formatted-title
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-technical-formatted-title/Description.ru]]
