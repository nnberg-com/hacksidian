---
language: ru
translation_status: complete
title: Note при печати
group: Декоративные варианты
---

# Note при печати

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Зачем

Примечание не теряется, когда цветовые заливки отключены.

## Как работает

В print-режиме добавляется чёрная рамка, заголовок не отрывается от тела, ссылки выводятся с адресами.

## Ограничения исходного приёма

Посмотрите предварительный просмотр печати. CSS-пагинация не может удержать блок, который длиннее страницы.

## Пояснения из HTML-атласа

ЗачемПримечание не теряется, когда цветовые заливки отключены.

КакВ print-режиме добавляется чёрная рамка, заголовок не отрывается от тела, ссылки выводятся с адресами.

Посмотрите предварительный просмотр печати. CSS-пагинация не может удержать блок, который длиннее страницы.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#print>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@media print {@box {background:white;color:black;border:1px solid black;box-shadow:none;break-inside:avoid} @title {color:black;break-after:avoid} @body a::after {content:" (" attr(href) ")";font-size:.8em;overflow-wrap:anywhere}}
```

## Данные исходного каталога

```json
{
  "group": "finish",
  "key": "print",
  "title": "Note при печати",
  "why": "Примечание не теряется, когда цветовые заливки отключены.",
  "how": "В print-режиме добавляется чёрная рамка, заголовок не отрывается от тела, ссылки выводятся с адресами.",
  "profile": "obsidian",
  "type": "note",
  "note": "Посмотрите предварительный просмотр печати. CSS-пагинация не может удержать блок, который длиннее страницы.",
  "source": "https://help.obsidian.md/callouts",
  "n": 68,
  "id": "c068"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="note" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Обратите внимание</div></div><div class="callout-content">
<p>Сверьте правила с <a href="https://help.obsidian.md/callouts" class="external-link" target="_blank" rel="noopener nofollow" aria-label="https://help.obsidian.md/callouts" data-tooltip-position="top">описанием Callouts</a>.</p>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 0. Случаев для отдельного решения: 1. [baseline.json](./baseline.json) · [Default.css](./Default.css)
