---
language: ru
translation_status: complete
title: Двузначные номера
group: Сложное содержимое и среда
---

# Двузначные номера

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
footnote-e052
```

## Зачем

Список из десяти и более источников.

## Как работает

Широкий отступ у ol и табличные цифры у маркеров.

## Демонстрация

Сравните номер в тексте и примечания ниже.

## Ограничения исходного приёма

Обычный CSS

## Пояснения из HTML-атласа

Как Широкий отступ у ol и табличные цифры у маркеров.

Зачем Список из десяти и более источников.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/footnote-styles-demo/index.html#e052>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Общие условия исходного раздела

Подсветка и нижняя панель основаны на опубликованных приёмах. Варианты оформления и сочетания с :has() и якорями — адаптации для HTML выбранного Markdown-рендерера.

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
.e052 .footnotes-list {padding-inline-start:3em;}
.e052 .footnote-item::marker {font-variant-numeric:tabular-nums;}
.e052 .footnote-item {margin-block:.3em;}
```

## Данные исходного каталога

```json
{
  "id": "e052",
  "title": "Двузначные номера",
  "how": "Широкий отступ у ol и табличные цифры у маркеров.",
  "why": "Список из десяти и более источников.",
  "action": "Сравните номер в тексте и примечания ниже.",
  "limit": "",
  "support": "Обычный CSS",
  "group": "resilience"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<p>Ссылка<sup class="footnote-ref"><a href="#fn-e052-1" id="fnref-e052-1">[1]</a></sup>, Ссылка<sup class="footnote-ref"><a href="#fn-e052-2" id="fnref-e052-2">[2]</a></sup>, Ссылка<sup class="footnote-ref"><a href="#fn-e052-3" id="fnref-e052-3">[3]</a></sup>, Ссылка<sup class="footnote-ref"><a href="#fn-e052-4" id="fnref-e052-4">[4]</a></sup>, Ссылка<sup class="footnote-ref"><a href="#fn-e052-5" id="fnref-e052-5">[5]</a></sup>, Ссылка<sup class="footnote-ref"><a href="#fn-e052-6" id="fnref-e052-6">[6]</a></sup>, Ссылка<sup class="footnote-ref"><a href="#fn-e052-7" id="fnref-e052-7">[7]</a></sup>, Ссылка<sup class="footnote-ref"><a href="#fn-e052-8" id="fnref-e052-8">[8]</a></sup>, Ссылка<sup class="footnote-ref"><a href="#fn-e052-9" id="fnref-e052-9">[9]</a></sup>, Ссылка<sup class="footnote-ref"><a href="#fn-e052-10" id="fnref-e052-10">[10]</a></sup>, Ссылка<sup class="footnote-ref"><a href="#fn-e052-11" id="fnref-e052-11">[11]</a></sup>, Ссылка<sup class="footnote-ref"><a href="#fn-e052-12" id="fnref-e052-12">[12]</a></sup>.</p>
<hr class="footnotes-sep">
<section class="footnotes">
<ol class="footnotes-list">
<li id="fn-e052-1" class="footnote-item"><p>Источник 1. <a href="#fnref-e052-1" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e052-2" class="footnote-item"><p>Источник 2. <a href="#fnref-e052-2" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e052-3" class="footnote-item"><p>Источник 3. <a href="#fnref-e052-3" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e052-4" class="footnote-item"><p>Источник 4. <a href="#fnref-e052-4" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e052-5" class="footnote-item"><p>Источник 5. <a href="#fnref-e052-5" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e052-6" class="footnote-item"><p>Источник 6. <a href="#fnref-e052-6" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e052-7" class="footnote-item"><p>Источник 7. <a href="#fnref-e052-7" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e052-8" class="footnote-item"><p>Источник 8. <a href="#fnref-e052-8" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e052-9" class="footnote-item"><p>Источник 9. <a href="#fnref-e052-9" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e052-10" class="footnote-item"><p>Источник 10. <a href="#fnref-e052-10" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e052-11" class="footnote-item"><p>Источник 11. <a href="#fnref-e052-11" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e052-12" class="footnote-item"><p>Источник 12. <a href="#fnref-e052-12" class="footnote-backref">↩︎</a></p>
</li>
</ol>
</section>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
