---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e012
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: footnote-e012
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e012/Description.ru]]
