---
language: ru
translation_status: complete
title: Градиентная рамка
group: Декоративные варианты
---

# Градиентная рамка

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-gradient
```

## Зачем

Акцентное примечание в визуально насыщенной теме.

## Как работает

Два слоя background заполняют padding-box и border-box; сама граница прозрачная.

## Пояснения из HTML-атласа

ЗачемАкцентное примечание в визуально насыщенной теме.

КакДва слоя background заполняют padding-box и border-box; сама граница прозрачная.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#gradient>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@box {border:2px solid transparent;background:linear-gradient(var(--paper),var(--paper)) padding-box,linear-gradient(125deg,var(--tone),#c68f50) border-box}
```

## Данные исходного каталога

```json
{
  "group": "finish",
  "key": "gradient",
  "title": "Градиентная рамка",
  "why": "Акцентное примечание в визуально насыщенной теме.",
  "how": "Два слоя background заполняют padding-box и border-box; сама граница прозрачная.",
  "profile": "obsidian",
  "type": "note",
  "note": "",
  "source": "https://help.obsidian.md/callouts",
  "n": 63,
  "id": "c063"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="note" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Обратите внимание</div></div><div class="callout-content">
<p>Изменения вступят в силу после повторного открытия файла. <strong>Сохраните результат</strong>, прежде чем продолжить.</p>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 1. Используется штатных переменных: 2. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 0. Случаев для отдельного решения: 1. [baseline.json](./baseline.json) · [Default.css](./Default.css)
