---
language: ru
translation_status: complete
title: Колонка 80
group: Разлиновка и направляющие
---

# Колонка 80

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
code-e030
```

## Зачем

Видеть рекомендованную границу длины строки.

## Как работает

Вертикальный градиент на 80ch от начала code; фон движется с текстом.

## Ограничения исходного приёма

Прокрутите вправо до направляющей. ch основан на ширине нуля, а не на подсчёте Unicode-символов.

## Пояснения из HTML-атласа

Видеть рекомендованную границу длины строки.

Вертикальный градиент на 80ch от начала code; фон движется с текстом.

Прокрутите вправо до направляющей. ch основан на ширине нуля, а не на подсчёте Unicode-символов.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/code-styles-demo/index.html#e030>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
S pre > code { display: block; width: max-content; min-width: 100%; background: linear-gradient(to right, transparent 80ch, #b8484280 80ch calc(80ch + 1px), transparent calc(80ch + 1px)); }
```

## Данные исходного каталога

```json
{
  "id": "e030",
  "group": "rulers",
  "title": "Колонка 80",
  "why": "Видеть рекомендованную границу длины строки.",
  "how": "Вертикальный градиент на 80ch от начала code; фон движется с текстом.",
  "note": "Прокрутите вправо до направляющей. ch основан на ширине нуля, а не на подсчёте Unicode-символов.",
  "kind": "Обычный Markdown"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<pre><code>GET /api/search?query=markdown&amp;include=examples,notes,references&amp;sort=updated_at&amp;direction=descending HTTP/1.1
Authorization: Bearer example_token_for_documentation_only
Accept: application/json

{&quot;status&quot;:&quot;ok&quot;,&quot;message&quot;:&quot;A deliberately long response that demonstrates horizontal scrolling and soft wrapping without changing the source text.&quot;}
</code></pre>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
