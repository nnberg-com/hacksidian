---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e030
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e030
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e030/Description.ru]]
