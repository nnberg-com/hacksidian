---
language: ru
translation_status: complete
title: Оформление свёрнутого Callout
group: Среда и состояния
---

# Оформление свёрнутого Callout

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-fold-closed
```

## Зачем

Начальное состояние [!note]- в Obsidian.

## Как работает

Для статического демо атрибут data-callout-fold="-" скрывает тело; индикатор создаётся CSS.

## Ограничения исходного приёма

Только начальное состояние. В работающем Obsidian текущее состояние задаётся классом is-collapsed; правило по начальному атрибуту не следует переносить для интерактивного складывания.

## Пояснения из HTML-атласа

ЗачемНачальное состояние [!note]- в Obsidian.

КакДля статического демо атрибут data-callout-fold="-" скрывает тело; индикатор создаётся CSS.

Только начальное состояние. В работающем Obsidian текущее состояние задаётся классом is-collapsed; правило по начальному атрибуту не следует переносить для интерактивного складывания.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#fold-closed>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@box[data-callout-fold="-"] > .callout-content {display:none} @box[data-callout-fold="-"] > .callout-title {margin-bottom:0} @box[data-callout-fold="-"] > .callout-title::after {content:"›";margin-inline-start:auto}
```

## Данные исходного каталога

```json
{
  "group": "states",
  "key": "fold-closed",
  "title": "Оформление свёрнутого Callout",
  "why": "Начальное состояние [!note]- в Obsidian.",
  "how": "Для статического демо атрибут data-callout-fold=\"-\" скрывает тело; индикатор создаётся CSS.",
  "profile": "obsidian",
  "type": "note",
  "note": "Только начальное состояние. В работающем Obsidian текущее состояние задаётся классом is-collapsed; правило по начальному атрибуту не следует переносить для интерактивного складывания.",
  "source": "https://help.obsidian.md/callouts",
  "n": 70,
  "id": "c070"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="note" data-callout-fold="-" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Скрыто по умолчанию</div></div><div class="callout-content">
<p>Этот текст остаётся в исходнике и HTML.</p>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
