---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e025
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: footnote-e025
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e025/Description.ru]]
