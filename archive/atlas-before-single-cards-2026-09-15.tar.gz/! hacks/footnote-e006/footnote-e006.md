---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e006
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: footnote-e006
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e006/Description.ru]]
