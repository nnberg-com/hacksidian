---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: inset
sources:
- https://help.obsidian.md/callouts
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-technical-inset
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-technical-inset/Description.ru]]
