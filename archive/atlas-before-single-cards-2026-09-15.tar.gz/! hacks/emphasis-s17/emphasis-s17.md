---
tags:
- atlas/technique
- atlas/emphasis
category: emphasis
digest: []
source_anchor: s17
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: emphasis-s17
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/emphasis-s17/Description.ru]]
