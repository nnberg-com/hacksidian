---
language: ru
translation_status: complete
title: Приподнятые углы бумаги
group: Декоративные оболочки
---

# Приподнятые углы бумаги

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
code-e038
```

## Зачем

Выразительная бумажная карточка для центрального примера.

## Как работает

Два повёрнутых псевдоэлемента с тенями находятся под непрозрачным code.

## Пояснения из HTML-атласа

Выразительная бумажная карточка для центрального примера.

Два повёрнутых псевдоэлемента с тенями находятся под непрозрачным code.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/code-styles-demo/index.html#e038>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
S pre { position: relative; isolation: isolate; overflow: visible; padding: 0; background: none; }
S pre > code { display: block; position: relative; z-index: 1; padding: 18px; background: #fffef8; border: 1px solid #e7e3d5; overflow: auto; }
S pre::before, S pre::after { content: ""; position: absolute; width: 42%; height: 25%; bottom: 9px; left: 9px; box-shadow: 0 13px 10px #27362e44; transform: rotate(-3deg); }
S pre::after { left: auto; right: 9px; transform: rotate(3deg); }
```

## Данные исходного каталога

```json
{
  "id": "e038",
  "group": "objects",
  "title": "Приподнятые углы бумаги",
  "why": "Выразительная бумажная карточка для центрального примера.",
  "how": "Два повёрнутых псевдоэлемента с тенями находятся под непрозрачным code.",
  "note": "",
  "kind": "Обычный Markdown"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<pre><code>const palette = {
  background: &quot;#f8f7f2&quot;,
  accent: &quot;#bd5036&quot;,
  spacing: [4, 8, 16]
};

render(palette);
</code></pre>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 1. Случаев для отдельного решения: 1. [baseline.json](./baseline.json) · [Default.css](./Default.css)
