---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e038
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: code-e038
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e038/Description.ru]]
