---
tags:
- atlas/technique
- atlas/emphasis
category: emphasis
digest: []
source_anchor: s21
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: emphasis-s21
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/emphasis-s21/Description.ru]]
