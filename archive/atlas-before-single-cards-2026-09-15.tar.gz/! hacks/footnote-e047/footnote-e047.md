---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e047
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: footnote-e047
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e047/Description.ru]]
