---
tags:
- atlas/technique
- atlas/heading
category: heading
digest: []
source_anchor: e021
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: heading-e021
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/heading-e021/Description.ru]]
