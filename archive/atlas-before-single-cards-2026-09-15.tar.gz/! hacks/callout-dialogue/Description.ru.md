---
language: ru
translation_status: complete
title: Переписка
group: ''
---

# Переписка

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-dialogue
```

## Зачем

Сохранить интервью или показать, как участники пришли к решению.

## Как работает

Один абзац — одна реплика. CSS чередует стороны через :nth-child(); имя в **жирном** становится строкой автора.

## Ограничения исходного приёма

Чередование рассчитано на двух собеседников и одну реплику в каждом абзаце. CSS не определяет автора по тексту.

## Пояснения из HTML-атласа

Сохранить интервью или показать, как участники пришли к решению.

Один абзац — одна реплика. CSS чередует стороны через :nth-child(); имя в **жирном** становится строкой автора.

Чередование рассчитано на двух собеседников и одну реплику в каждом абзаце. CSS не определяет автора по тексту.

Практика сообщества

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/index.html#dialogue>)
- [Источник 1](https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/conversation.html)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
[data-callout="dialogue"] {padding:24px;background:#eaf0f6;color:#213647;border-radius:18px}
[data-callout="dialogue"] > .callout-title {text-align:center;margin-bottom:24px;font-size:13px;text-transform:uppercase;letter-spacing:.1em}
[data-callout="dialogue"] > .callout-content {display:flex;flex-direction:column;gap:14px}
[data-callout="dialogue"] p {max-width:85%;margin:0;padding:14px 18px;background:white;border-radius:16px 16px 16px 3px;align-self:flex-start;font-size:14px}
[data-callout="dialogue"] p:nth-child(even) {align-self:flex-end;background:#294c66;color:white;border-radius:16px 16px 3px 16px}
[data-callout="dialogue"] strong + br {display:none}
[data-callout="dialogue"] strong {display:block;font-size:11px;margin-bottom:5px;opacity:.8}
```

## Данные исходного каталога

```json
{
  "key": "dialogue",
  "title": "Переписка",
  "role": "Сохранить интервью или показать, как участники пришли к решению.",
  "how": "Один абзац — одна реплика. CSS чередует стороны через :nth-child(); имя в **жирном** становится строкой автора.",
  "ref": "https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/conversation.html",
  "limit": "Чередование рассчитано на двух собеседников и одну реплику в каждом абзаце. CSS не определяет автора по тексту."
}
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 3. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 8. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
