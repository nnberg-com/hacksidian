---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e005
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: footnote-e005
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e005/Description.ru]]
