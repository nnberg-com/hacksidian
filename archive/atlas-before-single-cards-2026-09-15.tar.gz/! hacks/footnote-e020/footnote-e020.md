---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e020
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: footnote-e020
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e020/Description.ru]]
