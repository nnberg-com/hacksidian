---
language: ru
translation_status: complete
title: Примечание только с заголовком
group: Заголовок и значок
---

# Примечание только с заголовком

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-title-only
```

## Зачем

Короткий сигнал без отдельного поясняющего абзаца.

## Как работает

Obsidian создаёт Callout без контейнера тела; у заголовка убирается нижний отступ.

## Пояснения из HTML-атласа

ЗачемКороткий сигнал без отдельного поясняющего абзаца.

КакObsidian создаёт Callout без контейнера тела; у заголовка убирается нижний отступ.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#title-only>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@title {margin-bottom:0}
```

## Данные исходного каталога

```json
{
  "group": "title",
  "key": "title-only",
  "title": "Примечание только с заголовком",
  "why": "Короткий сигнал без отдельного поясняющего абзаца.",
  "how": "Obsidian создаёт Callout без контейнера тела; у заголовка убирается нижний отступ.",
  "profile": "obsidian",
  "type": "success",
  "note": "",
  "source": "https://help.obsidian.md/callouts",
  "n": 40,
  "id": "c040"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="success" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Изменения сохранены</div></div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
