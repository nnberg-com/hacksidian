---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e033
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e033
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e033/Description.ru]]
