---
tags:
- atlas/technique
- atlas/heading
category: heading
digest: []
source_anchor: e012
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: heading-e012
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/heading-e012/Description.ru]]
