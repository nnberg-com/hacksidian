---
language: ru
translation_status: complete
title: Досье
group: ''
---

# Досье

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-dossier
```

## Зачем

Быстро познакомить с объектом: местом, человеком, проектом или устройством.

## Как работает

Изображение становится обложкой, заголовки разделяют разделы, таблица хранит характеристики. Всё находится внутри одного callout.

## Пояснения из HTML-атласа

Быстро познакомить с объектом: местом, человеком, проектом или устройством.

Изображение становится обложкой, заголовки разделяют разделы, таблица хранит характеристики. Всё находится внутри одного callout.

Практика сообщества

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/index.html#dossier>)
- [Источник 1](https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/fas-infobox.html)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/station.svg](<./assets/assets/station.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
[data-callout="dossier"] {max-width:420px;margin-inline:auto;border:1px solid #bac5b6;background:#f5f7ef;box-shadow:8px 8px 0 #dce4d7;padding:0;color:#26392d}
[data-callout="dossier"] > .callout-title {padding:18px 24px;background:#26392d;color:#fff;font-family:Georgia,serif;font-size:26px}
[data-callout="dossier"] > .callout-content > p:first-child {margin:0}
[data-callout="dossier"] img {width:100%;display:block;aspect-ratio:2/1;object-fit:cover}
[data-callout="dossier"] h3 {padding:10px 22px;border-block:1px solid #bac5b6;font-size:13px;text-transform:uppercase;letter-spacing:.06em}
[data-callout="dossier"] table {width:calc(100% - 44px);margin:20px 22px;font-size:14px}
[data-callout="dossier"] td {padding:8px 0;border-bottom:1px solid #dce4d7}
[data-callout="dossier"] th {text-align:left;font-size:12px}
[data-callout="dossier"] td:first-child {color:#637462;width:40%}
[data-callout="dossier"] > .callout-content > p:not(:first-child) {margin:20px 22px}
[data-callout="record"] {margin:0;padding:16px 22px;background:#e3eada;border-top:1px dashed #879d85;font-size:13px}
```

## Данные исходного каталога

```json
{
  "key": "dossier",
  "title": "Досье",
  "role": "Быстро познакомить с объектом: местом, человеком, проектом или устройством.",
  "how": "Изображение становится обложкой, заголовки разделяют разделы, таблица хранит характеристики. Всё находится внутри одного callout.",
  "ref": "https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/fas-infobox.html",
  "limit": ""
}
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 5. Используется штатных переменных: 2. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color, font; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 9. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
