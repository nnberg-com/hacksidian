---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e025
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: code-e025
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e025/Description.ru]]
