---
language: ru
translation_status: complete
title: Тени сверху и снизу
group: Ширина и прокрутка
---

# Тени сверху и снизу

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
code-e025
```

## Зачем

Показать положение в длинном вертикальном выводе.

## Как работает

Та же комбинация local/scroll вдоль вертикальной оси.

## Пояснения из HTML-атласа

Показать положение в длинном вертикальном выводе.

Та же комбинация local/scroll вдоль вертикальной оси.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/code-styles-demo/index.html#e025>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
S pre { max-height: 12rem; overflow: auto;
 background: linear-gradient(#f4f3ee 35%, #f4f3ee00) top / 100% 36px no-repeat local,
 linear-gradient(to top, #f4f3ee 35%, #f4f3ee00) bottom / 100% 36px no-repeat local,
 linear-gradient(#263d3238, transparent) top / 100% 12px no-repeat scroll,
 linear-gradient(to top, #263d3238, transparent) bottom / 100% 12px no-repeat scroll;
 background-color: #f4f3ee;
}
```

## Данные исходного каталога

```json
{
  "id": "e025",
  "group": "flow",
  "title": "Тени сверху и снизу",
  "why": "Показать положение в длинном вертикальном выводе.",
  "how": "Та же комбинация local/scroll вдоль вертикальной оси.",
  "note": "",
  "kind": "Обычный Markdown"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<pre><code>01:00  build · module_01  completed
02:00  build · module_02  completed
03:00  build · module_03  completed
04:00  build · module_04  completed
05:00  build · module_05  completed
06:00  build · module_06  completed
07:00  build · module_07  completed
08:00  build · module_08  completed
09:00  build · module_09  completed
10:00  build · module_10  completed
11:00  build · module_11  completed
12:00  build · module_12  completed
13:00  build · module_13  completed
14:00  build · module_14  completed
15:00  build · module_15  completed
16:00  build · module_16  completed
17:00  build · module_17  completed
18:00  build · module_18  completed
19:00  build · module_19  completed
20:00  build · module_20  completed
21:00  build · module_21  completed
22:00  build · module_22  completed
23:00  build · module_23  completed
24:00  build · module_24  completed
</code></pre>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
