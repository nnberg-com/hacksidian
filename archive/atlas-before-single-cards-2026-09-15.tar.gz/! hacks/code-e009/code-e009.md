---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e009
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e009
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e009/Description.ru]]
