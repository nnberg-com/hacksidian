---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e021
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: code-e021
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e021/Description.ru]]
