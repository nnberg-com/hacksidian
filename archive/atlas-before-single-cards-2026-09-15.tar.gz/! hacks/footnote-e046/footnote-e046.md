---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e046
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: footnote-e046
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e046/Description.ru]]
