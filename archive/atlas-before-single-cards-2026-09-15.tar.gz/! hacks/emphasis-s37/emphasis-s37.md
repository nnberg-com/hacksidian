---
tags:
- atlas/technique
- atlas/emphasis
category: emphasis
digest: []
source_anchor: s37
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: emphasis-s37
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/emphasis-s37/Description.ru]]
