---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e003
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e003
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e003/Description.ru]]
