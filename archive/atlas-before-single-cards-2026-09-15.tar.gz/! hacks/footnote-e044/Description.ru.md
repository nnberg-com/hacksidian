---
language: ru
translation_status: complete
title: Карточка у номера при наведении
group: Карточка рядом с номером
---

# Карточка у номера при наведении

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Зачем

Короткие ремарки и ссылки без прыжка к концу.

## Как работает

Якорь ставит примечание близко к номеру; задержка закрытия помогает пройти небольшой зазор.

## Демонстрация

Наведите на номер, затем на карточку. Клик закрепляет её до возврата по ↩. Если фокус остался на номере, Tab убирает предпросмотр.

## Ограничения исходного приёма

Только на устройствах с hover и поддержкой якорей. В остальных случаях — обычные сноски.

Anchor Positioning

## Пояснения из HTML-атласа

Как Якорь ставит примечание близко к номеру; задержка закрытия помогает пройти небольшой зазор.

Зачем Короткие ремарки и ссылки без прыжка к концу.

Условие Только на устройствах с hover и поддержкой якорей. В остальных случаях — обычные сноски.

Ваш браузер понимает базовое якорное позиционирование.Якорное позиционирование недоступно: показан обычный список.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/footnote-styles-demo/index.html#e044>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Общие условия исходного раздела

Подсветка и нижняя панель основаны на опубликованных приёмах. Варианты оформления и сочетания с :has() и якорями — адаптации для HTML выбранного Markdown-рендерера.

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@supports (anchor-name:--a) and (position-area:bottom) {@media screen and (hover:hover) {.e044 a[href="#fn-e044-1"] {anchor-name:--e044-1;}
.e044 #fn-e044-1 {position-anchor:--e044-1;}
.e044 a[href="#fn-e044-2"] {anchor-name:--e044-2;}
.e044 #fn-e044-2 {position-anchor:--e044-2;}
.e044 #fn-e044-1 {position:fixed;z-index:30;box-sizing:border-box;max-block-size:42dvh;overflow:auto;padding:1.25rem 1.5rem 1.25rem 2.5rem;background:var(--paper);color:var(--ink);border:1px solid var(--line);box-shadow:0 12px 50px #0003;inset:auto;position-area:bottom;position-try-fallbacks:flip-block,flip-inline;inline-size:min(22rem,calc(100vw - 2rem));margin:.3rem;visibility:hidden;opacity:0;transition:opacity .12s .4s,visibility 0s .55s;}
.e044:has(a[href="#fn-e044-1"]:is(:hover,:focus-visible)) #fn-e044-1, .e044 #fn-e044-1:is(:hover,:focus-within,:target) {visibility:visible;opacity:1;transition-delay:0s;}
.e044 #fn-e044-2 {position:fixed;z-index:30;box-sizing:border-box;max-block-size:42dvh;overflow:auto;padding:1.25rem 1.5rem 1.25rem 2.5rem;background:var(--paper);color:var(--ink);border:1px solid var(--line);box-shadow:0 12px 50px #0003;inset:auto;position-area:bottom;position-try-fallbacks:flip-block,flip-inline;inline-size:min(22rem,calc(100vw - 2rem));margin:.3rem;visibility:hidden;opacity:0;transition:opacity .12s .4s,visibility 0s .55s;}
.e044:has(a[href="#fn-e044-2"]:is(:hover,:focus-visible)) #fn-e044-2, .e044 #fn-e044-2:is(:hover,:focus-within,:target) {visibility:visible;opacity:1;transition-delay:0s;}
}}
```

## Данные исходного каталога

```json
{
  "id": "e044",
  "title": "Карточка у номера при наведении",
  "how": "Якорь ставит примечание близко к номеру; задержка закрытия помогает пройти небольшой зазор.",
  "why": "Короткие ремарки и ссылки без прыжка к концу.",
  "action": "Наведите на номер, затем на карточку. Клик закрепляет её до возврата по ↩. Если фокус остался на номере, Tab убирает предпросмотр.",
  "limit": "Только на устройствах с hover и поддержкой якорей. В остальных случаях — обычные сноски.",
  "support": "Anchor Positioning",
  "group": "anchors"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<p>Хорошая сноска оставляет подробность рядом с мыслью,<sup class="footnote-ref"><a href="#fn-e044-1" id="fnref-e044-1">[1]</a></sup> не перегружая само предложение. Второе примечание помогает сравнить оформление.<sup class="footnote-ref"><a href="#fn-e044-2" id="fnref-e044-2">[2]</a></sup></p>
<hr class="footnotes-sep">
<section class="footnotes">
<ol class="footnotes-list">
<li id="fn-e044-1" class="footnote-item"><p>Уточнение к основному тексту. Его можно прочитать отдельно и вернуться по стрелке. <a href="#fnref-e044-1" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e044-2" class="footnote-item"><p>Источник или короткая авторская ремарка. <a href="#fnref-e044-2" class="footnote-backref">↩︎</a></p>
</li>
</ol>
</section>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 12. Используется штатных переменных: 3. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
