---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e044
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: footnote-e044
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e044/Description.ru]]
