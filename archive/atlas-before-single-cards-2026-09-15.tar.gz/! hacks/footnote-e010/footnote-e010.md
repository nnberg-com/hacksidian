---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e010
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: footnote-e010
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e010/Description.ru]]
