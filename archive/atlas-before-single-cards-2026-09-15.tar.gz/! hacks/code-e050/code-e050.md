---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e050
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e050
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e050/Description.ru]]
