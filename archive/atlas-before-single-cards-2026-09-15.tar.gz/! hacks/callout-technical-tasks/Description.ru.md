---
language: ru
translation_status: complete
title: Чек-лист внутри TODO
group: Содержимое примечания
---

# Чек-лист внутри TODO

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-tasks
```

## Зачем

Оставшиеся действия в рамках одной ремарки.

## Как работает

Готовые checkbox и пункты списка оформляются внутри callout-content.

## Ограничения исходного приёма

Нативные флажки можно переключать. Это изменяет только состояние страницы, а не исходный Markdown-файл.

## Пояснения из HTML-атласа

ЗачемОставшиеся действия в рамках одной ремарки.

КакГотовые checkbox и пункты списка оформляются внутри callout-content.

Нативные флажки можно переключать. Это изменяет только состояние страницы, а не исходный Markdown-файл.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#tasks>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@body ul {list-style:none;padding:0} @body li {margin-block:.45em} @body input {accent-color:var(--tone)} @body li:has(input:checked) {color:var(--muted);text-decoration:line-through}
```

## Данные исходного каталога

```json
{
  "group": "content",
  "key": "tasks",
  "title": "Чек-лист внутри TODO",
  "why": "Оставшиеся действия в рамках одной ремарки.",
  "how": "Готовые checkbox и пункты списка оформляются внутри callout-content.",
  "profile": "obsidian",
  "type": "todo",
  "note": "Нативные флажки можно переключать. Это изменяет только состояние страницы, а не исходный Markdown-файл.",
  "source": "https://help.obsidian.md/callouts",
  "n": 53,
  "id": "c053"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="todo" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Перед завершением</div></div><div class="callout-content">
<ul class="contains-task-list">
<li class="task-list-item is-checked" data-task="x" data-line="1"><input class="task-list-item-checkbox" type="checkbox" checked data-line="1">Проверить широкий экран</li>
<li class="task-list-item is-checked" data-task="x" data-line="2"><input class="task-list-item-checkbox" type="checkbox" checked data-line="2">Проверить узкую полосу</li>
<li class="task-list-item" data-task=" " data-line="3"><input class="task-list-item-checkbox" type="checkbox" data-line="3">Получить визуальную оценку</li>
</ul>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 2. Используется штатных переменных: 2. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
