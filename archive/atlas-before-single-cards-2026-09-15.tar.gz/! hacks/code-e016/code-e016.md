---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e016
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e016
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e016/Description.ru]]
