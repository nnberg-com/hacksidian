---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e022
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: footnote-e022
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e022/Description.ru]]
