---
tags:
- atlas/technique
- atlas/heading
category: heading
digest: []
source_anchor: e010
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: heading-e010
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/heading-e010/Description.ru]]
