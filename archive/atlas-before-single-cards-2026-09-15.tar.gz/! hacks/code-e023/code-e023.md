---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e023
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e023
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e023/Description.ru]]
