---
language: ru
translation_status: complete
title: Фотокарточка
group: ''
---

# Фотокарточка

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-photo
```

## Зачем

Связать изображение с короткой подписью в дневнике наблюдений.

## Как работает

CSS меняет порядок заголовка и содержимого через Flexbox. Заголовок callout становится нижней подписью; дополнительный HTML для неё не нужен.

## Ограничения исходного приёма

В демо авторская SVG-иллюстрация. В том же Markdown можно указать обычную фотографию.

## Пояснения из HTML-атласа

Связать изображение с короткой подписью в дневнике наблюдений.

CSS меняет порядок заголовка и содержимого через Flexbox. Заголовок callout становится нижней подписью; дополнительный HTML для неё не нужен.

В демо авторская SVG-иллюстрация. В том же Markdown можно указать обычную фотографию.

Практика сообщества

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/index.html#photo>)
- [Источник 1](https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/polaroid.html)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/bay-scene.svg](<./assets/assets/bay-scene.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
[data-callout="photo"] {display:flex;flex-direction:column-reverse;background:#fffdf7;padding:14px;max-width:400px;margin:14px auto;transform:rotate(-2deg);box-shadow:2px 10px 20px #25332b25;color:#3b473f}
[data-callout="photo"] > .callout-title {text-align:center;font-family:Georgia,serif;font-style:italic;font-size:18px;padding:22px 8px 12px}
[data-callout="photo"] p {margin:0}
[data-callout="photo"] img {display:block;width:100%;aspect-ratio:4/3;object-fit:cover;filter:saturate(.65)}
```

## Данные исходного каталога

```json
{
  "key": "photo",
  "title": "Фотокарточка",
  "role": "Связать изображение с короткой подписью в дневнике наблюдений.",
  "how": "CSS меняет порядок заголовка и содержимого через Flexbox. Заголовок callout становится нижней подписью; дополнительный HTML для неё не нужен.",
  "ref": "https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/polaroid.html",
  "limit": "В демо авторская SVG-иллюстрация. В том же Markdown можно указать обычную фотографию."
}
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 1. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color, font; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 3. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
