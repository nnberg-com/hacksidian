---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: photo
sources:
- https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/polaroid.html
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-photo
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-photo/Description.ru]]
