---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e017
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: code-e017
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e017/Description.ru]]
