---
language: ru
translation_status: complete
title: Горизонтальная прокрутка
group: Ширина и прокрутка
---

# Горизонтальная прокрутка

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
code-e017
```

## Зачем

Сохранить длинные строки буквально.

## Как работает

white-space: pre плюс overflow: auto.

## Ограничения исходного приёма

Прокрутите вправо. Фокусируемость scroll-контейнера с клавиатуры зависит от браузера; CSS не добавляет tabindex.

## Пояснения из HTML-атласа

Сохранить длинные строки буквально.

white-space: pre плюс overflow: auto.

Прокрутите вправо. Фокусируемость scroll-контейнера с клавиатуры зависит от браузера; CSS не добавляет tabindex.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/code-styles-demo/index.html#e017>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
S pre { white-space: pre; overflow: auto; }
```

## Данные исходного каталога

```json
{
  "id": "e017",
  "group": "flow",
  "title": "Горизонтальная прокрутка",
  "why": "Сохранить длинные строки буквально.",
  "how": "white-space: pre плюс overflow: auto.",
  "note": "Прокрутите вправо. Фокусируемость scroll-контейнера с клавиатуры зависит от браузера; CSS не добавляет tabindex.",
  "kind": "Обычный Markdown"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<pre><code>GET /api/search?query=markdown&amp;include=examples,notes,references&amp;sort=updated_at&amp;direction=descending HTTP/1.1
Authorization: Bearer example_token_for_documentation_only
Accept: application/json

{&quot;status&quot;:&quot;ok&quot;,&quot;message&quot;:&quot;A deliberately long response that demonstrates horizontal scrolling and soft wrapping without changing the source text.&quot;}
</code></pre>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
