---
language: ru
translation_status: complete
title: Количество колонок по ширине
group: Колонки и сетки
---

# Количество колонок по ширине

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
footnote-e034
```

## Зачем

Одна система для узких и широких документов.

## Как работает

columns:15rem задаёт желаемую ширину; браузер выбирает количество.

## Демонстрация

Сравните номер в тексте и примечания ниже.

## Ограничения исходного приёма

Обычный CSS

## Пояснения из HTML-атласа

Как columns:15rem задаёт желаемую ширину; браузер выбирает количество.

Зачем Одна система для узких и широких документов.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/footnote-styles-demo/index.html#e034>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Общие условия исходного раздела

Подсветка и нижняя панель основаны на опубликованных приёмах. Варианты оформления и сочетания с :has() и якорями — адаптации для HTML выбранного Markdown-рендерера.

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
.e034 .footnotes-list {columns:15rem;column-gap:2rem;column-rule:1px solid var(--line);}
.e034 .footnote-item {break-inside:avoid;}
```

## Данные исходного каталога

```json
{
  "id": "e034",
  "title": "Количество колонок по ширине",
  "how": "columns:15rem задаёт желаемую ширину; браузер выбирает количество.",
  "why": "Одна система для узких и широких документов.",
  "action": "Сравните номер в тексте и примечания ниже.",
  "limit": "",
  "support": "Обычный CSS",
  "group": "columns"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<p>В этом фрагменте собраны короткие источники: первый,<sup class="footnote-ref"><a href="#fn-e034-1" id="fnref-e034-1">[1]</a></sup> второй,<sup class="footnote-ref"><a href="#fn-e034-2" id="fnref-e034-2">[2]</a></sup> третий,<sup class="footnote-ref"><a href="#fn-e034-3" id="fnref-e034-3">[3]</a></sup> четвёртый,<sup class="footnote-ref"><a href="#fn-e034-4" id="fnref-e034-4">[4]</a></sup> пятый<sup class="footnote-ref"><a href="#fn-e034-5" id="fnref-e034-5">[5]</a></sup> и шестой.<sup class="footnote-ref"><a href="#fn-e034-6" id="fnref-e034-6">[6]</a></sup></p>
<hr class="footnotes-sep">
<section class="footnotes">
<ol class="footnotes-list">
<li id="fn-e034-1" class="footnote-item"><p>Записные книжки. 1924. <a href="#fnref-e034-1" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e034-2" class="footnote-item"><p>Письма к редактору. 1931. Дополнительное уточнение занимает ещё одну строку. <a href="#fnref-e034-2" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e034-3" class="footnote-item"><p>Каталог собрания. № 17. <a href="#fnref-e034-3" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e034-4" class="footnote-item"><p>Авторский комментарий к изданию. <a href="#fnref-e034-4" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e034-5" class="footnote-item"><p>Предисловие. Страницы 12–14. <a href="#fnref-e034-5" class="footnote-backref">↩︎</a></p>
</li>
<li id="fn-e034-6" class="footnote-item"><p>Сопоставление двух редакций текста. <a href="#fnref-e034-6" class="footnote-backref">↩︎</a></p>
</li>
</ol>
</section>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 1. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
