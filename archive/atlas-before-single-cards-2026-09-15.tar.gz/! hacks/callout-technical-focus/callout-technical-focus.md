---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: focus
sources:
- https://help.obsidian.md/callouts
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: callout-technical-focus
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-technical-focus/Description.ru]]
