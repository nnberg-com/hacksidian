---
language: ru
translation_status: complete
title: Весь note реагирует на фокус ссылки
group: Контекст и длинный текст
---

# Весь note реагирует на фокус ссылки

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-focus
```

## Зачем

Помогает понять, в каком примечании находится клавиатурный фокус.

## Как работает

focus-within меняет рамку родителя при фокусе любой ссылки внутри.

## Ограничения исходного приёма

Нажмите Tab до ссылки. На hover можно назначить такой же визуальный акцент, но он не заменяет фокус.

## Пояснения из HTML-атласа

ЗачемПомогает понять, в каком примечании находится клавиатурный фокус.

Какfocus-within меняет рамку родителя при фокусе любой ссылки внутри.

Нажмите Tab до ссылки. На hover можно назначить такой же визуальный акцент, но он не заменяет фокус.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#focus>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@box:focus-within {outline:2px solid var(--tone);outline-offset:3px} @body a:focus-visible {outline:1px solid var(--tone);outline-offset:2px}
```

## Данные исходного каталога

```json
{
  "group": "detail",
  "key": "focus",
  "title": "Весь note реагирует на фокус ссылки",
  "why": "Помогает понять, в каком примечании находится клавиатурный фокус.",
  "how": "focus-within меняет рамку родителя при фокусе любой ссылки внутри.",
  "profile": "obsidian",
  "type": "note",
  "note": "Нажмите Tab до ссылки. На hover можно назначить такой же визуальный акцент, но он не заменяет фокус.",
  "source": "https://help.obsidian.md/callouts",
  "n": 60,
  "id": "c060"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="note" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Обратите внимание</div></div><div class="callout-content">
<p>Откройте <a href="https://help.obsidian.md/callouts" class="external-link" target="_blank" rel="noopener nofollow" aria-label="https://help.obsidian.md/callouts" data-tooltip-position="top">описание Callouts</a>, чтобы сверить синтаксис.</p>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 2. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
