---
tags:
- atlas/technique
- atlas/emphasis
category: emphasis
digest: []
source_anchor: s23
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: emphasis-s23
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/emphasis-s23/Description.ru]]
