---
language: ru
translation_status: complete
title: Таблица внутри примечания
group: Содержимое примечания
---

# Таблица внутри примечания

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-table
```

## Зачем

Справочные параметры с короткими значениями.

## Как работает

CSS оформляет table, которую поддерживаемый рендерер создал из Markdown внутри Callout.

## Пояснения из HTML-атласа

ЗачемСправочные параметры с короткими значениями.

КакCSS оформляет table, которую поддерживаемый рендерер создал из Markdown внутри Callout.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#table>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@body table {border-collapse:collapse;width:100%;font-size:.88em} @body th,@body td {padding:.5em;border-block-end:1px solid var(--edge);text-align:start} @body th {color:var(--tone)}
```

## Данные исходного каталога

```json
{
  "group": "content",
  "key": "table",
  "title": "Таблица внутри примечания",
  "why": "Справочные параметры с короткими значениями.",
  "how": "CSS оформляет table, которую поддерживаемый рендерер создал из Markdown внутри Callout.",
  "profile": "obsidian",
  "type": "note",
  "note": "",
  "source": "https://help.obsidian.md/callouts",
  "n": 52,
  "id": "c052"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="note" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Условия проверки</div></div><div class="callout-content">
<table>
<thead>
<tr>
<th>Параметр</th>
<th>Значение</th>
</tr>
</thead>
<tbody>
<tr>
<td>Ширина</td>
<td>390 px</td>
</tr>
<tr>
<td>Тема</td>
<td>Светлая</td>
</tr>
<tr>
<td>Режим</td>
<td>Чтение</td>
</tr>
</tbody>
</table>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 2. Используется штатных переменных: 2. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 2. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
