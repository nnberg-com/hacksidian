---
tags:
- atlas/technique
- atlas/emphasis
category: emphasis
digest: []
source_anchor: s03
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: emphasis-s03
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/emphasis-s03/Description.ru]]
