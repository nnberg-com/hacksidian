---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e003
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: footnote-e003
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e003/Description.ru]]
