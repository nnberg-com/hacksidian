---
language: ru
translation_status: complete
title: Светлая и тёмная палитра note
group: Среда и состояния
---

# Светлая и тёмная палитра note

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-dark
```

## Зачем

Читаемый Callout в обоих режимах просмотра.

## Как работает

Палитра задаётся через CSS-переменные; стенд переключает их без JavaScript.

## Ограничения исходного приёма

Включите «Тёмный стенд». В приложении эти переменные можно связать с его темой или prefers-color-scheme.

## Пояснения из HTML-атласа

ЗачемЧитаемый Callout в обоих режимах просмотра.

КакПалитра задаётся через CSS-переменные; стенд переключает их без JavaScript.

Включите «Тёмный стенд». В приложении эти переменные можно связать с его темой или prefers-color-scheme.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#dark>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@box {background:var(--wash);border:1px solid var(--edge)} @title {color:var(--tone)}
```

## Данные исходного каталога

```json
{
  "group": "states",
  "key": "dark",
  "title": "Светлая и тёмная палитра note",
  "why": "Читаемый Callout в обоих режимах просмотра.",
  "how": "Палитра задаётся через CSS-переменные; стенд переключает их без JavaScript.",
  "profile": "obsidian",
  "type": "note",
  "note": "Включите «Тёмный стенд». В приложении эти переменные можно связать с его темой или prefers-color-scheme.",
  "source": "https://help.obsidian.md/callouts",
  "n": 71,
  "id": "c071"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="note" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Обратите внимание</div></div><div class="callout-content">
<p>Изменения вступят в силу после повторного открытия файла. <strong>Сохраните результат</strong>, прежде чем продолжить.</p>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 3. Используется штатных переменных: 3. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 0. Случаев для отдельного решения: 2. [baseline.json](./baseline.json) · [Default.css](./Default.css)
