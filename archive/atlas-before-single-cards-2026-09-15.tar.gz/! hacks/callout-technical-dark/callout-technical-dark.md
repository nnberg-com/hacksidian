---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: dark
sources:
- https://help.obsidian.md/callouts
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-technical-dark
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-technical-dark/Description.ru]]
