---
language: ru
translation_status: complete
title: Тихий вложенный note
group: Композиция блока
---

# Тихий вложенный note

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-nested-quiet
```

## Зачем

Несколько уровней пояснения без нагромождения плашек.

## Как работает

У вложенного Callout остаются только линия и заголовок; фон убран.

## Ограничения исходного приёма

Только Obsidian: вложенные примечания.

## Пояснения из HTML-атласа

ЗачемНесколько уровней пояснения без нагромождения плашек.

КакУ вложенного Callout остаются только линия и заголовок; фон убран.

Только Obsidian: вложенные примечания.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#nested-quiet>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@box .callout {background:transparent;border:0;border-inline-start:2px solid var(--tone);border-radius:0;padding:.5em 1em}
```

## Данные исходного каталога

```json
{
  "group": "layout",
  "key": "nested-quiet",
  "title": "Тихий вложенный note",
  "why": "Несколько уровней пояснения без нагромождения плашек.",
  "how": "У вложенного Callout остаются только линия и заголовок; фон убран.",
  "profile": "obsidian",
  "type": "note",
  "note": "Только Obsidian: вложенные примечания.",
  "source": "https://help.obsidian.md/callouts",
  "n": 45,
  "id": "c045"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="note" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Контекст</div></div><div class="callout-content">
<p>Результат зависит от настроек среды.</p>
<div class="callout" data-callout="info" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Уточнение</div></div><div class="callout-content">
<p>Запишите версию рендерера рядом с примером.</p>
</div></div>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 1. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 0. Случаев для отдельного решения: 1. [baseline.json](./baseline.json) · [Default.css](./Default.css)
