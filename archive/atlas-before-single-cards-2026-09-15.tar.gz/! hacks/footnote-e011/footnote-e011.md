---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e011
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: footnote-e011
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e011/Description.ru]]
