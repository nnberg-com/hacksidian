---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e051
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: footnote-e051
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e051/Description.ru]]
