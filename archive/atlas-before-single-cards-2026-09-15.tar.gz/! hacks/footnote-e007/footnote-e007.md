---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e007
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: footnote-e007
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e007/Description.ru]]
