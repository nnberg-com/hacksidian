---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e042
sources:
- https://github.com/markdown-it/markdown-it-footnote
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: footnote-e042
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e042/Description.ru]]
