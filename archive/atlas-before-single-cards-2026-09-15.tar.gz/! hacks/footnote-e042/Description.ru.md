---
language: ru
translation_status: complete
title: Предпросмотр с задержкой закрытия
group: Предпросмотр при наведении
---

# Предпросмотр с задержкой закрытия

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Зачем

Дать время перевести указатель на ссылку в примечании.

## Как работает

Карточка изначально фиксирована и скрыта visibility. Уход запускает задержку 0.8s; наведение на карточку отменяет закрытие. :focus-visible и :target удерживают её при работе с клавиатурой.

## Демонстрация

Наведите на номер и переведите указатель в нижнюю карточку. Или нажмите номер, чтобы закрепить её. После ↩ отведите указатель; при работе с клавиатурой нажмите Tab, чтобы убрать предпросмотр.

## Ограничения исходного приёма

На устройствах с hover список заменён скрытыми карточками. На сенсорных экранах и при печати остаётся обычный список. Исходный порядок фокуса не меняется.

:has()

## Пояснения из HTML-атласа

Как Карточка изначально фиксирована и скрыта visibility. Уход запускает задержку 0.8s; наведение на карточку отменяет закрытие. :focus-visible и :target удерживают её при работе с клавиатурой.

Зачем Дать время перевести указатель на ссылку в примечании.

Условие На устройствах с hover список заменён скрытыми карточками. На сенсорных экранах и при печати остаётся обычный список. Исходный порядок фокуса не меняется.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/footnote-styles-demo/index.html#e042>)
- [Источник 1](https://github.com/markdown-it/markdown-it-footnote)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Общие условия исходного раздела

Подсветка и нижняя панель основаны на опубликованных приёмах. Варианты оформления и сочетания с :has() и якорями — адаптации для HTML выбранного Markdown-рендерера.

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@media screen and (hover:hover) {
.e042 #fn-e042-1 {position:fixed;z-index:30;box-sizing:border-box;max-block-size:42dvh;overflow:auto;padding:1.25rem 1.5rem 1.25rem 2.5rem;background:var(--paper);color:var(--ink);border:1px solid var(--line);box-shadow:0 12px 50px #0003;inset:auto 1rem 1rem auto;inline-size:min(30rem,calc(100% - 2rem));visibility:hidden;opacity:0;transition:opacity .12s .65s,visibility 0s .8s;}
.e042:has(a[href="#fn-e042-1"]:is(:hover,:focus-visible)) #fn-e042-1, .e042 #fn-e042-1:is(:hover,:focus-within,:target) {visibility:visible;opacity:1;transition-delay:0s;}
}
@media screen and (hover:hover) {
.e042 #fn-e042-2 {position:fixed;z-index:30;box-sizing:border-box;max-block-size:42dvh;overflow:auto;padding:1.25rem 1.5rem 1.25rem 2.5rem;background:var(--paper);color:var(--ink);border:1px solid var(--line);box-shadow:0 12px 50px #0003;inset:auto 1rem 1rem auto;inline-size:min(30rem,calc(100% - 2rem));visibility:hidden;opacity:0;transition:opacity .12s .65s,visibility 0s .8s;}
.e042:has(a[href="#fn-e042-2"]:is(:hover,:focus-visible)) #fn-e042-2, .e042 #fn-e042-2:is(:hover,:focus-within,:target) {visibility:visible;opacity:1;transition-delay:0s;}
}
```

## Данные исходного каталога

```json
{
  "id": "e042",
  "title": "Предпросмотр с задержкой закрытия",
  "how": "Карточка изначально фиксирована и скрыта visibility. Уход запускает задержку 0.8s; наведение на карточку отменяет закрытие. :focus-visible и :target удерживают её при работе с клавиатурой.",
  "why": "Дать время перевести указатель на ссылку в примечании.",
  "action": "Наведите на номер и переведите указатель в нижнюю карточку. Или нажмите номер, чтобы закрепить её. После ↩ отведите указатель; при работе с клавиатурой нажмите Tab, чтобы убрать предпросмотр.",
  "limit": "На устройствах с hover список заменён скрытыми карточками. На сенсорных экранах и при печати остаётся обычный список. Исходный порядок фокуса не меняется.",
  "support": ":has()",
  "group": "hover"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<p>Короткое уточнение может соседствовать с развёрнутым комментарием.<sup class="footnote-ref"><a href="#fn-e042-1" id="fnref-e042-1">[1]</a></sup> Ссылка на источник тоже остаётся обычной сноской.<sup class="footnote-ref"><a href="#fn-e042-2" id="fnref-e042-2">[2]</a></sup></p>
<hr class="footnotes-sep">
<section class="footnotes">
<ol class="footnotes-list">
<li id="fn-e042-1" class="footnote-item"><p><strong>Главная мысль примечания.</strong> Здесь есть <em>курсив</em> и несколько абзацев.</p>
<p>Второй абзац принадлежит той же сноске. Он не должен выглядеть как отдельное примечание.</p>
<ul>
<li>Первый довод.</li>
<li>Второй довод с <code>inline code</code>.</li>
</ul>
 <a href="#fnref-e042-1" class="footnote-backref">↩︎</a></li>
<li id="fn-e042-2" class="footnote-item"><p>Документация <a href="https://github.com/markdown-it/markdown-it-footnote">Markdown-it Footnote</a>. Длинные адреса и названия тоже должны помещаться в колонку. <a href="#fnref-e042-2" class="footnote-backref">↩︎</a></p>
</li>
</ol>
</section>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 12. Используется штатных переменных: 3. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
