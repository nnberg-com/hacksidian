---
language: ru
translation_status: complete
title: Хронология
group: ''
---

# Хронология

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-chronicle
```

## Зачем

Восстановить последовательность событий и увидеть переломные моменты.

## Как работает

Вложенные notes — события. Псевдоэлементы рисуют ось и узлы; счётчик CSS нумерует этапы.

## Ограничения исходного приёма

Ось показывает порядок, а не масштаб времени: расстояния между датами не вычисляются.

## Пояснения из HTML-атласа

Восстановить последовательность событий и увидеть переломные моменты.

Вложенные notes — события. Псевдоэлементы рисуют ось и узлы; счётчик CSS нумерует этапы.

Ось показывает порядок, а не масштаб времени: расстояния между датами не вычисляются.

Практика сообщества

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/index.html#chronicle>)
- [Источник 1](https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/timeline.html)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
[data-callout="chronicle"] {padding:24px;background:#f3ece5;color:#472c27}
[data-callout="chronicle"] > .callout-title {font-family:Georgia,serif;font-size:25px;margin-bottom:22px}
[data-callout="chronicle"] > .callout-content {counter-reset:event;padding-left:22px}
[data-callout="event"] {position:relative;margin:0;padding:0 0 28px 28px;border-left:2px solid #b9a096}
[data-callout="event"]::before {counter-increment:event;content:counter(event);position:absolute;left:-15px;top:0;width:28px;height:28px;display:grid;place-items:center;background:#8d4332;color:white;border-radius:50%;font-size:12px}
[data-callout="event"]:last-child {padding-bottom:0;border-color:transparent}
[data-callout="event"] > .callout-title {font-weight:750;color:#8d4332}
[data-callout="event"] p {margin-top:8px;font-size:14px}
```

## Данные исходного каталога

```json
{
  "key": "chronicle",
  "title": "Хронология",
  "role": "Восстановить последовательность событий и увидеть переломные моменты.",
  "how": "Вложенные notes — события. Псевдоэлементы рисуют ось и узлы; счётчик CSS нумерует этапы.",
  "ref": "https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/timeline.html",
  "limit": "Ось показывает порядок, а не масштаб времени: расстояния между датами не вычисляются."
}
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 2. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color, font; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 5. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
