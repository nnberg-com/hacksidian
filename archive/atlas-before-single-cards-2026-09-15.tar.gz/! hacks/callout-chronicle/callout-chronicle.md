---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: chronicle
sources:
- https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/timeline.html
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-chronicle
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-chronicle/Description.ru]]
