---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e024
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: footnote-e024
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e024/Description.ru]]
