---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e038
sources:
- https://github.com/markdown-it/markdown-it-footnote
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: footnote-e038
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e038/Description.ru]]
