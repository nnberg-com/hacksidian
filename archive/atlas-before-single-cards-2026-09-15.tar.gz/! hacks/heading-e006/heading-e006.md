---
tags:
- atlas/technique
- atlas/heading
category: heading
digest: []
source_anchor: e006
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: heading-e006
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/heading-e006/Description.ru]]
