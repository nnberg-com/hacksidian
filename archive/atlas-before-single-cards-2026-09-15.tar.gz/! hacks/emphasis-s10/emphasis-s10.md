---
tags:
- atlas/technique
- atlas/emphasis
category: emphasis
digest: []
source_anchor: s10
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: emphasis-s10
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/emphasis-s10/Description.ru]]
