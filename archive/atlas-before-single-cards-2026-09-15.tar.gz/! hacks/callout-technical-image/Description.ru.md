---
language: ru
translation_status: complete
title: Иллюстрация внутри NOTE
group: Содержимое примечания
---

# Иллюстрация внутри NOTE

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-image
```

## Зачем

Примечание, объясняющее конкретную картинку.

## Как работает

img ограничен шириной блока; обычный следующий курсивный абзац оформлен как подпись.

## Ограничения исходного приёма

Образец получен GitHub API. Локальные изображения Obsidian проходят отдельную обработку embeds внутри приложения.

## Пояснения из HTML-атласа

ЗачемПримечание, объясняющее конкретную картинку.

Какimg ограничен шириной блока; обычный следующий курсивный абзац оформлен как подпись.

Образец получен GitHub API. Локальные изображения Obsidian проходят отдельную обработку embeds внутри приложения.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#image>)
- [Источник 1](https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#alerts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bay.svg](<./assets/assets/bay.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@box img {display:block;width:100%;max-height:14em;object-fit:cover;border-radius:.35em} @box p:has(img) + p {font-size:.8em;color:var(--muted)}
```

## Данные исходного каталога

```json
{
  "group": "content",
  "key": "image",
  "title": "Иллюстрация внутри NOTE",
  "why": "Примечание, объясняющее конкретную картинку.",
  "how": "img ограничен шириной блока; обычный следующий курсивный абзац оформлен как подпись.",
  "profile": "github",
  "type": "note",
  "note": "Образец получен GitHub API. Локальные изображения Obsidian проходят отдельную обработку embeds внутри приложения.",
  "source": "https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#alerts",
  "n": 54,
  "id": "c054"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="markdown-alert markdown-alert-note"><p class="markdown-alert-title"><svg data-component="Octicon" class="octicon octicon-info mr-2" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8Zm8-6.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13ZM6.5 7.75A.75.75 0 0 1 7.25 7h1a.75.75 0 0 1 .75.75v2.75h.25a.75.75 0 0 1 0 1.5h-2a.75.75 0 0 1 0-1.5h.25v-2h-.25a.75.75 0 0 1-.75-.75ZM8 6a1 1 0 1 1 0-2 1 1 0 0 1 0 2Z"></path></svg>Note</p><p><a target="_blank" rel="noopener noreferrer" href="assets/bay.svg"><img src="assets/bay.svg" alt="Залив утром" style="max-width: 100%;"></a></p>
<p><em>Утренний свет до появления ветра.</em></p>
<p>Вернитесь к той же точке вечером.</p>
</div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 1. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
