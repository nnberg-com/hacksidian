---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e031
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e031
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e031/Description.ru]]
