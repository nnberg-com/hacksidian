---
language: ru
translation_status: complete
title: Временное раскрытие лога
group: Выделение и состояния
---

# Временное раскрытие лога

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
code-e045
```

## Зачем

Дать быстро просмотреть больше строк указателем.

## Как работает

При hover увеличивается max-height; основная прокрутка доступна всегда.

## Ограничения исходного приёма

Это не постоянный переключатель «раскрыть». Блок снова уменьшится при уходе указателя, сдвигая страницу.

## Пояснения из HTML-атласа

Дать быстро просмотреть больше строк указателем.

При hover увеличивается max-height; основная прокрутка доступна всегда.

Это не постоянный переключатель «раскрыть». Блок снова уменьшится при уходе указателя, сдвигая страницу.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/code-styles-demo/index.html#e045>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
S pre { max-height: 7rem; overflow: auto; }
@media (hover: hover) { S pre:hover { max-height: 24rem; } }
```

## Данные исходного каталога

```json
{
  "id": "e045",
  "group": "interaction",
  "title": "Временное раскрытие лога",
  "why": "Дать быстро просмотреть больше строк указателем.",
  "how": "При hover увеличивается max-height; основная прокрутка доступна всегда.",
  "note": "Это не постоянный переключатель «раскрыть». Блок снова уменьшится при уходе указателя, сдвигая страницу.",
  "kind": "Компромисс"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<pre><code>01:00  build · module_01  completed
02:00  build · module_02  completed
03:00  build · module_03  completed
04:00  build · module_04  completed
05:00  build · module_05  completed
06:00  build · module_06  completed
07:00  build · module_07  completed
08:00  build · module_08  completed
09:00  build · module_09  completed
10:00  build · module_10  completed
11:00  build · module_11  completed
12:00  build · module_12  completed
13:00  build · module_13  completed
14:00  build · module_14  completed
15:00  build · module_15  completed
16:00  build · module_16  completed
17:00  build · module_17  completed
18:00  build · module_18  completed
19:00  build · module_19  completed
20:00  build · module_20  completed
21:00  build · module_21  completed
22:00  build · module_22  completed
23:00  build · module_23  completed
24:00  build · module_24  completed
</code></pre>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
