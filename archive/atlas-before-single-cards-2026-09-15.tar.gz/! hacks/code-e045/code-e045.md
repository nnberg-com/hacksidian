---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e045
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: code-e045
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e045/Description.ru]]
