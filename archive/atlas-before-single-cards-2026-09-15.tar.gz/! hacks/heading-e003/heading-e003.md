---
tags:
- atlas/technique
- atlas/heading
category: heading
digest: []
source_anchor: e003
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: heading-e003
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/heading-e003/Description.ru]]
