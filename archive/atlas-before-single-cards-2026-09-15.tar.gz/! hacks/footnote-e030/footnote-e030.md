---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e030
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: footnote-e030
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e030/Description.ru]]
