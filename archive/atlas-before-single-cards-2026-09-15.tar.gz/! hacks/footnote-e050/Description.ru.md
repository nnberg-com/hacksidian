---
language: ru
translation_status: complete
title: Длинные адреса и код
group: Сложное содержимое и среда
---

# Длинные адреса и код

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
footnote-e050
```

## Зачем

Техническая документация не расширяет страницу.

## Как работает

overflow-wrap переносит непрерывный адрес; pre прокручивается внутри себя.

## Демонстрация

Сравните номер в тексте и примечания ниже.

## Ограничения исходного приёма

Обычный CSS

## Пояснения из HTML-атласа

Как overflow-wrap переносит непрерывный адрес; pre прокручивается внутри себя.

Зачем Техническая документация не расширяет страницу.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/footnote-styles-demo/index.html#e050>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Общие условия исходного раздела

Подсветка и нижняя панель основаны на опубликованных приёмах. Варианты оформления и сочетания с :has() и якорями — адаптации для HTML выбранного Markdown-рендерера.

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
.e050 .footnotes {overflow-wrap:anywhere;}
.e050 .footnotes pre {max-inline-size:100%;overflow:auto;white-space:pre;}
.e050 .footnotes code {font-size:.9em;}
```

## Данные исходного каталога

```json
{
  "id": "e050",
  "title": "Длинные адреса и код",
  "how": "overflow-wrap переносит непрерывный адрес; pre прокручивается внутри себя.",
  "why": "Техническая документация не расширяет страницу.",
  "action": "Сравните номер в тексте и примечания ниже.",
  "limit": "",
  "support": "Обычный CSS",
  "group": "resilience"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<p>Технические детали вынесены в сноску.<sup class="footnote-ref"><a href="#fn-e050-1" id="fnref-e050-1">[1]</a></sup></p>
<hr class="footnotes-sep">
<section class="footnotes">
<ol class="footnotes-list">
<li id="fn-e050-1" class="footnote-item"><p>https://example.org/archive/very-long-reference-without-spaces-and-with-many-different-details-and-a-long-document-identifier</p>
<pre><code class="language-css">.footnotes .footnote-item:target { outline: 2px solid currentColor; scroll-margin-block-start: 6rem; }
</code></pre>
 <a href="#fnref-e050-1" class="footnote-backref">↩︎</a></li>
</ol>
</section>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 1. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
