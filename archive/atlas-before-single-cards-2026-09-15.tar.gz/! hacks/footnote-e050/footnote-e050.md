---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e050
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: footnote-e050
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e050/Description.ru]]
