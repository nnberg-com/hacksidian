---
tags:
- atlas/technique
- atlas/heading
category: heading
digest: []
source_anchor: e013
sources:
- https://developer.mozilla.org/en-US/docs/Web/CSS/text-wrap
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: heading-e013
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/heading-e013/Description.ru]]
