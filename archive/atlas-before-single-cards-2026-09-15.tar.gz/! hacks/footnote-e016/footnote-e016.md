---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e016
sources:
- https://github.com/markdown-it/markdown-it-footnote
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: footnote-e016
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e016/Description.ru]]
