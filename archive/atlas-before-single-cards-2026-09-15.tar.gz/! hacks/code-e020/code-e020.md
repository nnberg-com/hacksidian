---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e020
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e020
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e020/Description.ru]]
