---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e032
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e032
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e032/Description.ru]]
