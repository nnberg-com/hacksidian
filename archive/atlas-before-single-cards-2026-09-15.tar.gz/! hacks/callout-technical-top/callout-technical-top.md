---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: top
sources:
- https://help.obsidian.md/callouts
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-technical-top
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-technical-top/Description.ru]]
