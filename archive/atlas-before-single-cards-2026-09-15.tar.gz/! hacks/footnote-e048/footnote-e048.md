---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e048
sources:
- https://github.com/markdown-it/markdown-it-footnote
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: footnote-e048
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e048/Description.ru]]
