---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: double-rail
sources:
- https://help.obsidian.md/callouts
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-technical-double-rail
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-technical-double-rail/Description.ru]]
