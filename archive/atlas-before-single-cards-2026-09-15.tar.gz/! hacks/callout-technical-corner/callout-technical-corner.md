---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: corner
sources:
- https://help.obsidian.md/callouts
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-technical-corner
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-technical-corner/Description.ru]]
