---
tags:
- atlas/technique
- atlas/heading
category: heading
digest: []
source_anchor: e009
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: heading-e009
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/heading-e009/Description.ru]]
