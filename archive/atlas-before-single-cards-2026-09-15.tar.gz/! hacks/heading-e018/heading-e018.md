---
tags:
- atlas/technique
- atlas/heading
category: heading
digest: []
source_anchor: e018
sources:
- https://developer.mozilla.org/en-US/docs/Web/CSS/text-box-trim
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: heading-e018
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/heading-e018/Description.ru]]
