---
language: ru
translation_status: complete
title: Поля адаптируются к ширине
group: Контекст и длинный текст
---

# Поля адаптируются к ширине

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-mobile
```

## Зачем

Один Callout в основной колонке и на мобильном экране.

## Как работает

Контейнерный запрос уменьшает поля и расстояние между значком и названием.

## Ограничения исходного приёма

Узкую полосу можно включить в верхней панели стенда.

## Пояснения из HTML-атласа

ЗачемОдин Callout в основной колонке и на мобильном экране.

КакКонтейнерный запрос уменьшает поля и расстояние между значком и названием.

Узкую полосу можно включить в верхней панели стенда.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#mobile>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@box {padding:1.5em} @container preview (max-width:340px) {@box {padding:.75em} @title {gap:.35em;font-size:.95em}}
```

## Данные исходного каталога

```json
{
  "group": "detail",
  "key": "mobile",
  "title": "Поля адаптируются к ширине",
  "why": "Один Callout в основной колонке и на мобильном экране.",
  "how": "Контейнерный запрос уменьшает поля и расстояние между значком и названием.",
  "profile": "obsidian",
  "type": "note",
  "note": "Узкую полосу можно включить в верхней панели стенда.",
  "source": "https://help.obsidian.md/callouts",
  "n": 62,
  "id": "c062"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="note" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Примечание должно оставаться читаемым на узком экране</div></div><div class="callout-content">
<p>Изменения вступят в силу после повторного открытия файла. <strong>Сохраните результат</strong>, прежде чем продолжить.</p>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
