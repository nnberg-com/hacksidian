---
language: ru
translation_status: complete
title: Примечание внутри примечания
group: Композиция блока
---

# Примечание внутри примечания

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-nested
```

## Зачем

Общий совет с уточняющим предупреждением.

## Как работает

Obsidian создаёт вложенные callout; тип дочернего блока определяет его собственный цвет.

## Ограничения исходного приёма

Вложенность — возможность Obsidian. GitHub Alerts вложение не поддерживают.

## Пояснения из HTML-атласа

ЗачемОбщий совет с уточняющим предупреждением.

КакObsidian создаёт вложенные callout; тип дочернего блока определяет его собственный цвет.

Вложенность — возможность Obsidian. GitHub Alerts вложение не поддерживают.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#nested>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@box .callout {margin-block:1em 0;border:1px solid var(--edge);background:var(--paper)}
```

## Данные исходного каталога

```json
{
  "group": "layout",
  "key": "nested",
  "title": "Примечание внутри примечания",
  "why": "Общий совет с уточняющим предупреждением.",
  "how": "Obsidian создаёт вложенные callout; тип дочернего блока определяет его собственный цвет.",
  "profile": "obsidian",
  "type": "note",
  "note": "Вложенность — возможность Obsidian. GitHub Alerts вложение не поддерживают.",
  "source": "https://help.obsidian.md/callouts",
  "n": 44,
  "id": "c044"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="tip" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Перед изменениями</div></div><div class="callout-content">
<p>Сначала сохраните исходник.</p>
<div class="callout" data-callout="warning" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Проверьте путь</div></div><div class="callout-content">
<p>Не перезаписывайте единственную копию.</p>
</div></div>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 2. Используется штатных переменных: 2. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 0. Случаев для отдельного решения: 2. [baseline.json](./baseline.json) · [Default.css](./Default.css)
