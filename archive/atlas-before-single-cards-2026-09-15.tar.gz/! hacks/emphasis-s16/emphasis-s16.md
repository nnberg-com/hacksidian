---
tags:
- atlas/technique
- atlas/emphasis
category: emphasis
digest: []
source_anchor: s16
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: emphasis-s16
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/emphasis-s16/Description.ru]]
