---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e017
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: footnote-e017
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e017/Description.ru]]
