---
language: ru
translation_status: complete
title: Три уровня уточнения
group: Композиция блока
---

# Три уровня уточнения

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-three-levels
```

## Зачем

Вложенное объяснение со строго ограниченной глубиной.

## Как работает

Каждый внутренний блок получает меньшие поля; контейнеры уже создаёт Obsidian.

## Ограничения исходного приёма

GitHub не поддерживает эту структуру. Большая глубина быстро съедает ширину.

## Пояснения из HTML-атласа

ЗачемВложенное объяснение со строго ограниченной глубиной.

КакКаждый внутренний блок получает меньшие поля; контейнеры уже создаёт Obsidian.

GitHub не поддерживает эту структуру. Большая глубина быстро съедает ширину.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#three-levels>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@box .callout {padding:.65em;border-width:1px} @box .callout .callout {background:var(--paper);border-style:dashed}
```

## Данные исходного каталога

```json
{
  "group": "layout",
  "key": "three-levels",
  "title": "Три уровня уточнения",
  "why": "Вложенное объяснение со строго ограниченной глубиной.",
  "how": "Каждый внутренний блок получает меньшие поля; контейнеры уже создаёт Obsidian.",
  "profile": "obsidian",
  "type": "note",
  "note": "GitHub не поддерживает эту структуру. Большая глубина быстро съедает ширину.",
  "source": "https://help.obsidian.md/callouts",
  "n": 46,
  "id": "c046"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="question" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Как повторить результат?</div></div><div class="callout-content">
<div class="callout" data-callout="todo" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Сохранить условия</div></div><div class="callout-content">
<div class="callout" data-callout="example" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Минимальный пример</div></div><div class="callout-content">
<p>Один заголовок и один абзац.</p>
</div></div>
</div></div>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 1. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 0. Случаев для отдельного решения: 2. [baseline.json](./baseline.json) · [Default.css](./Default.css)
