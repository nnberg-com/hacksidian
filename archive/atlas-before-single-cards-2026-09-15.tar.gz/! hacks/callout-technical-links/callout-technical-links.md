---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: links
sources:
- https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#alerts
- https://help.obsidian.md/callouts
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: callout-technical-links
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-technical-links/Description.ru]]
