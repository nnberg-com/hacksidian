---
language: ru
translation_status: complete
title: Источники внутри INFO
group: Содержимое примечания
---

# Источники внутри INFO

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-links
```

## Зачем

Сопроводительные ссылки к основному тексту.

## Как работает

Ссылки наследуют цвет типа, но сохраняют подчёркивание и клавиатурный фокус.

## Пояснения из HTML-атласа

ЗачемСопроводительные ссылки к основному тексту.

КакСсылки наследуют цвет типа, но сохраняют подчёркивание и клавиатурный фокус.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#links>)
- [Источник 1](https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#alerts)
- [Источник 2](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@body a {color:var(--tone);text-underline-offset:.2em} @body a:focus-visible {outline:2px solid var(--tone);outline-offset:3px}
```

## Данные исходного каталога

```json
{
  "group": "content",
  "key": "links",
  "title": "Источники внутри INFO",
  "why": "Сопроводительные ссылки к основному тексту.",
  "how": "Ссылки наследуют цвет типа, но сохраняют подчёркивание и клавиатурный фокус.",
  "profile": "obsidian",
  "type": "info",
  "note": "",
  "source": "https://help.obsidian.md/callouts",
  "n": 55,
  "id": "c055"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="info" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Подробнее о формате</div></div><div class="callout-content">
<ul>
<li data-line="1"><a href="https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#alerts" class="external-link" target="_blank" rel="noopener nofollow" aria-label="https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#alerts" data-tooltip-position="top">GitHub Alerts</a></li>
<li data-line="2"><a href="https://help.obsidian.md/callouts" class="external-link" target="_blank" rel="noopener nofollow" aria-label="https://help.obsidian.md/callouts" data-tooltip-position="top">Obsidian Callouts</a></li>
</ul>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 2. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
