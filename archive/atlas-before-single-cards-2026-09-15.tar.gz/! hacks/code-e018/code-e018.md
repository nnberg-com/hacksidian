---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e018
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: code-e018
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e018/Description.ru]]
