---
language: ru
translation_status: complete
title: Мягкий перенос
group: Ширина и прокрутка
---

# Мягкий перенос

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
code-e018
```

## Зачем

Читать длинный текстовый вывод без горизонтального перемещения.

## Как работает

pre-wrap сохраняет пробелы и разрешает перенос по возможным границам.

## Пояснения из HTML-атласа

Читать длинный текстовый вывод без горизонтального перемещения.

pre-wrap сохраняет пробелы и разрешает перенос по возможным границам.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/code-styles-demo/index.html#e018>)
- Отдельная внешняя ссылка для этого приёма в исходной карточке не указана.

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
S pre { white-space: pre-wrap; }
```

## Данные исходного каталога

```json
{
  "id": "e018",
  "group": "flow",
  "title": "Мягкий перенос",
  "why": "Читать длинный текстовый вывод без горизонтального перемещения.",
  "how": "pre-wrap сохраняет пробелы и разрешает перенос по возможным границам.",
  "note": "",
  "kind": "Обычный Markdown"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<pre><code>GET /api/search?query=markdown&amp;include=examples,notes,references&amp;sort=updated_at&amp;direction=descending HTTP/1.1
Authorization: Bearer example_token_for_documentation_only
Accept: application/json

{&quot;status&quot;:&quot;ok&quot;,&quot;message&quot;:&quot;A deliberately long response that demonstrates horizontal scrolling and soft wrapping without changing the source text.&quot;}
</code></pre>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
