---
tags:
- atlas/technique
- atlas/callout
category: callout
digest:
- teach
source_anchor: storyboard
sources:
- https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/comic.html
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-storyboard
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-storyboard/Description.ru]]
