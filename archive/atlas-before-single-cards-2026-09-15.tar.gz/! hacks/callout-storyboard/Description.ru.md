---
language: ru
translation_status: complete
title: Раскадровка
group: ''
---

# Раскадровка

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-storyboard
```

## Зачем

Объяснить последовательность действий через сцены и короткие реплики.

## Как работает

Вложенные callouts — панели. Изображения и абзацы располагаются в общей ячейке Grid; реплика накладывается на нижнюю часть кадра.

## Пояснения из HTML-атласа

Объяснить последовательность действий через сцены и короткие реплики.

Вложенные callouts — панели. Изображения и абзацы располагаются в общей ячейке Grid; реплика накладывается на нижнюю часть кадра.

Практика сообщества

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/index.html#storyboard>)
- [Источник 1](https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/comic.html)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/camera.svg](<./assets/assets/camera.svg>)
- [assets/assets/notebook.svg](<./assets/assets/notebook.svg>)
- [assets/assets/station.svg](<./assets/assets/station.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
[data-callout="storyboard"] {padding:20px;background:#f8db57;border:3px solid #242424;color:#242424;box-shadow:6px 6px 0 #242424}
[data-callout="storyboard"] > .callout-title {font-size:24px;font-weight:850;text-transform:uppercase;line-height:1.1;margin-bottom:20px}
[data-callout="storyboard"] > .callout-content {display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,170px),1fr));gap:12px}
[data-callout="panel"] {border:2px solid #242424;background:white}
[data-callout="panel"] > .callout-title {padding:8px 10px;font-size:12px;background:#242424;color:white}
[data-callout="panel"] > .callout-content {display:grid;min-height:230px}
[data-callout="panel"] p {grid-area:1/1;margin:0}
[data-callout="panel"] p:first-child {align-self:stretch}
[data-callout="panel"] img {width:100%;height:100%;object-fit:cover}
[data-callout="panel"] p:last-child {align-self:end;z-index:1;margin:12px;padding:10px;background:white;border:2px solid #242424;border-radius:15px 15px 15px 0;font-size:13px;font-weight:700}
```

## Данные исходного каталога

```json
{
  "key": "storyboard",
  "title": "Раскадровка",
  "role": "Объяснить последовательность действий через сцены и короткие реплики.",
  "how": "Вложенные callouts — панели. Изображения и абзацы располагаются в общей ячейке Grid; реплика накладывается на нижнюю часть кадра.",
  "ref": "https://elsatam.github.io/obsidian-fancy-a-story/docs/callouts/comic.html",
  "limit": ""
}
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 5. Используется штатных переменных: 3. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 7. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
