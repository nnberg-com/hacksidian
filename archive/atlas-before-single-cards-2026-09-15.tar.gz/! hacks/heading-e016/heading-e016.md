---
tags:
- atlas/technique
- atlas/heading
category: heading
digest: []
source_anchor: e016
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: heading-e016
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/heading-e016/Description.ru]]
