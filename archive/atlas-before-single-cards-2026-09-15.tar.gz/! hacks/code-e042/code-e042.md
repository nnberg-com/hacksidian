---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e042
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: code-e042
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e042/Description.ru]]
