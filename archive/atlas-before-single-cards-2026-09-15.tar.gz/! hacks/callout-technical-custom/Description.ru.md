---
language: ru
translation_status: complete
title: Собственный тип Callout
group: Композиция блока
---

# Собственный тип Callout

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-custom
```

## Зачем

Доменная пометка: решение, эксперимент, допущение.

## Как работает

[!decision] создаёт data-callout="decision". CSS выбирает этот тип; ручных HTML-атрибутов нет.

## Ограничения исходного приёма

Неизвестный тип без CSS получает стандартное оформление note. Здесь внешний вид определён явно.

## Пояснения из HTML-атласа

ЗачемДоменная пометка: решение, эксперимент, допущение.

Как[!decision] создаёт data-callout="decision". CSS выбирает этот тип; ручных HTML-атрибутов нет.

Неизвестный тип без CSS получает стандартное оформление note. Здесь внешний вид определён явно.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#custom>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
& .callout[data-callout="decision"] {--tone:color-mix(in srgb,#947035 65%,var(--ink));border-inline-start:4px solid var(--tone)}
```

## Данные исходного каталога

```json
{
  "group": "layout",
  "key": "custom",
  "title": "Собственный тип Callout",
  "why": "Доменная пометка: решение, эксперимент, допущение.",
  "how": "[!decision] создаёт data-callout=\"decision\". CSS выбирает этот тип; ручных HTML-атрибутов нет.",
  "profile": "obsidian",
  "type": "decision",
  "note": "Неизвестный тип без CSS получает стандартное оформление note. Здесь внешний вид определён явно.",
  "source": "https://help.obsidian.md/callouts",
  "n": 47,
  "id": "c047"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="decision" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Принятое решение</div></div><div class="callout-content">
<p>Сохраняем исходники рядом с результатом. Пересмотрим это правило, если структура проекта изменится.</p>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 1. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
