---
tags:
- atlas/technique
- atlas/callout
category: callout
digest:
- management
source_anchor: board
sources:
- https://github.com/SlRvb/Obsidian--ITS-Theme/blob/main/Guide/Callouts.md
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-board
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-board/Description.ru]]
