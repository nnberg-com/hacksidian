---
language: ru
translation_status: complete
title: Доска состояния
group: ''
---

# Доска состояния

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-board
```

## Зачем

Показать, на каком этапе находятся работы, прямо внутри отчёта.

## Как работает

Внешний callout — доска, вложенные — колонки, пункты списков — карточки. Вся структура хранится в Markdown.

## Ограничения исходного приёма

Доска статическая: переносить карточки можно изменением Markdown. Перетаскивания нет.

## Пояснения из HTML-атласа

Показать, на каком этапе находятся работы, прямо внутри отчёта.

Внешний callout — доска, вложенные — колонки, пункты списков — карточки. Вся структура хранится в Markdown.

Доска статическая: переносить карточки можно изменением Markdown. Перетаскивания нет.

Практика сообщества

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/index.html#board>)
- [Источник 1](https://github.com/SlRvb/Obsidian--ITS-Theme/blob/main/Guide/Callouts.md)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
[data-callout="board"] {padding:20px;background:#e9eae8;border-radius:10px}
[data-callout="board"] > .callout-title {font-size:21px;margin-bottom:20px}
[data-callout="board"] > .callout-content {display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
[data-callout="lane"] > .callout-title {font-size:12px;text-transform:uppercase;letter-spacing:.06em;border-top:4px solid #b9ada0;padding-top:10px}
[data-callout="lane"]:nth-child(2) > .callout-title {border-color:#d4a349}
[data-callout="lane"]:nth-child(3) > .callout-title {border-color:#568a75}
[data-callout="lane"] ul {list-style:none;padding:0;margin-top:15px}
[data-callout="lane"] li {padding:12px;background:white;border-radius:4px;margin-bottom:10px;box-shadow:0 2px 0 #d3d5d1;font-size:13px}
@media(max-width:650px){[data-callout="board"] > .callout-content {grid-template-columns:1fr}}
```

## Данные исходного каталога

```json
{
  "key": "board",
  "title": "Доска состояния",
  "role": "Показать, на каком этапе находятся работы, прямо внутри отчёта.",
  "how": "Внешний callout — доска, вложенные — колонки, пункты списков — карточки. Вся структура хранится в Markdown.",
  "ref": "https://github.com/SlRvb/Obsidian--ITS-Theme/blob/main/Guide/Callouts.md",
  "limit": "Доска статическая: переносить карточки можно изменением Markdown. Перетаскивания нет."
}
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 3. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 9. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
