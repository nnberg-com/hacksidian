---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e028
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: footnote-e028
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e028/Description.ru]]
