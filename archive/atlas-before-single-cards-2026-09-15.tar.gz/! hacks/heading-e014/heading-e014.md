---
tags:
- atlas/technique
- atlas/heading
category: heading
digest: []
source_anchor: e014
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: heading-e014
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/heading-e014/Description.ru]]
