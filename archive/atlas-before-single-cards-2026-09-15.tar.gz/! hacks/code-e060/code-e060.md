---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e060
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: code-e060
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e060/Description.ru]]
