---
tags:
- atlas/technique
- atlas/code
category: code
digest: []
source_anchor: e044
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: true
id: code-e044
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/code-e044/Description.ru]]
