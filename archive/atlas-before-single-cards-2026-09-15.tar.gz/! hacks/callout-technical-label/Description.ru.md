---
language: ru
translation_status: complete
title: Заголовок-ярлычок
group: Заголовок и значок
---

# Заголовок-ярлычок

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Зачем

Небольшая пометка на рамке примечания.

## Как работает

Заголовок шириной по содержимому смещён вверх отрицательным margin, под ним непрозрачный фон. Сверху оставлен запас места.

## Пояснения из HTML-атласа

ЗачемНебольшая пометка на рамке примечания.

КакЗаголовок шириной по содержимому смещён вверх отрицательным margin, под ним непрозрачный фон. Сверху оставлен запас места.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#label>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
& {padding-block-start:.8em} @box {background:var(--paper);border:1px solid var(--tone);margin-block-start:.7em} @title {width:fit-content;max-width:100%;background:var(--paper);padding-inline:.5em;margin-block-start:-1.8em;margin-inline-start:-.3em}
```

## Данные исходного каталога

```json
{
  "group": "title",
  "key": "label",
  "title": "Заголовок-ярлычок",
  "why": "Небольшая пометка на рамке примечания.",
  "how": "Заголовок шириной по содержимому смещён вверх отрицательным margin, под ним непрозрачный фон. Сверху оставлен запас места.",
  "profile": "obsidian",
  "type": "note",
  "note": "",
  "source": "https://help.obsidian.md/callouts",
  "n": 34,
  "id": "c034"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="note" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Обратите внимание</div></div><div class="callout-content">
<p>Изменения вступят в силу после повторного открытия файла. <strong>Сохраните результат</strong>, прежде чем продолжить.</p>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 5. Используется штатных переменных: 4. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 1. Случаев для отдельного решения: 2. [baseline.json](./baseline.json) · [Default.css](./Default.css)
