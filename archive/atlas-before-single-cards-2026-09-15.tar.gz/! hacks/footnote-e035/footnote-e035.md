---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e035
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: footnote-e035
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e035/Description.ru]]
