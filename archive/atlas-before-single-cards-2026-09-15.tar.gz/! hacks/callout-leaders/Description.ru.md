---
language: ru
translation_status: complete
title: Программа с отточиями
group: ''
---

# Программа с отточиями

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-leaders
```

## Зачем

Связать название и значение взглядом: программа дня, оглавление, меню или перечень расходов.

## Как работает

Каждый абзац содержит название, следующая вложенная цитата — время. Grid собирает пары, повторяющийся фон рисует точки между колонками.

## Ограничения исходного приёма

Пары должны идти в порядке «абзац → цитата». Значения берутся из Markdown, а не вычисляются.

## Пояснения из HTML-атласа

Связать название и значение взглядом: программа дня, оглавление, меню или перечень расходов.

Каждый абзац содержит название, следующая вложенная цитата — время. Grid собирает пары, повторяющийся фон рисует точки между колонками.

Пары должны идти в порядке «абзац → цитата». Значения берутся из Markdown, а не вычисляются.

sailKite

В оригинале заголовок скрыт. Здесь он сохранён как название программы. Изменены палитра и типографика; принцип пар «абзац

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/index.html#leaders>)
- [Источник 1](https://github.com/r-u-s-h-i-k-e-s-h/Obsidian-CSS-Snippets/blob/Collection/snippets/callout%20styling%20-%20leader%20list.md)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
[data-callout="leaders"] {background:#f4c6d0;color:#322332;padding:30px 24px;border:1px solid #322332;box-shadow:5px 5px 0 #322332}
[data-callout="leaders"] > .callout-title {font-size:32px;font-weight:850;line-height:1.04;letter-spacing:-.035em;padding-bottom:24px;border-bottom:3px solid #322332;margin-bottom:25px;max-width:100%}
[data-callout="leaders"] > .callout-content {display:grid;grid-template-columns:minmax(0,1fr) auto;column-gap:10px;row-gap:22px;align-items:baseline}
[data-callout="leaders"] > .callout-content > p {display:flex;gap:10px;align-items:baseline;margin:0;font-size:14px}
[data-callout="leaders"] > .callout-content > p::after {content:"";flex:1;min-width:16px;height:3px;background:radial-gradient(circle,currentColor 1px,transparent 1.5px) left bottom / 7px 3px repeat-x}
[data-callout="leaders"] > .callout-content > blockquote {border:0;padding:0;margin:0;font-size:20px;font-weight:800;font-variant-numeric:tabular-nums}
[data-callout="leaders"] blockquote p {margin:0}
```

## Данные исходного каталога

```json
{
  "key": "leaders",
  "title": "Программа с отточиями",
  "role": "Связать название и значение взглядом: программа дня, оглавление, меню или перечень расходов.",
  "how": "Каждый абзац содержит название, следующая вложенная цитата — время. Grid собирает пары, повторяющийся фон рисует точки между колонками.",
  "ref": "https://github.com/r-u-s-h-i-k-e-s-h/Obsidian-CSS-Snippets/blob/Collection/snippets/callout%20styling%20-%20leader%20list.md",
  "limit": "Пары должны идти в порядке «абзац → цитата». Значения берутся из Markdown, а не вычисляются.",
  "author": "sailKite",
  "adaptation": "В оригинале заголовок скрыт. Здесь он сохранён как название программы. Изменены палитра и типографика; принцип пар «абзац
}
```


## Опора на стандартную тему

Связи с темой проверены; изменений: 4. Используется штатных переменных: 2. Геометрия и механика эффекта сохранены. Требуют отдельного решения: literal-color; детали в baseline.json.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.

## Уточнение опорных переменных

Уточнено привязок: 6. Случаев для отдельного решения: 0. [baseline.json](./baseline.json) · [Default.css](./Default.css)
