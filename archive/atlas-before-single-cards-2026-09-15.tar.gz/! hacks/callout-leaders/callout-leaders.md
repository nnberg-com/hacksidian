---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: leaders
sources:
- https://github.com/r-u-s-h-i-k-e-s-h/Obsidian-CSS-Snippets/blob/Collection/snippets/callout%20styling%20-%20leader%20list.md
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-leaders
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-leaders/Description.ru]]
