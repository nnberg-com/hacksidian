---
tags:
- atlas/technique
- atlas/heading
category: heading
digest: []
source_anchor: e007
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: heading-e007
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/heading-e007/Description.ru]]
