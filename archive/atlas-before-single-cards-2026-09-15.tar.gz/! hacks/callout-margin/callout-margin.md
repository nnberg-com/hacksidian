---
tags:
- atlas/technique
- atlas/callout
category: callout
digest: []
source_anchor: margin
sources:
- https://github.com/efemkay/obsidian-modular-css-layout#float-callout
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: callout-margin
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/callout-margin/Description.ru]]
