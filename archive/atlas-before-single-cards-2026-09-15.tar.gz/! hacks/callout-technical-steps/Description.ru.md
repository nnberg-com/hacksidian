---
language: ru
translation_status: complete
title: Мини-инструкция внутри TIP
group: Содержимое примечания
---

# Мини-инструкция внутри TIP

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-steps
```

## Зачем

Совет, который требует нескольких действий.

## Как работает

Нумерованный Markdown-список остаётся внутри того же блока Callout.

## Пояснения из HTML-атласа

ЗачемСовет, который требует нескольких действий.

КакНумерованный Markdown-список остаётся внутри того же блока Callout.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#steps>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@body ol {padding-inline-start:1.4em} @body li {padding-inline-start:.3em;margin-block:.55em} @body li::marker {color:var(--tone);font-weight:700}
```

## Данные исходного каталога

```json
{
  "group": "content",
  "key": "steps",
  "title": "Мини-инструкция внутри TIP",
  "why": "Совет, который требует нескольких действий.",
  "how": "Нумерованный Markdown-список остаётся внутри того же блока Callout.",
  "profile": "obsidian",
  "type": "tip",
  "note": "",
  "source": "https://help.obsidian.md/callouts",
  "n": 50,
  "id": "c050"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="tip" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Повторить проверку</div></div><div class="callout-content">
<ol>
<li data-line="1">Откройте исходную заметку.</li>
<li data-line="2">Измените ширину окна.</li>
<li data-line="3">Сравните переносы заголовка.</li>
</ol>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 2. Используется штатных переменных: 2. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
