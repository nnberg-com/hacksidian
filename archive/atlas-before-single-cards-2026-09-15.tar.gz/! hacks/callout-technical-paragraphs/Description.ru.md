---
language: ru
translation_status: complete
title: Многоабзацное примечание
group: Содержимое примечания
---

# Многоабзацное примечание

[Открыть Markdown-пример](./Markdown.ru.md) · [CSS приёма](./recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
callout-technical-paragraphs
```

## Зачем

Объяснение, которое нельзя сжать до одного предложения.

## Как работает

Первый и последний абзацы не добавляют лишних внешних отступов; между абзацами сохранён ритм.

## Пояснения из HTML-атласа

ЗачемОбъяснение, которое нельзя сжать до одного предложения.

КакПервый и последний абзацы не добавляют лишних внешних отступов; между абзацами сохранён ритм.

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/callout-styles-demo/technical-atlas.html#paragraphs>)
- [Источник 1](https://help.obsidian.md/callouts)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Локальные зависимости

- [assets/assets/abstract.svg](<./assets/assets/abstract.svg>)
- [assets/assets/bug.svg](<./assets/assets/bug.svg>)
- [assets/assets/danger.svg](<./assets/assets/danger.svg>)
- [assets/assets/example.svg](<./assets/assets/example.svg>)
- [assets/assets/failure.svg](<./assets/assets/failure.svg>)
- [assets/assets/info.svg](<./assets/assets/info.svg>)
- [assets/assets/note.svg](<./assets/assets/note.svg>)
- [assets/assets/question.svg](<./assets/assets/question.svg>)
- [assets/assets/quote.svg](<./assets/assets/quote.svg>)
- [assets/assets/success.svg](<./assets/assets/success.svg>)
- [assets/assets/tip.svg](<./assets/assets/tip.svg>)
- [assets/assets/todo.svg](<./assets/assets/todo.svg>)
- [assets/assets/warning.svg](<./assets/assets/warning.svg>)

## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
@body p {margin-block:.8em} @body > :first-child {margin-top:0} @body > :last-child {margin-bottom:0}
```

## Данные исходного каталога

```json
{
  "group": "content",
  "key": "paragraphs",
  "title": "Многоабзацное примечание",
  "why": "Объяснение, которое нельзя сжать до одного предложения.",
  "how": "Первый и последний абзацы не добавляют лишних внешних отступов; между абзацами сохранён ритм.",
  "profile": "obsidian",
  "type": "note",
  "note": "",
  "source": "https://help.obsidian.md/callouts",
  "n": 56,
  "id": "c056"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<div class="callout" data-callout="note" data-callout-fold="" data-callout-metadata=""><div class="callout-title"><div class="callout-icon"></div><div class="callout-title-inner">Почему результат отличается</div></div><div class="callout-content">
<p>Один и тот же Markdown может создавать разную HTML-структуру в разных приложениях.</p>
<p>CSS работает с уже созданными элементами. Поэтому перенос темы начинается с проверки структуры заголовка и тела.</p>
<p><strong>Сохраните пример и версию рендерера</strong>, чтобы повторить сравнение позже.</p>
</div></div>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 0. Используется штатных переменных: 0. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](./Default.css) · [Данные привязки и нерешённые случаи](./baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
