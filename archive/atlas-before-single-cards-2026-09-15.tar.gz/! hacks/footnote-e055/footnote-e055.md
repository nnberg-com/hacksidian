---
tags:
- atlas/technique
- atlas/footnote
category: footnote
digest: []
source_anchor: e055
sources: []
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: footnote-e055
description: Description.ru.md
---

![[! P R O/hacksidian/atlas/! hacks/footnote-e055/Description.ru]]
