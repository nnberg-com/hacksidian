---
language: ru
translation_status: complete
title: Номер в отдельном визуальном поле
group: Декор и нумерация
---

# Номер в отдельном визуальном поле

[Открыть Markdown-пример](!%20P%20R%20O/hacksidian/atlas/!%20hacks/tag-e041/table-e067/Markdown.ru.md) · [CSS приёма](!%20P%20R%20O/hacksidian/atlas/!%20hacks/tag-e041/table-e067/recipe.css) · [[atlas|Атлас]]

## Живой пример в Obsidian

```hacksidian-live
table-e067
```

## Зачем

Нумерация отделена от названия без добавления реальной колонки.

## Как работает

before имеет фиксированную ширину и inline-block.

## Ограничения исходного приёма

Это часть первой ячейки; в HTML дополнительного столбца нет.

## Пояснения из HTML-атласа

Нумерация отделена от названия без добавления реальной колонки.

before имеет фиксированную ширину и inline-block.

Это часть первой ячейки; в HTML дополнительного столбца нет.

Документация ↗

## Источники

- [Исходный пример HTML](</Users/op/dev/olgapavlova/hacksidian/atlas/sources/table-styles-demo/index.html#e067>)
- [Источник 1](https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Counter_styles/Using_counters)

## Использование в Obsidian

`recipe.css` — единый CSS приёма. Атлас подключает его без изменений в изолированный пример; кнопка «Применить hack» записывает тот же CSS в целевой сниппет. Дополнительный класс заметки для подключения не нужен. Селекторы самого приёма определяют нужные элементы и режим Obsidian. Повторное применение обновляет блок; Undo возвращает предыдущий CSS.
## Исходный CSS рецепта

Точная версия до замены селектора контейнера; условные обозначения `&`, `S` и классы стенда принадлежат исходному атласу.

```css
& tbody {counter-reset:row} & tbody>tr {counter-increment:row} & td:first-child::before {content:counter(row,decimal-leading-zero);display:inline-block;width:2.3em;margin-inline-end:.5em;color:var(--accent);font:600 .85em ui-monospace,monospace}
```

## Данные исходного каталога

```json
{
  "n": 67,
  "id": "e067",
  "group": "generated",
  "title": "Номер в отдельном визуальном поле",
  "why": "Нумерация отделена от названия без добавления реальной колонки.",
  "how": "before имеет фиксированную ширину и inline-block.",
  "note": "Это часть первой ячейки; в HTML дополнительного столбца нет.",
  "hint": "",
  "source": "https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Counter_styles/Using_counters"
}
```

## HTML исходного образца

Сохранён для проверки требований к рендереру; это исторический результат, а не второй редактируемый исходник.

```html
<table>
<thead>
<tr>
<th align="left">Предмет</th>
<th align="left">Материал</th>
<th align="right">Цена, ₽</th>
</tr>
</thead>
<tbody><tr>
<td align="left">Блокнот</td>
<td align="left">Бумага</td>
<td align="right">320</td>
</tr>
<tr>
<td align="left">Карандаш</td>
<td align="left">Графит</td>
<td align="right">85</td>
</tr>
<tr>
<td align="left">Папка</td>
<td align="left">Картон</td>
<td align="right">240</td>
</tr>
<tr>
<td align="left">Линейка</td>
<td align="left">Металл</td>
<td align="right">190</td>
</tr>
</tbody></table>
```

## Опора на стандартную тему

Связи с темой проверены; изменений: 1. Используется штатных переменных: 1. Геометрия и механика эффекта сохранены.

[CSS стандартной темы](!%20P%20R%20O/hacksidian/atlas/!%20hacks/tag-e041/table-e067/Default.css) · [Данные привязки и нерешённые случаи](!%20P%20R%20O/hacksidian/atlas/!%20hacks/tag-e041/table-e067/baseline.json)

Удалите блок этого приёма или используйте Undo сразу после применения. Default.css — справка, а не сброс пользовательских настроек.
