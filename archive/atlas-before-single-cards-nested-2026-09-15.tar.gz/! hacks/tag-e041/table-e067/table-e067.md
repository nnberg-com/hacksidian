---
tags:
- atlas/technique
- atlas/table
category: table
digest: []
source_anchor: e067
sources:
- https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Counter_styles/Using_counters
example: Markdown.ru.md
template: recipe.css
format: markdown
interactive: false
id: table-e067
description: Description.ru.md
---

# table-e067

[Русский](!%20P%20R%20O/hacksidian/atlas/!%20hacks/tag-e041/table-e067/Description.ru.md)
