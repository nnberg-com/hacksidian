---
language: en
translation_status: pending
---

## Default-theme baseline

Book composition: line height ×1.13, width ×0.85, first-line indent 1.5em; preserves family.

[Default theme CSS](./Default.css) · [Baseline metadata](./baseline.json)

Remove this technique block or use Undo immediately after applying it. Default.css is reference only: do not apply it over the recipe or overwrite user settings with it.

