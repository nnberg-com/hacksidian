---
language: en
translation_status: pending
---

## Default-theme baseline

Drop cap ×4 of paragraph size; line height ×0.57; current text color and family.

[Default theme CSS](./Default.css) · [Baseline metadata](./baseline.json)

Remove this technique block or use Undo immediately after applying it. Default.css is reference only: do not apply it over the recipe or overwrite user settings with it.

