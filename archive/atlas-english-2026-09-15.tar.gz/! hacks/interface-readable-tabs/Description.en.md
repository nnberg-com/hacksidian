---
language: en
translation_status: complete
title: "More room for tab titles"
group: ""
---

# More room for tab titles

## Purpose

Tell apart notes with long, similar names.

## How it works

Obsidian variables control tab width and font size. The model uses the same variables for its illustrative tabs.

## Demonstration

Compare title truncation, then narrow the window.

## Limitations of the original technique

Many open tabs still force shrinking. This does not remove tab-strip constraints.

## Use and verification

Scope: the interface recipe affects a pane (or tab group) containing a callmered-coloring note. The model substitutes container names; native bindings are in hack.json.

An original CSS example based on the documented mechanisms and referenced practices; this is an adaptation, not copied source code. Native rendering in installed Obsidian has not been verified.

## Sources

- [Obsidian: Tabs](https://docs.obsidian.md/Reference/CSS%20variables/Components/Tabs)

## CSS for Obsidian

```css
.workspace-tabs:has(.callmered-coloring:is(.markdown-preview-view, .markdown-source-view)) {--tab-width:220px;--tab-max-width:260px;--tab-font-size:14px}
```

## Default-theme baseline

Theme bindings reviewed; replacements: 0. Native variables used: 0. Effect geometry and mechanics are preserved.

[Default theme CSS](./Default.css) · [Bindings and unresolved cases](./baseline.json)

Remove the technique block or use Undo immediately after applying. Default.css is reference only, not a reset of user settings.
