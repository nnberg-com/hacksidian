---
language: en
translation_status: pending
---

## Default-theme baseline

Three-line initial when initial-letter is supported; preserves family and color.

[Default theme CSS](./Default.css) · [Baseline metadata](./baseline.json)

Remove this technique block or use Undo immediately after applying it. Default.css is reference only: do not apply it over the recipe or overwrite user settings with it.

