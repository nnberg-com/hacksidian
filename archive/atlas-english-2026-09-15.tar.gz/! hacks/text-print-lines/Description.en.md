---
language: en
translation_status: pending
---

## Default-theme baseline

Keeps at least three paragraph lines at page breaks when printing.

[Default theme CSS](./Default.css) · [Baseline metadata](./baseline.json)

Remove this technique block or use Undo immediately after applying it. Default.css is reference only: do not apply it over the recipe or overwrite user settings with it.

