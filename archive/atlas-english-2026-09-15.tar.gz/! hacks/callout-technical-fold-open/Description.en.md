---
language: en
translation_status: pending
---

## Default-theme baseline

Theme bindings reviewed; replacements: 1. Native variables used: 1. Effect geometry and mechanics are preserved.

[Default theme CSS](./Default.css) · [Bindings and unresolved cases](./baseline.json)

Remove the technique block or use Undo immediately after applying. Default.css is reference only, not a reset of user settings.
