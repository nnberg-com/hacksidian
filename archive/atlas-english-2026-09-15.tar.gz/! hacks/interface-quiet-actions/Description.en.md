---
language: en
translation_status: complete
title: "Quiet pane actions"
group: ""
---

# Quiet pane actions

## Purpose

Reduce visual noise while keeping pane actions available.

## How it works

An adaptation of focus mode: only pane actions are muted. Hover and focus-within restore full visibility; touch devices are excluded.

## Demonstration

Hover the pane, then Tab through its buttons.

## Limitations of the original technique

Buttons remain visible and usable. This is not Minimal’s full interface-hiding implementation; the CSS is independently written.

## Use and verification

Scope: the interface recipe affects a pane (or tab group) containing a callmered-coloring note. The model substitutes container names; native bindings are in hack.json.

An original CSS example based on the documented mechanisms and referenced practices; this is an adaptation, not copied source code. Native rendering in installed Obsidian has not been verified.

## Sources

- [Minimal: Theme Settings / Focus mode](https://github.com/kepano/obsidian-minimal/blob/master/docs/Plugins/Minimal%20Theme%20Settings.md)
- [MDN: :focus-visible](https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Selectors/:focus-visible)

## CSS for Obsidian

```css
@media (hover:hover) and (pointer:fine) { .workspace-leaf:has(.callmered-coloring:is(.markdown-preview-view, .markdown-source-view)) .view-actions {opacity:.45;transition:opacity .15s} .workspace-leaf:has(.callmered-coloring:is(.markdown-preview-view, .markdown-source-view)):hover .view-actions, .workspace-leaf:has(.callmered-coloring:is(.markdown-preview-view, .markdown-source-view)):focus-within .view-actions {opacity:1} } @media (prefers-reduced-motion:reduce) { .workspace-leaf:has(.callmered-coloring:is(.markdown-preview-view, .markdown-source-view)) .view-actions {transition:none} }
```

## Default-theme baseline

Theme bindings reviewed; replacements: 0. Native variables used: 0. Effect geometry and mechanics are preserved.

[Default theme CSS](./Default.css) · [Bindings and unresolved cases](./baseline.json)

Remove the technique block or use Undo immediately after applying. Default.css is reference only, not a reset of user settings.
