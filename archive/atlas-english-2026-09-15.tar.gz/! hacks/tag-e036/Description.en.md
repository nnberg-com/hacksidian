---
language: en
translation_status: pending
---

## Default-theme baseline

Theme bindings reviewed; replacements: 2. Native variables used: 2. Effect geometry and mechanics are preserved. Needs individual review: literal-color; see baseline.json.

[Default theme CSS](./Default.css) · [Bindings and unresolved cases](./baseline.json)

Remove the technique block or use Undo immediately after applying. Default.css is reference only, not a reset of user settings.

## Refined variable bindings

Refined bindings: 2. Cases needing individual decisions: 2. [baseline.json](./baseline.json) · [Default.css](./Default.css)
