---
language: en
translation_status: complete
title: "Adapt to pane width"
group: ""
---

# Adapt to pane width

## Purpose

Keep one note readable in both a narrow split and a wide pane.

## How it works

A container query measures the note container rather than the whole window. Narrow panes compact quotes and tables.

## Demonstration

Open preview separately and narrow it below 420 px; in Obsidian resize the split pane.

## Limitations of the original technique

CSS containment can affect positioned plugin elements. Very wide tables will still need scrolling.

## Use and verification

Application is limited to callmered-coloring notes. Media conditions are evaluated by the browser or app; the atlas does not simulate them automatically.

An original CSS example based on the documented mechanisms and referenced practices; this is an adaptation, not copied source code. Native rendering in installed Obsidian has not been verified.

## Sources

- [MDN: Container queries](https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Containment/Container_queries)

## CSS for Obsidian

```css
.callmered-coloring:is(.markdown-preview-view, .markdown-source-view) {container-type:inline-size} @container (width < 420px) { .callmered-coloring:is(.markdown-preview-view, .markdown-source-view).callmered-coloring:is(.markdown-preview-view, .markdown-source-view) blockquote {margin-inline:0!important;padding-inline:.65em!important} .callmered-coloring:is(.markdown-preview-view, .markdown-source-view) table {font-size:.85em!important} }
```

## Default-theme baseline

Theme bindings reviewed; replacements: 0. Native variables used: 0. Effect geometry and mechanics are preserved.

[Default theme CSS](./Default.css) · [Bindings and unresolved cases](./baseline.json)

Remove the technique block or use Undo immediately after applying. Default.css is reference only, not a reset of user settings.
