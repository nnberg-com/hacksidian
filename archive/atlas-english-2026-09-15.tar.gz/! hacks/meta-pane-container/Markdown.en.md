---
cssclasses: atlas-meta-pane-container
---

# Workshop plan

==Important note== and [Obsidian documentation](https://help.obsidian.md/).

> Decision: run a short check before publishing.
> Participants should understand the next step without spoken instructions.

- [ ] Prepare materials
- [x] Agree on the topic
- [ ] Send invitations

| Stage | Outcome |
| --- | --- |
| Preparation | Question list |
| Meeting | Decisions and actions |

## Materials

A paragraph for checking printed pages: examples, conclusions, and next steps stay alongside their explanation.

A paragraph for checking printed pages: examples, conclusions, and next steps stay alongside their explanation.

A paragraph for checking printed pages: examples, conclusions, and next steps stay alongside their explanation.

A paragraph for checking printed pages: examples, conclusions, and next steps stay alongside their explanation.

A paragraph for checking printed pages: examples, conclusions, and next steps stay alongside their explanation.

A paragraph for checking printed pages: examples, conclusions, and next steps stay alongside their explanation.

A paragraph for checking printed pages: examples, conclusions, and next steps stay alongside their explanation.

A paragraph for checking printed pages: examples, conclusions, and next steps stay alongside their explanation.

A paragraph for checking printed pages: examples, conclusions, and next steps stay alongside their explanation.

A paragraph for checking printed pages: examples, conclusions, and next steps stay alongside their explanation.

A paragraph for checking printed pages: examples, conclusions, and next steps stay alongside their explanation.

A paragraph for checking printed pages: examples, conclusions, and next steps stay alongside their explanation.

