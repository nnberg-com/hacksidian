---
language: en
translation_status: pending
---

## Default-theme baseline

Tabular lining numerals in the current font; no text enlargement.

[Default theme CSS](./Default.css) · [Baseline metadata](./baseline.json)

Remove this technique block or use Undo immediately after applying it. Default.css is reference only: do not apply it over the recipe or overwrite user settings with it.

