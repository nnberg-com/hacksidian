---
language: en
translation_status: pending
---

## Default-theme baseline

Follows the active Obsidian theme rather than OS prefers-color-scheme; adds no palette.

[Default theme CSS](./Default.css) · [Baseline metadata](./baseline.json)

Remove this technique block or use Undo immediately after applying it. Default.css is reference only: do not apply it over the recipe or overwrite user settings with it.

