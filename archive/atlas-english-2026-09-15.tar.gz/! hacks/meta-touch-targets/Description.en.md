---
language: en
translation_status: complete
title: "Larger targets for touch input"
group: ""
---

# Larger targets for touch input

## Purpose

Space out links and checkboxes for a coarse primary pointer.

## How it works

pointer:coarse checks the primary input capability, not a device name or viewport width.

## Demonstration

Use a touch device or emulate a coarse pointer. Narrowing a desktop window alone is insufficient.

## Limitations of the original technique

A hybrid device can still report a mouse as its primary pointer. Inline links may increase line height.

## Use and verification

Application is limited to callmered-coloring notes. Media conditions are evaluated by the browser or app; the atlas does not simulate them automatically.

An original CSS example based on the documented mechanisms and referenced practices; this is an adaptation, not copied source code. Native rendering in installed Obsidian has not been verified.

## Sources

- [MDN: Pointer capabilities](https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/pointer)

## CSS for Obsidian

```css
@media (pointer:coarse) { .callmered-coloring:is(.markdown-preview-view, .markdown-source-view) a {display:inline-block;min-height:44px;padding:.35em .15em} .callmered-coloring:is(.markdown-preview-view, .markdown-source-view) li.task-list-item {min-height:44px;padding-block:.35em} .callmered-coloring:is(.markdown-preview-view, .markdown-source-view) input[type=checkbox] {min-width:24px;min-height:24px} }
```

## Default-theme baseline

Theme bindings reviewed; replacements: 0. Native variables used: 0. Effect geometry and mechanics are preserved.

[Default theme CSS](./Default.css) · [Bindings and unresolved cases](./baseline.json)

Remove the technique block or use Undo immediately after applying. Default.css is reference only, not a reset of user settings.
