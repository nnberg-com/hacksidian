---
language: en
translation_status: pending
---

## Default-theme baseline

Hanging indent of 1.5em; preserves the current font.

[Default theme CSS](./Default.css) · [Baseline metadata](./baseline.json)

Remove this technique block or use Undo immediately after applying it. Default.css is reference only: do not apply it over the recipe or overwrite user settings with it.

