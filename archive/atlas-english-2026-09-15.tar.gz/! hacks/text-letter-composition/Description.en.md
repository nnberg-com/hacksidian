---
language: en
translation_status: pending
---

## Default-theme baseline

Letter composition: line height ×1.2, width ×0.9, paragraph spacing ×1.1; retains font family and size.

[Default theme CSS](./Default.css) · [Baseline metadata](./baseline.json)

Remove this technique block or use Undo immediately after applying it. Default.css is reference only: do not apply it over the recipe or overwrite user settings with it.

